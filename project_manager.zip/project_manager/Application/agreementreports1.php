<?php  
session_start();
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");

date_default_timezone_set('Asia/Calcutta');
$current_date = date("Y-m-d");



if(isset($_POST["submit"]))
{
		
		if($_POST["types"] == "PLUS")
		{
			
		$checkbox1 = $_POST['chk1'];
		$checkbox2 = $_POST['chk2'];
		$checkbox3 = $_POST['chk3'];
		$checkbox4 = $_POST['chk4'];
		$checkbox5 = $_POST['chk5'];
		
		for ($i=0; $i<sizeof($checkbox1); $i++)
		{
		for ($i=0; $i<sizeof($checkbox2); $i++)
		{
		for ($i=0; $i<sizeof($checkbox3); $i++)
		{
		for ($i=0; $i<sizeof($checkbox4); $i++)
		{
		for ($i=0; $i<sizeof($checkbox5); $i++)
		{
		
			
			if($checkbox4[$i] == '' || $checkbox4[$i] == 0)
			{
				
			}
			else
			{	
				
				
				$sql="INSERT INTO rem_transfer(transfer_item,transfer_qty,transfer_from_type,transfer_from_outlet,transfer_from,transfer_to_type,transfer_to_outlet,transfer_to,transfer_movable,transfer_user)
VALUES
('".$checkbox5[$i]."','".$checkbox4[$i]."','".$checkbox1[$i]."','".$checkbox2[$i]."','".$checkbox3[$i]."','3','$_GET[outlet]','$_GET[merchant]','0','$_SESSION[user_name]')";
          		if (!mysql_query($sql,$con))
				{
            		die('Error: ' . mysql_error());
          		}
				
			}
		  		
		}
		}
		}
		}
		}
		
		
		
		
		
		}
	else
		{
		$checkbox1 = $_POST['chk1'];
		$checkbox2 = $_POST['chk2'];
		$checkbox3 = $_POST['chk3'];
		$checkbox4 = $_POST['chk4'];
		$checkbox5 = $_POST['chk5'];
		
		for ($i=0; $i<sizeof($checkbox1); $i++)
		{
		for ($i=0; $i<sizeof($checkbox2); $i++)
		{
		for ($i=0; $i<sizeof($checkbox3); $i++)
		{
		for ($i=0; $i<sizeof($checkbox4); $i++)
		{
		for ($i=0; $i<sizeof($checkbox5); $i++)
		{
		
			
			if($checkbox4[$i] == '' || $checkbox4[$i] == 0)
			{
				
			}
			else
			{	
				
				
				$sql="INSERT INTO rem_transfer(transfer_item,transfer_qty,transfer_from_type,transfer_from_outlet,transfer_from,transfer_to_type,transfer_to_outlet,transfer_to,transfer_movable,transfer_user)
VALUES
('".$checkbox5[$i]."','".$checkbox4[$i]."','3','$_GET[outlet]','$_GET[merchant]','".$checkbox1[$i]."','".$checkbox2[$i]."','".$checkbox3[$i]."','0','$_SESSION[user_name]')";
          		if (!mysql_query($sql,$con))
				{
            		die('Error: ' . mysql_error());
          		}
				
			}
		  		
		}
		}
		}
		}
		}
		
		
		
		
		
		
		
		
		}
		
		$message = 'Sent Successfully..!';
		echo "<SCRIPT type='text/javascript'> 
        alert('$message');
		window.location.replace(\"merchantstockreports1.php?outlet=$_GET[outlet]&merchant=$_GET[merchant]\");
    	</SCRIPT>";
	
}


$result_merchant = mysql_query("SELECT a.assign_counter counter_id,b.counter_name counter_name,c.merchant_name merchant_name,a.assign_merchant merchant_id FROM rem_counter_assign a LEFT JOIN rem_counter_master b ON a.assign_counter=b.counter_id LEFT JOIN rem_merchant c ON a.assign_merchant=c.merchant_id  WHERE a.assign_outlet='$_GET[outlet]' AND a.assign_counter='$_GET[merchant]'");
					
while($row_merchant = mysql_fetch_array($result_merchant))
  {
	  $counter_id = $row_merchant['counter_id'];
	  $merchant_name =$row_merchant['merchant_name'];
	  $counter_name=$row_merchant['counter_name'];
	  $merchant_id =$row_merchant['merchant_id'];
 }
	  
	  
if(isset($_POST["search"]))
{
	if($_POST["merchant"] == 'ALL')
	{
		header("Location: agreementreports1.php?outlet=$_POST[outlet]&merchant=$_POST[merchant]");
	}
	else
	{
		header("Location: agreementreports1.php?outlet=$_POST[outlet]&merchant=$_POST[merchant]");
	}
}

if(isset($_POST["assign"]))
{
	header("Location: agreementreports.php?outlet=$_POST[outlet]&merchant=$_POST[merchant]");	
}

if($_GET['merchant'] == 'ALL')
{
	$query_item=mysql_query("SELECT a.item_id item_id,a.item_name item_name,b.cat_name item_category,c.stock req,d.stock stock_stock,e.stock stock_sales FROM rem_item a LEFT JOIN rem_vendor_category b ON a.item_category=b.cat_id LEFT JOIN (SELECT assign_item,SUM(assign_qty) stock FROM rem_merchant_item_assign GROUP BY assign_item) AS c ON c.assign_item = a.item_id LEFT JOIN (SELECT stock_item,SUM(stock_qty) stock FROM rem_stock WHERE stock_to_type=3  GROUP BY stock_item) AS d ON d.stock_item = a.item_id
	LEFT JOIN (SELECT stock_item,SUM(stock_qty) stock FROM rem_stock WHERE stock_from_type=3 GROUP BY stock_item) AS e ON e.stock_item = a.item_id WHERE a.item_id IN (SELECT assign_item FROM rem_merchant_item_assign  GROUP BY assign_item)");

}
else 
{	
	$query_item=mysql_query("SELECT g.stock_item item_id,a.item_name item_name,b.cat_name item_category,c.stock req,d.stock stock_stock,e.stock stock_sales FROM rem_stock g 
	LEFT JOIN rem_item a ON g.stock_item=a.item_id 
	LEFT JOIN rem_vendor_category b ON a.item_category=b.cat_id 
	LEFT JOIN (SELECT assign_item,SUM(assign_qty) stock FROM rem_merchant_item_assign WHERE assign_merchant='$merchant_id' AND assign_outlet='1' GROUP BY assign_item) AS c ON c.assign_item = g.stock_item 
	LEFT JOIN (SELECT stock_item,SUM(stock_qty) stock FROM rem_stock WHERE stock_to_type=3 AND stock_to_outlet='$_GET[outlet]' AND stock_to='$_GET[merchant]' GROUP BY stock_item) AS d ON d.stock_item = g.stock_item
	LEFT JOIN (SELECT stock_item,SUM(stock_qty) stock FROM rem_stock WHERE stock_from_type=3 AND stock_from_outlet='$_GET[outlet]' AND stock_from='$_GET[merchant]' GROUP BY stock_item) AS e ON e.stock_item = g.stock_item WHERE g.stock_to_outlet='$_GET[outlet]' AND g.stock_to='$_GET[merchant]' AND g.stock_to_type='3' GROUP BY g.stock_item");
}

	while($row_item = mysql_fetch_assoc($query_item))
	{
		$details_item[] = $row_item;
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Project Manager</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
/* Paste this css to your style sheet file or under head tag */
/* This only works with JavaScript, 
if it's not present, don't show loader */
.no-js #loader { display: none;  }
.js #loader { display: block; position: absolute; left: 100px; top: 0; }
.se-pre-con {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url(images/pageLoader.gif) center no-repeat #fff;
}
</style>
</head>
<body>
<div class="se-pre-con"></div>

<div class="container">
  <h2> Merchantwise Item  Aloted Reports</h2>
  <form method="post">
    <table>
      <tr>
  <td width="6%"><br/><a class="btn btn-primary btn-sm" href="index.php" role="button"><i class="fa fa-fast-backward"></i>&nbsp;Home</a></td>
  <td width="6%"><br/>&nbsp;<a class="btn btn-success btn-sm" href="exportagreement1.php?outlet=<?php echo $_GET['outlet']; ?>&merchant=<?php echo $_GET['merchant']; ?>" role="button"><i class="fa fa-file-excel-o"></i>&nbsp;Export</a>&nbsp;</td>
  
  <td width="15%" >
  			  Choose Outlet: 
								<?php 
								$vendor = mysql_query("SELECT outlet_id,outlet_name FROM rem_outlet WHERE outlet_id!='$_GET[outlet]' AND outlet_type='0'");
								?>
                      	<select  class="form-control" onChange="showoutlet(this.value)"  name="outlet" id="outlet" onkeydown='if(event.keyCode == 13){document.getElementById("merchant").focus();return false;}'  >
                         
                                <?php 
								
							
								$vendor6 = mysql_query("SELECT outlet_id,outlet_name FROM rem_outlet WHERE outlet_id='$_GET[outlet]'");
								while($area_vendor6 = mysql_fetch_array($vendor6))
								{?>
								<option value="<?php echo $area_vendor6[0]; ?>"><?php echo $area_vendor6[1]; } ?></option>
                              
         						
                                <?php 
   								while($area_vendor = mysql_fetch_array($vendor))
								{
								?>
								<option value="<?php echo $area_vendor[0]; ?>"><?php echo $area_vendor[1]; }?></option>
      					</select>
</td>
                               
<td width="15%">

    <div id="displayCategory">                      
                         
                       
                          Choose Merchant: 
								<?php 
								
								$merchant = mysql_query("SELECT a.assign_counter,b.counter_name,c.merchant_name FROM rem_counter_assign a LEFT JOIN rem_counter_master b ON a.assign_counter=b.counter_id LEFT JOIN rem_merchant c ON a.assign_merchant=c.merchant_id  WHERE a.assign_outlet='$_GET[outlet]'");
								
								?>
                      	<select  class="form-control"   name="merchant" id="merchant" onkeydown='if(event.keyCode == 13){document.getElementById("merchant").focus();return false;}'>
                         
                                <?php 
								if($_GET['merchant'] == 'ALL')
								{?>
                                <option value="ALL">ALL Merchant..</option>
                                <?php 
								} 
								else
								{
							
								$vendor6 = mysql_query("SELECT a.assign_counter,b.counter_name,c.merchant_name FROM rem_counter_assign a LEFT JOIN rem_counter_master b ON a.assign_counter=b.counter_id LEFT JOIN rem_merchant c ON a.assign_merchant=c.merchant_id  WHERE a.assign_outlet='$_GET[outlet]' AND a.assign_counter='$_GET[merchant]'");
								while($area_vendor6 = mysql_fetch_array($vendor6))
								{?>
								<option value="<?php echo $area_vendor6[0]; ?>"><?php 
echo $area_vendor6[1]."-".$area_vendor6[2]; 
} ?></option>
                               <option value="ALL">ALL Merchant</option>
                                <?php } ?>
         						
                                <?php 
   								while($area_vendor = mysql_fetch_array($merchant))
								{
								?>
								<option value="<?php echo $area_vendor[0]; ?>"><?php 
echo $area_vendor[1]."-".$area_vendor[2]; 
} ?></option>
      					</select> 
                   
        </div>                        
</td>

<td width="8%"><br/>&nbsp;<input class="btn btn-info btn-sm" type="submit" value="Alloted Reports" name="search" id="search"></td>
<td width="8%"><br/>&nbsp;<input class="btn btn-success btn-sm" type="submit" value="Assigned Reports" name="assign" id="assign"></td>
<td width="22%"></td>
  </tr>
</table>
  </form>
  <center><h3><U>COUNTER NO-<?php echo $counter_name; ?>&nbsp;&nbsp;(<?php echo $merchant_name; ?>)</u></h3></center>
  <div >
  <p align="right"><font color="#000000">Search  : &nbsp;</font><input type="search" class="light-table-filter" data-table="table-bordered" placeholder="Filter"></p>    
  </div><br/>
  
    <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg" style="width:50%;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Shift/Transfer Item to Counter</h4>
        </div>
        <div class="modal-body ">
                <label id='ur_id'><label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>   
  <button style="display:none" type="button" class="btn btn-info btn-lg btn_open_modal" data-toggle="modal" data-target="#myModal">Open Modal</button>   
    
  <table class="table table-bordered" id="table"
               data-toggle="table"
               data-height="460"
               data-sort-name="price"
               data-sort-order="desc">
    <thead>
      <tr>
       
         <th class="col-md-1">SL.NO</th>
         <th class="col-md-2">ITEM CATEGORY</th>
        <th class="col-md-5">ITEM NAME</th> 
        <th class="col-md-1">ALLOTED ITEMS IN THIS COUNTER </th>
                 
      </tr>
    </thead>
    <tbody>
    <?php
	$counter=0;
	foreach($details_item as $i):				
	?>
      <tr>
        <td><?php echo ++$counter; ?></td>
        <td><?php print_r($i['item_category']);?></td>
        <td><?php print_r($i['item_name']) ;?></td>
      
        <td align="center"><?php print_r($sales=round($i['stock_stock']-$i['stock_sales'],0)) ;?></td>
         
      
      </tr>
	<?php
	endforeach;
	?> 

 
    </tbody>
  </table>
</div>
</body>
</html>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
<script>

//paste this code under the head tag or in a separate js file.
	// Wait for window load
	$(window).load(function() {
		// Animate loader off screen
		$(".se-pre-con").fadeOut("slow");;
	});
	</script>
    <script>
    function priceSorter(a, b) {
        a = +a.substring(1); // remove $
        b = +b.substring(1);
        if (a > b) return 1;
        if (a < b) return -1;
        return 0;
    }
</script>

<script
  src="https://code.jquery.com/jquery-3.3.1.js"
  integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
  crossorigin="anonymous"></script>

  <script
  src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.min.js"
 ></script>
  <script>
  
$(document).on('click','.lbl_item',function(){
	var item_id = $(this).attr('itm_id');
	console.log(item_id);
	$.ajax({
			url:"getshift.php",
			data:{'item_id':item_id},
			type:'POST',
			success:function(data)
			{
				$("#ur_id").html(data);
			}
	});	
	
	$(".btn_open_modal").click();
});
</script>
 <script>
(function(document) {
    'use strict';

    var LightTableFilter = (function(Arr) {

          var _input;

          function _onInputEvent(e) {
              _input = e.target;
              var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
				});
			});
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
		};
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			LightTableFilter.init();
		}
	});

})(document);
</script>
<script>
function showoutlet(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayCategory").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getmerchantwisestockreports.php?q="+str,true);
  xmlhttp.send();
}
</script>


<script>
$.tablesorter.addParser({ 
    id: 'price', 
    is: function(s) { 
        return false; 
    }, 
    format: function(s) { 
        return s.replace(/Free/,0).replace(/ CHF/,""); 
    }, 
    type: 'numeric' 
}); 

$(function() { 
    $("table").tablesorter({ 
        headers: { 
            1: { 
                sorter:'price' 
            } 
        } 
    }); 
});
</script>