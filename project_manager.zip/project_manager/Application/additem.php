<?php 
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
include("header.php");
	
if($_SESSION['user_name'])
{
	if(isset($_GET["itemid"]))
   	{
	    mysql_query("DELETE FROM rem_item WHERE item_id= '$_GET[itemid]'");
		mysql_query("DELETE FROM rem_item_mapping WHERE map_item_id= '$_GET[itemid]'");
   	}
	
	if(isset($_GET["del_row"]))
   	{
		mysql_query("DELETE FROM rem_item_mapping WHERE map_id='$_GET[del_row]' AND map_item_id='$_GET[item_id]' ");
   	}
	
	if(isset($_POST["add"]))
	{
		
		$session_item_id=$_GET['item_id'];
			
		
		$result9 = mysql_query("SELECT map_specification_id FROM  rem_item_mapping where map_item_id='$session_item_id'");
		while($row9 = mysql_fetch_array($result9))
  		{
 		$username= $row9[0];
		}
	
	
		if ($_POST['specification'] == $username ) 
		{
			echo "<script>alert('Specification Already Choosen..!'); 
          	window.history.go(-1);
    		</script>";
		}
		else
		{
		
		$sql1="INSERT INTO rem_item_mapping(map_item_id,map_specification_id)
		VALUES('$session_item_id','$_POST[specification]')";

		if (!mysql_query($sql1,$con))
    	{
     		die('Error: ' . mysql_error());
   		}
		
		echo "<script>window.history.go(-1);</script>";
		}
	}
   
if(isset($_POST["submit"]))
{
	$result9 = mysql_query("SELECT item_name FROM rem_item where item_name='$_POST[name]'");
	while($row9 = mysql_fetch_array($result9))
  	{
 		$username= $row9[0];
	}
	
	
	if ($_POST['name'] == $username ) 
	{
		echo "<script>alert('Item Already Exist..!'); 
          	 	 window.history.go(-1);
    		 	 </script>";
	}
	else
	{
		$max_header_result = mysql_query("SELECT MAX(item_id) FROM rem_item");
		while($row_id = mysql_fetch_array($max_header_result))
		{
			$max_header = $row_id[0];
		}
	
			
		if ($max_header == 0 )
		{
			$max_header_id = "1";	
		}
		else
		{
			$max_header_id = $max_header;
			$max_header_id++;
		} 
		$header_id=$max_header_id;
	
 		$sql="INSERT INTO rem_item(item_id,item_name,item_category,item_unit,item_code,item_tax,item_movable,item_barcode)
		VALUES ('$header_id','$_POST[name]','$_POST[category]','$_POST[unit]','$_POST[sname]','$_POST[tax]','$_POST[movable]','$_POST[barcode]')";
 

       	if (!mysql_query($sql,$con))
      	{
           die('Error: ' . mysql_error());
       	}
		
		$checkbox1 = $_POST['chk1'];
		$checkbox2 = $_POST['chk2'];
	
		for ($i=0; $i<sizeof($checkbox1); $i++)
		{
		for ($i=0; $i<sizeof($checkbox2); $i++)
		{
			mysql_query("UPDATE rem_item_mapping SET map_item_id='$header_id',map_values='".$checkbox2[$i]."' WHERE map_item_id='$_GET[item_id]' AND map_specification_id='".$checkbox1[$i]."'");
		}
		}
			
		$message = 'Item Created Successfully';
	 	echo "<SCRIPT type='text/javascript'> 
     	alert('$message');
     	window.location.replace(\"additem.php\");
     	</SCRIPT>";
		
  	}
     
	 
}
?>
   
<div id="wrapper">
            <div id="layout-static">
              <div class="static-content-wrapper">
                  <div class="static-content">
                        <div class="page-content">
                          <ol class="breadcrumb">
                                
 <li class=""> <div class="btn-toolbar">
       <a class="btn btn-midnightblue" href="viewitem.php"><i class="fa fa-fast-backward"></i> Back</a> &nbsp;&nbsp;
    </div></li>


                          </ol>
                            <div class="container-fluid">
                              
  <div class="row">
	<div class="col-sm-7">
	  <div class="panel panel-midnightblue">
	    <div class="panel-heading">
				<h2>Item  Master</h2>
			</div>
			<div class="panel-body">
				<div class="tab-content">
					<div class="tab-pane active" id="horizontal-form">
						<form  method="post" class="form-horizontal">
                     <?php if(isset($_GET['display']))
					 {
						 ?> <center><font color="#FF0000" size="3"><b><?php echo $_GET['display']; ?></b></font></center>
                         <?php } ?>
						  <div class="form-group">
								<label for="inputPassword" class="col-sm-2 control-label">Item Name</label>
							  <div class="col-sm-8">
								  <input type="text" class="form-control" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("sname").focus();return false;}' id="name" value="" name="name" placeholder="Enter Item Name" >
						   </div>
						  </div>
                          <div class="form-group">
								<label for="inputPassword" class="col-sm-2 control-label">Item Code</label>
							  <div class="col-sm-8">
								  <input type="text" required="required" class="form-control" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("category").focus();return false;}' id="sname" value="" name="sname" placeholder="Enter Item Code" >
						   </div>
						  </div>
                          <div class="form-group">
						    <label for="selector1" class="col-sm-2 control-label">Item Category</label>
							<div class="col-sm-8">
                                  <?php
         $countries = mysql_query("SELECT cat_id,cat_name FROM rem_vendor_category");
		 ?>
		<select required  class="form-control"  name="category" id="category" onkeydown='if(event.keyCode == 13){document.getElementById("ordertype").focus();return false;}'>
         <option value="">Choose Category...</option>
         <?php 
   		while($row_countries = mysql_fetch_array($countries))
		{
		?>
		<option value="<?php echo $row_countries[0]; ?>"><?php echo $row_countries[1]; }?></option>
      
       </select></div>
						  </div>
					<!--Hide <div class="form-group">
						    <label for="selector1" class="col-sm-2 control-label">Order Type</label>
							<div class="col-sm-8">
             <?php
         $order_type = mysql_query("SELECT type_id,type_name FROM rem_order_type");
		 ?>                      
		<select required  class="form-control" name="order_type" id="order_type" onkeydown='if(event.keyCode == 13){document.getElementById("unit").focus();return false;}'>
        <option value="">Choose Order Type</option>
         <?php
        while($row_order_type = mysql_fetch_array($order_type))
		{?>
         <option value="<?php echo $row_order_type[0]; ?>"><?php echo $row_order_type[1]; ?></option>
        <?php } ?>
       	 </select></div>
						  </div>
					 -->
                          <div class="form-group">
						    <label for="selector1" class="col-sm-2 control-label">Choose Unit</label>
							<div class="col-sm-8">
                                  <?php
         $units = mysql_query("SELECT unit_id,unit_name FROM rem_unit");
		 ?>
		<select required  class="form-control"  name="unit" id="unit" onkeydown='if(event.keyCode == 13){document.getElementById("barcode").focus();return false;}'>
         <option value="">Choose Unit...</option>
         <?php 
   		while($row_units = mysql_fetch_array($units))
		{
		?>
		<option value="<?php echo $row_units[0]; ?>"><?php echo $row_units[1]; }?></option>
      
       </select></div>
						  </div>
                          <div class="form-group">
						    <label for="selector1" class="col-sm-2 control-label">Barcode Required??</label>
							<div class="col-sm-8">
                                 
		<select required class="form-control"  name="barcode" id="barcode" onkeydown='if(event.keyCode == 13){document.getElementById("movable").focus();return false;}'>
         <option value="">Barcode Required ...</option>
         <option value="0">NOT REQUIRED</option>
         <option value="1">REQUIRED</option>
      
       </select></div>
						  </div>

						    <div class="form-group">
						    <label for="selector1" class="col-sm-2 control-label">Choose Movable</label>
							<div class="col-sm-8">
                                 
		<select required class="form-control"  name="movable" id="movable" onkeydown='if(event.keyCode == 13){document.getElementById("specification").focus();return false;}'>
         <option value="">Choose ...</option>
         <option value="0">MOVABLE</option>
         <option value="1">IMMOVABLE</option>
      
       </select></div>
						  </div>
                          
                          <div class="form-group">
						    <label for="selector1" class="col-sm-2 control-label">Choose Tax%</label>
							<div class="col-sm-8">
                                  <?php
         $tax = mysql_query("SELECT tax_id,tax_primary FROM rem_tax_master");
		 ?>
		<select required  class="form-control"  name="tax" id="tax" onkeydown='if(event.keyCode == 13){document.getElementById("specification").focus();return false;}'>
         <option value="">Choose Tax%...</option>
         <?php 
   		while($row_tax = mysql_fetch_array($tax))
		{
		?>
		<option value="<?php echo $row_tax[0]; ?>"><?php echo round($row_tax[1],0)."%"; }?></option>
      
       </select></div>
						  </div>
                      <div class="form-group">
<label for="selector1" class="col-sm-2 control-label">Specification</label>
<div class="col-sm-7">
<?php
$specification = mysql_query("SELECT id,name FROM rem_item_specification");
?>
  <select   class="form-control"     name="specification" id="specification" onkeydown='if(event.keyCode == 13){document.getElementById("area").focus();return false;}'>
    <option value="">Choose Specification to create item ...</option>
    <?php 
while($row_specification = mysql_fetch_array($specification))
{?>
    <option value="<?php echo $row_specification[0]; ?>"><?php echo $row_specification[1]; }?></option>
  </select>
<a href="additemconfigure.php" >Add more specification</a>
</div>
<div class="col-sm-1">
<button type="submit" class="btn btn-success"   name="add" id="add">ADD</button>
</div></div>
                         
                         
        <?php
		$item_list = mysql_query("SELECT a.map_id,a.map_item_id,a.map_specification_id,a.map_values,b.name FROM rem_item_mapping a LEFT JOIN rem_item_specification b ON a.map_specification_id = b.id WHERE a.map_item_id='$_GET[item_id]'");
		while($row_item = mysql_fetch_array($item_list))
  		{
		?>
<div class="form-group">
	<label for="inputPassword" class="col-sm-2 control-label"><?php echo $row_item[4]; ?></label>
	<div class="col-sm-7">
		<input type="hidden" class="form-control" onkeydown='if (event.keyCode == 13){document.getElementById("specification").focus();return false;}' id="chk1[]" value="<?php echo $row_item[2]; ?>" name="chk1[]" placeholder="Enter <?php echo $row_item[4]; ?>" required>
        <input type="text" class="form-control" onkeydown='if (event.keyCode == 13){document.getElementById("specification").focus();return false;}' id="chk2[]" value="" name="chk2[]" placeholder="Enter <?php echo $row_item[4]; ?>" >
	</div>
    <div class="col-sm-1">
<a href="additem.php?del_row=<?php echo $row_item[0]; ?>&item_id=<?php echo $_GET['item_id']; ?>" class="btn btn-danger"><i class="fa fa-times-circle"></i></a>
</div>
</div>
<?php 
		}
	
?>


                          
                        </div>
					<div class="tab-pane" id="vertical-form"></div>
					</div>
                    
                      <div class="form-group">
								<label for="focusedinput" class="col-sm-2 control-label"></label>
								<div class="col-sm-8">
									<button type="submit" class="btn btn-info"  style="background-color:#F93;"  name="submit" id="submit">Create Item</button>
								</div>
						  </div>
  
                            </form>
				
         
			</div>
		</div>
        
	</div>
</div>
                          </div> 
                            <!-- .container-fluid -->
                        </div> <!-- #page-content -->
                </div>
                    <footer role="contentinfo">
   <?php include("footer.php"); ?>
</footer>
              </div>
  </div>
</div>



<!-- Switcher --><!-- /Switcher -->
    <!-- Load site level scripts -->

<!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script> -->
<script>
function confirmDelete(delUrl) {
  if (confirm("Are you sure you want to delete")) {
    document.location = delUrl;
  }
}
</script>
<script src="assets/js/jquery-1.10.2.min.js"></script> 							<!-- Load jQuery -->
<script src="assets/js/jqueryui-1.9.2.min.js"></script> 							<!-- Load jQueryUI -->

<script src="assets/js/bootstrap.min.js"></script> 								<!-- Load Bootstrap -->


<script src="assets/plugins/easypiechart/jquery.easypiechart.js"></script> 		<!-- EasyPieChart-->
<script src="assets/plugins/sparklines/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
<script src="assets/plugins/jstree/dist/jstree.min.js"></script>  				<!-- jsTree -->

<script src="assets/plugins/codeprettifier/prettify.js"></script> 				<!-- Code Prettifier  -->
<script src="assets/plugins/bootstrap-switch/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->

<script src="assets/plugins/bootstrap-tabdrop/js/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->

<script src="assets/plugins/iCheck/icheck.min.js"></script>     					<!-- iCheck -->

<script src="assets/js/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->

<script src="assets/plugins/bootbox/bootbox.js"></script>							<!-- Bootbox -->

<script src="assets/plugins/simpleWeather/jquery.simpleWeather.min.js"></script> <!-- Weather plugin-->

<script src="assets/plugins/nanoScroller/js/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->

<script src="assets/plugins/jquery-mousewheel/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script src="assets/plugins/datatables/jquery.dataTables.js"></script>
<script src="assets/plugins/datatables/dataTables.bootstrap.js"></script>
<script src="assets/demo/demo-datatables.js"></script>
<script src="assets/js/application.js"></script>
<script src="assets/demo/demo.js"></script>
<script src="assets/demo/demo-switcher.js"></script>

<!-- End loading site level scripts -->
    
    <!-- Load page level scripts-->
    

    <!-- End loading page level scripts-->

</body>

<!-- Mirrored from avenger.kaijuthemes.com/ui-forms.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 24 Oct 2015 18:46:10 GMT -->
</html>
<?php }
      else
        {
	       header('Location: ../index.php');
        }
		
	?>