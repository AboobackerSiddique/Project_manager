<?php
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php"); 
include("header.php"); 

if(isset($_POST["submit"]))
{
	header("Location: balancereports.php?outlet=$_POST[outlet]");
}

if($_GET['outlet'] == '1')
{
	$outlet='31';
}
else if($_GET['outlet'] == '2')
{
	$outlet='21';
}
else if($_GET['outlet'] == '3')
{
	$outlet='21';
}
else if($_GET['outlet'] == '5')
{
	$outlet='31';
}

if($_GET['outlet'] == 'ALL')
{
	
	$query_item=mysql_query("SELECT a.item_id item_id,a.item_name item_name,b.assign assign,c.stock stock,d.sales sales,e.delivered delivered FROM rem_item a 
	LEFT JOIN (SELECT assign_item,SUM(assign_qty) assign FROM rem_merchant_item_assign  GROUP BY assign_item) AS b ON b.assign_item=a.item_id 
	LEFT JOIN (SELECT stock_item,SUM(stock_qty) stock FROM rem_stock WHERE stock_to_type='3' GROUP BY stock_item) AS c ON c.stock_item=a.item_id
		
	LEFT JOIN (SELECT stock_item,SUM(stock_qty) sales FROM rem_stock WHERE stock_from_type='3' GROUP BY stock_item) AS d ON d.stock_item=a.item_id
	
	LEFT JOIN (SELECT details_item,SUM(details_qty) delivered FROM rem_delivery_details  GROUP BY details_item) AS e ON e.details_item=a.item_id
	
	 WHERE a.item_id IN (SELECT assign_item FROM rem_merchant_item_assign) AND a.item_category=1 ORDER BY a.item_id LIMIT 1000");
}
else
{
		$query_item=mysql_query("SELECT a.item_id item_id,a.item_name item_name,b.assign assign,c.stock alot,d.sales sales FROM rem_item a LEFT JOIN (SELECT assign_item,SUM(assign_qty) assign FROM rem_merchant_item_assign WHERE assign_outlet='$_GET[outlet]' GROUP BY assign_item) AS b ON b.assign_item=a.item_id 
		LEFT JOIN (SELECT stock_item,SUM(stock_qty) stock FROM rem_stock WHERE stock_to_type='3'  AND stock_to_outlet='$_GET[outlet]' GROUP BY stock_item) AS c ON c.stock_item=a.item_id 
		LEFT JOIN (SELECT stock_item,SUM(stock_qty) sales FROM rem_stock WHERE stock_from_type='3' AND stock_from_outlet='$_GET[outlet]'  GROUP BY stock_item ) AS d ON d.stock_item=a.item_id WHERE a.item_id IN (SELECT assign_item FROM rem_merchant_item_assign WHERE assign_outlet='$_GET[outlet]') AND a.item_category=1 ORDER BY a.item_id LIMIT 1000");
}
		
	  while($row_item = mysql_fetch_assoc($query_item))
		{
			$details_item[] = $row_item;
		}
		
?>


<div class="shadow-lg p-3 mb-1 bg-white rounded" style="position:fixed; width:100%; z-index:9999;">
   <a href="dashboard.php" class="btn btn-success btn-sm">Back</a>
 
</div>
 
 <br/>
<br/>
<br/>



  <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #ddd;
}

th, td {
    padding: 5px;
	font-size:10px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<h2>&nbsp;Excess Reports&nbsp;&nbsp;  <a data-toggle="modal" href="#myModals" style="background-color:#666;" class="btn btn-success btn-sm"><i class="fa fa-filter"></i> More Filter</a> </h2>

<div >
  <p align="right"><font color="#000000">Smart Search  : &nbsp;</font><input type="search" class="light-table-filter" data-table="table-bordered" placeholder="Filter">&nbsp;&nbsp;</p>    
  </div>
   <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg" style="width:95%; padding-top:100px;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Choose Outlet</h4>
           <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body ">
                <label id='ur_id'><label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>   
  <button style="display:none" type="button" class="btn btn-info btn-lg btn_open_modal" data-toggle="modal" data-target="#myModal">Open Modal</button>   
<div style="overflow-x:auto;">
  
  
 <?php 
 if($_GET['outlet'] == 'ALL')
 {?>          
  <table class="table-bordered">
    <thead>
      <tr>
        
        <th width="70%" >Item Name</th>
        <th width="5%">Prchse</th>
        <th width="5%" >Asgnd</th>
        <th width="5%" >Alot</th>
        <th width="5%">Req</th>
        <th width="5%">WH</th>
         <th width="5%">To Ordr</th>
      </tr>
    </thead>
    <tbody>
    <?php
	$total_Advance=0;				
	$counter=0;
	foreach($details_item as $i):
	$total_Advance+=$i['advance'];					  
	?>
      <tr>
      
        <td ><?php  print_r($i['item_name']); ?></td>
        <td align="center">
       <?php  print_r(round($i['delivered'])); ?></td>
        <td align="center"><?php  print_r($assign=round($i['assign'],0)); ?></td>
        <td align="center"><?php  print_r($alot=round($i['stock']-$i['sales'],0)); ?></td>
        <td align="center"> <div><a href="#" class="lbl_item btn btn-warning btn-sm" itm_id="<?php print_r($i['item_id'].'$'.$_GET['outlet']); ?>"><?php echo $balance=$assign-$alot; ?></a></div></td>
       
       
    <td align="center">
       <?php
       $result = mysql_query("SELECT a.item_name name,b.stock stock,c.sales sales FROM rem_item a LEFT JOIN (SELECT stock_item,SUM(stock_qty) stock FROM rem_stock WHERE stock_to_type=2 GROUP BY stock_item) AS b ON b.stock_item=a.item_id LEFT JOIN (SELECT stock_item,SUM(stock_qty) sales FROM rem_stock WHERE stock_from_type=2 GROUP BY stock_item) AS c ON c.stock_item=a.item_id WHERE a.item_id='$i[item_id]'");
	while($row = mysql_fetch_array($result))
  	{
		echo $warehouse=$row['stock']-$row['sales'];
	}
	?></td>
    <td align="center"><b><?php echo $balance-$warehouse; ?></b></td>
        
      </tr>
		<?php
		endforeach;
		?> 

 
    </tbody>
  </table>
  <?php 
 }
 else
 {?>
<table class="table-bordered">
    <thead>
      <tr>
        
        <th width="80%" >Item Name</th>
        <th width="5%" >Assigned</th>
        <th width="5%" >Aloted</th>
         <th width="5%">Required</th>
        <th width="5%">WH Stock</th>
         
      </tr>
    </thead>
    <tbody>
    <?php
	$total_Advance=0;				
	$counter=0;
	foreach($details_item as $i):
	$total_Advance+=$i['advance'];					  
	?>
      <tr>
       
        <td align="center"><?php  print_r($i['item_name']); ?></td>
        <td align="center"><?php  print_r($assign=round($i['assign'],0)); ?></td>
        <td align="center"><?php  print_r($alot=round($i['alot']-$i['sales'],0)); ?></td>
        <td align="center"><div><a href="#" class="lbl_item btn btn-warning btn-sm" itm_id="<?php print_r($i['item_id'].'$'.$_GET['outlet']); ?>" ><?php echo $balance=$assign-$alot; ?></a></div></td>
       <td align="center">
       <?php
       $result = mysql_query("SELECT a.item_name name,b.stock stock,c.sales sales FROM rem_item a LEFT JOIN (SELECT stock_item,SUM(stock_qty) stock FROM rem_stock WHERE stock_to_type=2 GROUP BY stock_item) AS b ON b.stock_item=a.item_id LEFT JOIN (SELECT stock_item,SUM(stock_qty) sales FROM rem_stock WHERE stock_from_type=2 GROUP BY stock_item) AS c ON c.stock_item=a.item_id WHERE a.item_id='$i[item_id]'");
	while($row = mysql_fetch_array($result))
  	{
		echo $warehouse=$row['stock']-$row['sales'];
	}
	?></td>
       
       
      </tr>
		<?php
		endforeach;
		?> 

 
    </tbody>
  </table>
 <?php } ?>
</div>

</body>
</html>
<div class="modal fade" id="myModals" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-dialog" style="padding-top:70px;">
						<div class="modal-content">
							<div class="modal-header">
								
								<h2 class="modal-title">Filter</h2>
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div>
							 <form class="form-horizontal" role="form" method="post">
<div class="modal-body">
					
                     <div class="form-group">
                        <label for="inputLinkPp" class="hidden-xs col-sm-3 control-label">Choose Outlet:</label>
                        <div class="input-group col-sm-8 xs-margin">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
                      <?php 
								$vendor = mysql_query("SELECT outlet_id,outlet_name FROM rem_outlet WHERE outlet_id!='$_GET[outlet]'");
								?>
		<select  class="form-control"  name="outlet" id="outlet" onkeydown='if(event.keyCode == 13){document.getElementById("type").focus();return false;}'  >
        <?php 
								if($_GET['outlet'] == 'ALL')
								{?>
                                <option value="ALL">ALL Outlet..</option>
                                <?php 
								} 
								else
								{
								$vendor6 = mysql_query("SELECT outlet_id,outlet_name FROM rem_outlet WHERE outlet_id='$_GET[outlet]'");
								while($area_vendor6 = mysql_fetch_array($vendor6))
								{
								?>
		  <option value="<?php echo $area_vendo6r[0]; ?>"><?php echo $area_vendor6[1]; }?></option>
           				<option value="ALL">ALL Outlet..</option>
                      <?php  }?>
		  <?php 
   								while($area_vendor = mysql_fetch_array($vendor))
								{
								?>
		  <option value="<?php echo $area_vendor[0]; ?>"><?php echo $area_vendor[1]; }?></option>
	    </select>
                       </div>
                    </div>
                    
</div>
<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								<button type="submit" name="submit" id="submit" class="btn btn-primary">Search</button>
							</div>
                            </form>
						</div><!-- /.modal-content -->
					</div><!-- /.modal-dialog -->
				</div>  
   <script>
    function priceSorter(a, b) {
        a = +a.substring(1); // remove $
        b = +b.substring(1);
        if (a > b) return 1;
        if (a < b) return -1;
        return 0;
    }
</script>
<script>
  
$(document).on('click','.lbl_item',function(){
	var item_id = $(this).attr('itm_id');
	console.log(item_id);
	$.ajax({
			url:"getbalance.php",
			data:{'item_id':item_id},
			type:'POST',
			success:function(data)
			{
				$("#ur_id").html(data);
			}
	});	
	
	$(".btn_open_modal").click();
});
</script>
 <script>
(function(document) {
    'use strict';

    var LightTableFilter = (function(Arr) {

          var _input;

          function _onInputEvent(e) {
              _input = e.target;
              var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
				});
			});
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
		};
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			LightTableFilter.init();
		}
	});

})(document);
</script>

<script>
$.tablesorter.addParser({ 
    id: 'price', 
    is: function(s) { 
        return false; 
    }, 
    format: function(s) { 
        return s.replace(/Free/,0).replace(/ CHF/,""); 
    }, 
    type: 'numeric' 
}); 

$(function() { 
    $("table").tablesorter({ 
        headers: { 
            1: { 
                sorter:'price' 
            } 
        } 
    }); 
});
</script>