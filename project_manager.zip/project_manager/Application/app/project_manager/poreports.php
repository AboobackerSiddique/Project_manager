<?php
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php"); 
include("header.php"); 

if(isset($_POST["submit"]))
{
	header("Location: poreports.php?vendor=$_POST[vendor]&type=$_POST[type]");
}
	if($_GET['vendor'] == 'ALL' && $_GET['type'] == 'ALL')
	{
		$query_merchant_assign=mysql_query("SELECT a.order_header_id pono,a.order_date order_date,a.order_delivery_date delivery_date,b.vendor_name vendor,a.order_total_amount total,a.order_advance advance,a.order_type type,a.order_vendor vendor_id FROM rem_order a LEFT JOIN rem_vendor b ON a.order_vendor=b.vendor_id WHERE a.order_modify!='1'
 GROUP BY a.order_header_id,a.order_type ORDER BY a.order_header_id");
		
	}
	else if($_GET['vendor'] != 'ALL' && $_GET['type'] == 'ALL')
	{
		$query_merchant_assign=mysql_query("SELECT a.order_header_id pono,a.order_date order_date,a.order_delivery_date delivery_date,b.vendor_name vendor,a.order_total_amount total,a.order_advance advance,a.order_type type,a.order_vendor vendor_id  FROM rem_order a LEFT JOIN rem_vendor b ON a.order_vendor=b.vendor_id 
 WHERE  a.order_vendor='$_GET[vendor]' AND a.order_modify!='1' GROUP BY a.order_header_id,a.order_type  ORDER BY a.order_header_id");
	}
	else if($_GET['vendor'] == 'ALL' && $_GET['type'] != 'ALL')
	{
		$query_merchant_assign=mysql_query("SELECT a.order_header_id pono,a.order_date order_date,a.order_delivery_date delivery_date,b.vendor_name vendor,a.order_total_amount total,a.order_advance advance,a.order_type type,a.order_vendor vendor_id  FROM rem_order a LEFT JOIN rem_vendor b ON a.order_vendor=b.vendor_id 
 WHERE a.order_type='$_GET[type]' AND a.order_process=0 AND a.order_modify!='1'  GROUP BY a.order_header_id,a.order_type  ORDER BY a.order_header_id");
	}
	else 
	{
		$query_merchant_assign=mysql_query("SELECT a.order_header_id pono,a.order_date order_date,a.order_delivery_date delivery_date,b.vendor_name vendor,a.order_total_amount total,a.order_advance advance,a.order_type type,a.order_vendor vendor_id  FROM rem_order a LEFT JOIN rem_vendor b ON a.order_vendor=b.vendor_id 
 WHERE  a.order_vendor='$_GET[vendor]' AND  a.order_type='$_GET[type]' AND a.order_process=0 AND a.order_modify!='1' GROUP BY a.order_header_id,a.order_type  ORDER BY a.order_header_id");
	}
	
	while($row_item = mysql_fetch_assoc($query_merchant_assign))
		{
			$details_item[] = $row_item;
		}
		
?>


<div class="shadow-lg p-3 mb-1 bg-white rounded" style="position:fixed; width:100%; z-index:9999;">
   <a href="dashboard.php" class="btn btn-success btn-sm">Back</a>
 
</div>
 
 <br/>
<br/>
<br/>



  <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #ddd;
}

th, td {
    padding: 5px;
	font-size:10px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<h2>&nbsp;PO/WO Reports&nbsp;&nbsp;   <a data-toggle="modal" href="#myModals" style="background-color:#666;" class="btn btn-success btn-sm"><i class="fa fa-filter"></i> More Filter</a> </h2>

<div >
  <p align="right"><font color="#000000">Smart Search  : &nbsp;</font><input type="search" class="light-table-filter" data-table="table-bordered" placeholder="Filter">&nbsp;&nbsp;</p>    
  </div>
   <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg" style="width:95%; padding-top:100px;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">PO/WO Details</h4>
           <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body ">
                <label id='ur_id'><label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>   
  <button style="display:none" type="button" class="btn btn-info btn-lg btn_open_modal" data-toggle="modal" data-target="#myModal">Open Modal</button>   
<div style="overflow-x:auto;">
  
  <table class="table-bordered">
  <thead>
    <tr>
      <th width="4%">SLNO</th>
      <th width="8%">PO/WO</th>
      <th width="10%">ORDERD</th>
      <th width="60%">VENDOR NAME</th>
      <th width="7%">TOTAL</th>
       <th width="7%">PAID</th>
        <th width="7%">BAL</th>
    </tr>
    </thead>
    <?php
	$total_Advance=0;
	$counter=0;
	foreach($details_item as $i):	
	$total_Advance+=$i['advance'];			
	?>
    <tr>
      <td><?php echo ++$counter; ?></td>
      <td><a href="#" class="btn btn-<?php if($i['type'] == '1') { echo "info"; } else { echo "success"; } ?> btn-sm lbl_item" itm_id="<?php print_r($i['pono'].'$'.$i['type'].'$'.$i['vendor_id'].'$'.$i['vendor']); ?>"><font size="1"><?php if($i['type'] == '1') { echo "PO"; } else { echo "WO"; } ?>-<?php print_r($i['pono']); ?></font></a></td>
      <td>
	  <?php echo date("d/m/y", strtotime($i['order_date'])) ;?></td>
       <td><?php print_r($i['vendor']) ;?></td>
        <td align="right"><?php 
	if($_GET['type'] == 'ALL')
	{
		$query_merchant_total=mysql_query("SELECT SUM(details_amount) amount FROM rem_order_details WHERE details_header_id='$i[pono]' AND details_order_type='$i[type]' AND details_modify!='1'");
		
	}
	else 
	{
		$query_merchant_total=mysql_query("SELECT SUM(details_amount) amount FROM rem_order_details WHERE details_header_id='$i[pono]' AND details_order_type='$_GET[type]' AND details_modify!='1'");
	}
	while($row_total = mysql_fetch_assoc($query_merchant_total))
		{
			echo $total_amt=round($row_total['amount'],0);
		}?></td>
        <td align="right">
		<?php 
$result212 = mysql_query("SELECT SUM(payment_amount) FROM rem_order_payment WHERE payment_order_id='$i[pono]' AND payment_order_type='$i[type]' ");
while($row212 = mysql_fetch_array($result212))
{
	$advance_paid=round($row212[0],0);	
}

echo $advance_amount=round($i['advance']+$advance_paid); 
?></td>
        <td align="right"><?php echo $total_amt-$advance_amount;?></td>
    </tr>
    <?php
	endforeach;
	?>
    <tr>
<td colspan="4" align="right"><b>TOTAL</b>&nbsp;</td>  
<td align="right"><b><?php 
if($_GET['type'] == 'ALL' && $_GET['vendor'] == 'ALL')
{
	$query = mysql_query("SELECT SUM(details_amount) FROM rem_order_details WHERE details_modify!='1'");

} 
else if($_GET['type'] == 'ALL' && $_GET['vendor'] != 'ALL')
{
	$query = mysql_query("SELECT SUM(details_amount) FROM rem_order_details WHERE details_vendor_id='$_GET[vendor]' AND details_modify!='1'");
}
else if($_GET['type'] != 'ALL' && $_GET['vendor'] == 'ALL')
{
	$query = mysql_query("SELECT SUM(details_amount) FROM rem_order_details WHERE details_order_type='$_GET[type]' AND details_modify!='1'");
}
else 
{
	$query = mysql_query("SELECT SUM(details_amount) FROM rem_order_details WHERE details_order_type='$_GET[type]' AND details_vendor_id='$_GET[vendor]' AND details_modify!='1'");
}
	while($row = mysql_fetch_array($query))
	{
	
	echo $total_Amount = round($row[0],0);
			
		} ?></b></td>
<td align="right"><b><?php 
if($_GET['type'] == 'ALL' && $_GET['vendor'] == 'ALL')
{
$result212 = mysql_query("SELECT SUM(payment_amount) FROM rem_order_payment ");
}
else if($_GET['type'] != 'ALL' && $_GET['vendor'] == 'ALL')
{
	$result212 = mysql_query("SELECT SUM(payment_amount) FROM rem_order_payment WHERE  payment_order_type='$_GET[type]'");
}
else if($_GET['type'] == 'ALL' && $_GET['vendor'] != 'ALL')
{
	$result212 = mysql_query("SELECT SUM(payment_amount) FROM rem_order_payment WHERE  payment_vendor_id='$_GET[vendor]'");
}
else 
{
	$result212 = mysql_query("SELECT SUM(payment_amount) FROM rem_order_payment WHERE  payment_vendor_id='$_GET[vendor]' AND payment_order_type='$_GET[type]'");
}
while($row212 = mysql_fetch_array($result212))
{
	$total_advance_paid=round($row212[0],0);	
}
 echo $advance_paid=round($total_Advance+$total_advance_paid,0);
 ?></b></td>
<td align="right"><b><?php 
echo $total_Amount-$advance_paid; ?></b></td>

</tr>
  </table>
</div>

</body>
</html>
<div class="modal fade" id="myModals" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-dialog" style="padding-top:70px;">
						<div class="modal-content">
							<div class="modal-header">
								
								<h2 class="modal-title">Filter</h2>
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div>
							 <form class="form-horizontal" role="form" method="post">
<div class="modal-body">
					 <div class="form-group">
                        <label for="inputLinkPp" class="hidden-xs col-sm-3 control-label">Choose Vendor:</label>
                        <div class="input-group col-sm-8 xs-margin">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
                      	<?php 
								$vendor = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor WHERE vendor_id!='$_GET[vendor]'");
								?>
                             	<select  class="form-control"  name="vendor" id="vendor" onkeydown='if(event.keyCode == 13){document.getElementById("type").focus();return false;}'  >
         						
                                
                                
                                <?php 
								if($_GET['vendor'] == 'ALL')
								{?>
                                <option value="ALL">ALL Vendor..</option>
                                <?php 
								} 
								else
								{
								$vendor6 = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor WHERE vendor_id='$_GET[vendor]'");
								while($area_vendor6 = mysql_fetch_array($vendor6))
								{
								?>
								<option value="<?php echo $area_vendo6r[0]; ?>"><?php echo $area_vendor6[1]; }?></option>
                                 <option value="ALL">ALL Vendor..</option>
                                  <?php } ?>
                               
         						<?php 
   								while($area_vendor = mysql_fetch_array($vendor))
								{
								?>
								<option value="<?php echo $area_vendor[0]; ?>"><?php echo $area_vendor[1]; }?></option>
      							</select>
                       </div>
                    </div>
                   
                     <div class="form-group">
                        <label for="inputLinkPp" class="hidden-xs col-sm-3 control-label">Choose Vendor:</label>
                        <div class="input-group col-sm-8 xs-margin">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
                      <?php 
								$vendor1 = mysql_query("SELECT type_id,type_shortname FROM rem_order_type WHERE type_id!='$_GET[type]'");
								?>
                             	<select  class="form-control"  name="type" id="type" onkeydown='if(event.keyCode == 13){document.getElementById("submit").focus();return false;}'  >
         						
                                
                                
                                <?php 
								if($_GET['type'] == 'ALL')
								{?>
                                <option value="ALL">ALL PO & WO..</option>
                                <?php 
								} 
								else
								{
								$vendor61 = mysql_query("SELECT type_id,type_shortname FROM rem_order_type WHERE type_id='$_GET[type]'");
								while($area_vendor61 = mysql_fetch_array($vendor61))
								{
								?>
								<option value="<?php echo $area_vendo61[0]; ?>"><?php echo $area_vendor61[1]; }?></option>
                                 <option value="ALL">ALL PO & WO..</option>
                                  <?php } ?>
                               
         						<?php 
   								while($area_vendor1 = mysql_fetch_array($vendor1))
								{
								?>
								<option value="<?php echo $area_vendor1[0]; ?>"><?php echo $area_vendor1[1]; }?></option>
      							</select>
                       </div>
                    </div>
                    
</div>
<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								<button type="submit" name="submit" id="submit" class="btn btn-primary">Search</button>
							</div>
                            </form>
						</div><!-- /.modal-content -->
					</div><!-- /.modal-dialog -->
				</div>  
   <script>
    function priceSorter(a, b) {
        a = +a.substring(1); // remove $
        b = +b.substring(1);
        if (a > b) return 1;
        if (a < b) return -1;
        return 0;
    }
</script>
<script>
  
$(document).on('click','.lbl_item',function(){
	var item_id = $(this).attr('itm_id');
	console.log(item_id);
	$.ajax({
			url:"getporeports.php",
			data:{'item_id':item_id},
			type:'POST',
			success:function(data)
			{
				$("#ur_id").html(data);
			}
	});	
	
	$(".btn_open_modal").click();
});
</script>
 <script>
(function(document) {
    'use strict';

    var LightTableFilter = (function(Arr) {

          var _input;

          function _onInputEvent(e) {
              _input = e.target;
              var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
				});
			});
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
		};
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			LightTableFilter.init();
		}
	});

})(document);
</script>

<script>
$.tablesorter.addParser({ 
    id: 'price', 
    is: function(s) { 
        return false; 
    }, 
    format: function(s) { 
        return s.replace(/Free/,0).replace(/ CHF/,""); 
    }, 
    type: 'numeric' 
}); 

$(function() { 
    $("table").tablesorter({ 
        headers: { 
            1: { 
                sorter:'price' 
            } 
        } 
    }); 
});
</script>