<?php
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php"); 
include("header.php"); 

if(isset($_GET['ids']))
{
	if($_GET['process'] == 'accept')
	{
		

	$max_header_result = mysql_query("SELECT MAX(advance_no) FROM rem_advance");
	while($row_id = mysql_fetch_array($max_header_result))
	{
		$max_header = $row_id[0];
	}
		$max_header_id = $max_header;
		$max_header_id++;
		$advance_nos=date("dmYHi")."-".$max_header_id;
		$sql2="INSERT INTO rem_advance(advance_no,advance_nos)
		VALUES
		('$max_header_id','$advance_nos')";
				
				if (!mysql_query($sql2,$con))
          		{
            		die('Error: ' . mysql_error());
          		}
		date_default_timezone_set('Asia/Calcutta');
		
		$time=date("Y-m-d h:i:s");
			
		$max = mysql_query("SELECT payment_date date,payment_order_id order_id,payment_vendor_id vendor,payment_amount amount,payment_type method,payment_description narration,payment_order_type type,display display,payment_by entry,payment_bank bank,payment_capital capital,payment_ledger ledger FROM rem_order_payment_request WHERE payment_id='$_GET[ids]'");
		while($row = mysql_fetch_array($max))
		{
			$date = $row['date'];
			$order_id = $row['order_id'];
			$vendor = $row['vendor'];
			$amount = $row['amount'];
			$method = $row['method'];
			$narration = $row['narration'];
			$type=$row['type'];
			$display = $row['display'];
			$entry = $row['entry'];
			$bank = $row['bank'];
			$capital = $row['capital'];
			$ledger = $row['ledger'];
		}	
			




		$sql="INSERT INTO rem_order_payment(payment_advance_no,payment_date,payment_order_id,payment_vendor_id,payment_amount,payment_type,payment_description,payment_order_type,display,payment_by,payment_approved_by,payment_approved_time,payment_bank,payment_capital,payment_ledger)
		VALUES
('$max_header_id','$date','$order_id','$vendor','$amount','$method','$narration','$type','$display','$entry','$_SESSION[user_name]','$time','$bank','$capital','$ledger')";
 		
		if (!mysql_query($sql,$con))
        {
        	die('Error: ' . mysql_error());
        } 

		mysql_query("DELETE FROM rem_order_payment_request WHERE payment_id='$_GET[ids]'");



			//if it is Expense start here
		if($capital == '2')
		{
			if($type == '2')
  			{
    			$max_outlet = mysql_query("SELECT order_merchant FROM rem_order WHERE order_header_id='$order_id'");
    			while($row_outlet = mysql_fetch_array($max_outlet))
    			{
      				$outlet_id=$row_outlet[0];
    			}
  			}
  			else
  			{
      				$outlet_id='4';
  			}

  			$max_header_result_advance = mysql_query("SELECT MAX(payment_id) FROM rem_order_payment");
			while($row_id_advance = mysql_fetch_array($max_header_result_advance))
			{
				$item_ids = $row_id_advance[0];
			}

			$party_id_result = mysql_query("SELECT party_id  FROM cfms_party_master WHERE party_type_id='$vendor' AND party_type='vendor'");
    		while($row_party = mysql_fetch_array($party_id_result))
    		{
      			$party_ids=$row_party[0];
   			}	

			$current_time = date("Y-m-d h:i:s");
        	$sql="INSERT INTO cfms_expense(exp_category,exp_date,exp_outlet,exp_ledger,exp_party,exp_total,exp_grosstotal,exp_paymethod,exp_bank,exp_description,exp_status,exp_entryby,exp_entytime,exp_adv_id,exp_process,exp_approved_by) VALUES ('expense','$date','$outlet_id','$ledger','$party_ids','$amount','$amount','$method','$bank','$narration','proceed',$_SESSION[user_name]','$current_time','$item_ids','$_SESSION[user_name]','$current_time')";
        	if (!mysql_query($sql,$con))
            {
              die('Error: ' . mysql_error());
            }

		}
		// Expense end here
		
	}
	else
	{
		
		mysql_query("DELETE FROM rem_order_payment_request WHERE payment_id='$_GET[ids]'");
		
	}
}


$query_merchant_assign=mysql_query("SELECT a.payment_id id,a.payment_date date,a.payment_order_id pono,b.vendor_name vendor,a.payment_amount amount,c.method_name pay_method,a.payment_description narration,a.payment_order_type type,a.payment_by entry,d.bank_name bank_name,a.payment_capital capital,e.ledger_name ledger FROM rem_order_payment_request a LEFT JOIN rem_vendor b ON a.payment_vendor_id=b.vendor_id LEFT JOIN rem_payment_method c ON a.payment_type=c.method_id LEFT JOIN cfms_bank_master d ON a.payment_bank=d.bank_id LEFT JOIN cfms_ledger_master e ON a.payment_ledger=e.ledger_id");
		
		
	while($row_item = mysql_fetch_assoc($query_merchant_assign))
		{
			$details_item[] = $row_item;
		}
		
?>


<div class="shadow-lg p-3 mb-1 bg-white rounded" style="position:fixed; width:100%; z-index:9999;">
   <a href="dashboard.php" class="btn btn-success btn-sm">Back</a>
 
</div>
 
 <br/>
<br/>
<br/>



  <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #ddd;
}

th, td {
    padding: 5px;
	font-size:10px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<h2>&nbsp;Advance Approval</h2>

<div >
  <p align="right"><font color="#000000">Smart Search  : &nbsp;</font><input type="search" class="light-table-filter" data-table="table-bordered" placeholder="Filter">&nbsp;&nbsp;</p>    
  </div>
   <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg" style="width:95%; padding-top:100px;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">PO/WO Details</h4>
           <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body ">
                <label id='ur_id'><label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>   
  <button style="display:none" type="button" class="btn btn-info btn-lg btn_open_modal" data-toggle="modal" data-target="#myModal">Open Modal</button>   
<div style="overflow-x:auto;">
  
  <table class="table-bordered">
  <thead>
    <tr>
      <th width="4%">SLNO</th>
      <th width="84%" colspan="2">DATE,ADV NO,VENDOR & NARRATION  </th>
    <th width="12%">ACTION <?php echo $capital; ?></th>

        
    </tr>
    </thead>
    <?php
	$total_Advance=0;
	$counter=0;
	foreach($details_item as $i):	
	$total_Advance+=$i['advance'];			
	?>
    <tr>
      <td width="4%" align="center"><?php echo ++$counter; ?></td>
      <td align="right" width="20%"><font size="1">PAID DATE<br/>PO/WO NO<br/>VENDOR<br/>AMOUNT<br/>BANK<br/>REQUEST BY<br/>NARRATIION<br/>EXPENSE TYPE<?php if($i['capital'] == '2') { ?><br/>LEDGER<?php } ?></font></td>
      <td width="64%"><font size="1"><?php echo date("d-m-Y h:i:a", strtotime($i['date'])) ;?><br/>
        <?php if($i['type'] == '1') { print_r("<font color='#009966'>PO- ".$i['pono']); } else { print_r("<font color='#FF0000'>WO- ".$i['pono']); } ?>
      </font><br/><?php print_r($i['vendor']) ;?><br/><font color="#FF0000"><b>&#8377 <?php  print_r(round($i['amount'], 0)); ?></b></font><br/><?php print_r($i['bank_name']) ;?><br/><?php print_r($i['entry']) ;?><br/><?php print_r($i['narration']) ;?><br/>
      <?php if($i['capital'] == '1') { echo "CAPITAL INVESTMENT"; } else { echo "EXPENSE"; } ?><br/>
      <?php if($i['capital'] == '2') { ?><?php echo $i['ledger']; } ?></font></td>
      
       <td width="12%" align="right"><a href="javascript:confirmApprove('advanceapproval.php?process=accept&ids=<?php print_r($i['id']); ?>')" class="btn btn-success btn-sm">Accept</a>
       <br/><br/><a href="javascript:confirmDelete('advanceapproval.php?process=reject&ids=<?php print_r($i['id']); ?>')" class="btn btn-danger btn-sm">Reject</a></td>
        
       
        
    </tr>
    <?php
	endforeach;
	?>
   
  </table>
</div>

</body>
</html>
<div class="modal fade" id="myModals" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-dialog" style="padding-top:70px;">
						<div class="modal-content">
							<div class="modal-header">
								
								<h2 class="modal-title">Filter</h2>
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div>
							 <form class="form-horizontal" role="form" method="post">
<div class="modal-body">
					 <div class="form-group">
                        <label for="inputLinkPp" class="hidden-xs col-sm-3 control-label">Choose Vendor:</label>
                        <div class="input-group col-sm-8 xs-margin">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
                      	<?php 
								$vendor = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor WHERE vendor_id!='$_GET[vendor]'");
								?>
                             	<select  class="form-control"  name="vendor" id="vendor" onkeydown='if(event.keyCode == 13){document.getElementById("type").focus();return false;}'  >
         						
                                
                                
                                <?php 
								if($_GET['vendor'] == 'ALL')
								{?>
                                <option value="ALL">ALL Vendor..</option>
                                <?php 
								} 
								else
								{
								$vendor6 = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor WHERE vendor_id='$_GET[vendor]'");
								while($area_vendor6 = mysql_fetch_array($vendor6))
								{
								?>
								<option value="<?php echo $area_vendo6r[0]; ?>"><?php echo $area_vendor6[1]; }?></option>
                                 <option value="ALL">ALL Vendor..</option>
                                  <?php } ?>
                               
         						<?php 
   								while($area_vendor = mysql_fetch_array($vendor))
								{
								?>
								<option value="<?php echo $area_vendor[0]; ?>"><?php echo $area_vendor[1]; }?></option>
      							</select>
                       </div>
                    </div>
                   
                  
                    
</div>
<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								<button type="submit" name="submit" id="submit" class="btn btn-primary">Search</button>
							</div>
                            </form>
						</div><!-- /.modal-content -->
					</div><!-- /.modal-dialog -->
				</div>  
   <script>
    function priceSorter(a, b) {
        a = +a.substring(1); // remove $
        b = +b.substring(1);
        if (a > b) return 1;
        if (a < b) return -1;
        return 0;
    }
</script>
<script>
function confirmDelete(delUrl) {
  if (confirm("Are you sure you want to Reject")) {
    document.location = delUrl;
  }
}
</script>
<script>
function confirmApprove(delUrl) {
  if (confirm("Are you sure you want to Approve")) {
    document.location = delUrl;
  }
}
</script> 
<script>
  
$(document).on('click','.lbl_item',function(){
	var item_id = $(this).attr('itm_id');
	console.log(item_id);
	$.ajax({
			url:"getporeports.php",
			data:{'item_id':item_id},
			type:'POST',
			success:function(data)
			{
				$("#ur_id").html(data);
			}
	});	
	
	$(".btn_open_modal").click();
});
</script>
 <script>
(function(document) {
    'use strict';

    var LightTableFilter = (function(Arr) {

          var _input;

          function _onInputEvent(e) {
              _input = e.target;
              var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
				});
			});
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
		};
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			LightTableFilter.init();
		}
	});

})(document);
</script>

<script>
$.tablesorter.addParser({ 
    id: 'price', 
    is: function(s) { 
        return false; 
    }, 
    format: function(s) { 
        return s.replace(/Free/,0).replace(/ CHF/,""); 
    }, 
    type: 'numeric' 
}); 

$(function() { 
    $("table").tablesorter({ 
        headers: { 
            1: { 
                sorter:'price' 
            } 
        } 
    }); 
});
</script>