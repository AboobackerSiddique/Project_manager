<?php
session_start();
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
$d =  $_POST['item_id'];
$details = explode('$',$d);
$item_id = $details[0];
$outlet_id = $details[1];

if($outlet_id == 'ALL')
{
?>
	<table class="table table-bordered" id="table"
               data-toggle="table"
               data-height="460"
               data-sort-name="price"
               data-sort-order="desc" width="100%">
  
      <tr>
       
         <td ><b>SLNO</b></th>
         <td  ><b>OUTLET<br/>MERCHANT</b></td>
        
        <td align="right"><b>ASSIGN</b></td>
        <td align="right"><b>ALOT</b></td>
       <td align="right"><b>BALANCE</b></td>
                  
      </tr>
   
    <tbody>
 <?php
							$result_item = mysql_query("SELECT a.assign_counter counter_id,b.counter_name counter_name,c.merchant_name merchant_name,d.outlet_name outlet_name,a.assign_merchant merchant_id,a.assign_outlet outlet_id FROM rem_counter_assign a LEFT JOIN rem_counter_master b ON a.assign_counter=b.counter_id LEFT JOIN rem_merchant c ON a.assign_merchant=c.merchant_id LEFT JOIN rem_outlet d ON a.assign_outlet=d.outlet_id  ");
							$counter=0;
							while($row_item = mysql_fetch_array($result_item))
  							{ ?>
      <tr>
        <td width="5%"><?php echo ++$counter; ?></td>
        <td width="15%"><?php echo $row_item['outlet_name']; ?><br/><?php echo $row_item['counter_name']."-".$row_item['merchant_name']; ?></td>
    
       
       	<td align="right" width="10%"><?php
	$result = mysql_query("SELECT a.item_name name,b.stock stock,c.sales sales FROM rem_item a LEFT JOIN (SELECT stock_item,SUM(stock_qty) stock FROM rem_stock WHERE stock_to_type='3' AND stock_to_outlet='$row_item[outlet_id]' AND stock_to='$row_item[counter_id]' AND stock_item='$item_id') AS b ON b.stock_item=a.item_id LEFT JOIN (SELECT stock_item,SUM(stock_qty) sales FROM rem_stock WHERE stock_from_type='3' AND stock_from_outlet='$row_item[outlet_id]' AND stock_from='$row_item[counter_id]' AND stock_item='$item_id') AS c ON c.stock_item=a.item_id WHERE a.item_id='$item_id'");
	while($row = mysql_fetch_array($result))
  	{
		$alot=$row['stock']-$row['sales'];
	}
	
	$result1 = mysql_query("SELECT SUM(assign_qty) qty FROM rem_merchant_item_assign WHERE assign_outlet='$row_item[outlet_id]' AND assign_merchant='$row_item[merchant_id]' AND assign_item='$item_id'");
	while($row1 = mysql_fetch_array($result1))
  	{
		echo  $assign=round($row1['qty'],0);
	}
	
	$balance=$assign-$alot;
 		
	 ?></td>
     
      <td align="right" width="10%"><?php echo round($alot,0); ?></td> 
      <td align="right" width="10%"><?php echo $balance; ?></td> 
      </tr>
	<?php
  }
	?>
 </tbody>
  </table>


<?php } else { ?>
<table class="table table-bordered" id="table"
               data-toggle="table"
               data-height="460"
               data-sort-name="price"
               data-sort-order="desc" width="100%">
  
      <tr>
       
         <td ><b>SLNO</b></th>
         <td  ><b>OUTLET<BR/>MERCHANT</b></td>
      >
        <td align="right"><b>ASSIGN</b></td>
        <td align="right"><b>ALOT</b></td>
       <td align="right"><b>BALANCE</b></td>
                  
      </tr>
   
    <tbody>
 <?php
							$result_item = mysql_query("SELECT a.assign_counter counter_id,b.counter_name counter_name,c.merchant_name merchant_name,d.outlet_name outlet_name,a.assign_merchant merchant_id FROM rem_counter_assign a LEFT JOIN rem_counter_master b ON a.assign_counter=b.counter_id LEFT JOIN rem_merchant c ON a.assign_merchant=c.merchant_id LEFT JOIN rem_outlet d ON a.assign_outlet=d.outlet_id  WHERE a.assign_outlet='$outlet_id'");
							$counter=0;
							while($row_item = mysql_fetch_array($result_item))
  							{ ?>
      <tr>
        <td width="5%"><?php echo ++$counter; ?></td>
        <td width="15%"><?php echo $row_item['outlet_name']; ?><br/><?php echo $row_item['counter_name']."-".$row_item['merchant_name']; ?></td>
     
       
       	<td align="right" width="10%"><?php
	$result = mysql_query("SELECT a.item_name name,b.stock stock,c.sales sales FROM rem_item a LEFT JOIN (SELECT stock_item,SUM(stock_qty) stock FROM rem_stock WHERE stock_to_type='3' AND stock_to_outlet='$outlet_id' AND stock_to='$row_item[counter_id]' AND stock_item='$item_id') AS b ON b.stock_item=a.item_id LEFT JOIN (SELECT stock_item,SUM(stock_qty) sales FROM rem_stock WHERE stock_from_type='3' AND stock_from_outlet='$outlet_id' AND stock_from='$row_item[counter_id]' AND stock_item='$item_id') AS c ON c.stock_item=a.item_id WHERE a.item_id='$item_id'");
	while($row = mysql_fetch_array($result))
  	{
		$alot=$row['stock']-$row['sales'];
	}
	
	$result1 = mysql_query("SELECT SUM(assign_qty) qty FROM rem_merchant_item_assign WHERE assign_outlet='$outlet_id' AND assign_merchant='$row_item[merchant_id]' AND assign_item='$item_id'");
	while($row1 = mysql_fetch_array($result1))
  	{
		echo  $assign=round($row1['qty'],0);
	}
	
	$balance=$assign-$alot;
 		
	 ?></td>
     
      <td align="right" width="10%"><?php echo round($alot,0); ?></td> 
      <td align="right" width="10%"><?php echo $balance; ?></td> 
      </tr>
	<?php
  }
	?>
 </tbody>
  </table>
  <?php } ?>