<?php
ob_start();
error_reporting(E_ERROR | E_PARSE);
session_start();
include("header.php"); 
include("dbconnection.php"); 
$_SESSION["user_id"] =$_GET['userid'];
$_SESSION["user_name"] =$_GET['username'];
$_SESSION["pass_word"] =$_GET['password'];
$_SESSION["user_type"] = $_GET['usertype'];
$_SESSION["user_outlet"] = $_GET['user_outlet'];
?>
 <style> 
 body, html {
    height: 100%;
    margin: 0;
}

.bg {
    /* The image used */
    background-image: url("img/bg.jpg");

    /* Full height */
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
	
}
.start {
 position: absolute;
     margin: auto;
     top: 0;
     right: 0;
     bottom: 0;
     left: 0;
     width: 100%;
     height: 100%;

} 

.btn {
  background-color: #F9F9F9;
  width:100%;
  border: none;
  color: black;
  padding: 16px 32px;
  text-align: center;
  font-size: 14px;
  margin:2px;
  transition: 0.3s;
}

.btn:hover {
  background-color: #B92626;
  color: white;
}
</style>


<div class="shadow-lg p-3 mb-1 bg-white rounded" style="position:fixed; width:100%; z-index:9999;">
   PROJECT MANAGER
 
</div>
 
	<div class="bg">
	<div class="start">
	<center>
	<br/><br/><br/><br/>
	<div class="form-group col-md-6">
   
   <?php if($_SESSION["user_name"] == 'junaiz' || $_SESSION["user_name"] == 'Junaiz' || $_SESSION["user_name"] == 'Z'  || $_SESSION["user_name"] == 'z'|| $_SESSION["user_name"] == 'firdos' || $_SESSION["user_name"] == 'Firdos' || $_SESSION["user_name"] == 'admin') 
	{ ?>
   <a href="poapprove.php" class="btn" >PO/WO Approval   (<b><font color="#FF0000"><?php $resultlogin = mysql_query("SELECT COUNT(*) FROM rem_order WHERE order_process='1'");
	while($row = mysql_fetch_array($resultlogin))
	{
		if($row[0] == '0')
		{
			echo "0";
		}
		else
		{
			echo $row[0];
		}; 
	} ?></font></b>)</a>
   <?php  }  ?>
   <?php if($_SESSION["user_name"] == 'junaiz' || $_SESSION["user_name"] == 'Junaiz' || $_SESSION["user_name"] == 'Z'  || $_SESSION["user_name"] == 'z'|| $_SESSION["user_name"] == 'firdos' || $_SESSION["user_name"] == 'Firdos' || $_SESSION["user_name"] == 'admin') 
	{?>
   <a href="advanceapproval.php" class="btn" >Advance Payment Approval   (<b><font color="#FF0000"><?php $resultlogina = mysql_query("SELECT COUNT(*) FROM rem_order_payment_request");
	while($rowa = mysql_fetch_array($resultlogina))
	{
		if($rowa[0] == '0')
		{
			echo "0";
		}
		else
		{
			echo $rowa[0];
		}; 
	} ?></font></b>)</a>
   <?php  }  ?>

    <?php if($_SESSION["user_name"] == 'junaiz' || $_SESSION["user_name"] == 'Junaiz' || $_SESSION["user_name"] == 'Z'  || $_SESSION["user_name"] == 'z'|| $_SESSION["user_name"] == 'firdos' || $_SESSION["user_name"] == 'Firdos' || $_SESSION["user_name"] == 'admin') 
	{?>
   <a href="newmerchantapproval.php" class="btn" >New Registered Merchant Approval  (<b><font color="#FF0000"><?php $resultlogins = mysql_query("SELECT COUNT(*) FROM rem_merchant_register WHERE merchant_process='0'");
	while($rown = mysql_fetch_array($resultlogins))
	{
		if($rown[0] == '0')
		{
			echo "0";
		}
		else
		{
			echo $rown[0];
		}; 
	} ?></font></b>)</a>
   <?php  }  ?>

    <?php if($_SESSION["user_name"] == 'junaiz' || $_SESSION["user_name"] == 'Junaiz' || $_SESSION["user_name"] == 'Z'  || $_SESSION["user_name"] == 'z'|| $_SESSION["user_name"] == 'firdos' || $_SESSION["user_name"] == 'Firdos' || $_SESSION["user_name"] == 'admin') 
	{?>
   <a href="onboardingmerchantapproval.php" class="btn" >Onboarding Merchant Approval  (<b><font color="#FF0000"><?php $resultlogins = mysql_query("SELECT COUNT(*) FROM rem_merchant_outlet_assign WHERE assign_process='2'");
	while($rown = mysql_fetch_array($resultlogins))
	{
		if($rown[0] == '0')
		{
			echo "0";
		}
		else
		{
			echo $rown[0];
		}; 
	} ?></font></b>)</a>
   <?php  }  ?>
   
      <!--  <a href="poapprove.php" class="btn" >PO/WO Approval   (<b><font color="#FF0000"><?php $resultlogin = mysql_query("SELECT COUNT(*) FROM rem_order WHERE order_process='1'");
	while($row = mysql_fetch_array($resultlogin))
	{
		if($row[0] == '0')
		{
			echo "0";
		}
		else
		{
			echo $row[0];
		}; 
	} ?></font></b>)</a> 
     <a href="advanceapproval.php" class="btn" >Advance Payment Approval   (<b><font color="#FF0000"><?php $resultlogina = mysql_query("SELECT COUNT(*) FROM rem_order_payment_request");
	while($rowa = mysql_fetch_array($resultlogina))
	{
		if($rowa[0] == '0')
		{
			echo "0";
		}
		else
		{
			echo $rowa[0];
		}; 
	} ?></font></b>)</a>  -->    
                <a href="itemquote.php" class="btn">Item Quotation Reports</a>
            	<a href="poreports.php?vendor=ALL&type=ALL" class="btn">PO/WO Reports</a>
                <a href="advancereports.php?vendor=ALL" class="btn">Advance Paid Reports</a>
                <a href="itemwisereports.php" class="btn">Itemwise Reports</a> 
            	<a href="deliverypending.php?vendor=ALL" class="btn">WORK / ITEM Pending Reports</a>
                
            	<a href="balancereports.php?outlet=ALL" class="btn">Outlet Item	 Excess Reports</a>
                <a href="merchantreport.php?outlet=1&merchant=1" class="btn">Merchantwise Item Excess Report</a>
                <a href="itemrequiredlist.php" class="btn">Item Required List Report</a>
                   <a href="merchantstatusupdate.php?outlet=1" class="btn">Merchant Status Update Report</a>
                    <a href="merchantalotlist.php?outlet=1&merchant=1" class="btn">Merchantwise Item Aloted Report</a>
                    <a href="warehousestock.php?outlet=ALL" class="btn">Warehouse Live Stock Reports</a>
                      <a href="barcode.php?outlet=1&merchant=1" class="btn">Outlet/Merchant  Alloted Barcode Reports</a>
                       <a href="liveworkreports.php?vendor=ALL&outlet=ALL" class="btn">Work Status Reports</a>
                       <a href="merchantstatus.php?outlet=1" class="btn">Merchant Live Status</a>
                       <a href="findbarcode.php" class="btn">Barcode Status</a>
    </div>	
    </div>	
	</center>
	</div>
	</div>