<?php
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php"); 
include("header.php"); 
$_SESSION["user_id"] =$_GET['userid'];
$_SESSION["user_name"] =$_GET['username'];
$_SESSION["pass_word"] =$_GET['password'];
$_SESSION["user_type"] = $_GET['usertype'];
$_SESSION["user_outlet"] = $_GET['user_outlet'];
if(isset($_POST["submit"]))
{
	header("Location: merchantstatus.php?outlet=$_POST[outlet]");
}

$query_item=mysql_query("SELECT a.merchant_id merchant_id,a.merchant_name merchant_name,b.assign_counter counter_no,c.status status,d.cuisine_name cuisine,b.assign_size size FROM rem_merchant a LEFT JOIN (SELECT assign_merchant,assign_outlet,assign_counter,assign_cuisine,assign_size FROM rem_counter_assign WHERE assign_outlet='$_GET[outlet]') AS b ON b.assign_merchant=a.merchant_id LEFT JOIN (SELECT j.assign_status,k.status_name status,j.assign_outlet,j.assign_merchant,j.assign_category FROM rem_merchant_category_assign j LEFT JOIN rem_status_master k ON j.assign_status=k.status_id WHERE j.assign_outlet='$_GET[outlet]' AND j.assign_category='17') AS c ON c.assign_merchant=a.merchant_id LEFT JOIN rem_cuisine_master d ON b.assign_cuisine = d.cuisine_id WHERE a.merchant_id IN (SELECT assign_merchant FROM rem_counter_assign WHERE assign_outlet='$_GET[outlet]') AND a.merchant_type=0 ORDER BY b.assign_counter ASC");
		while($row_item = mysql_fetch_assoc($query_item))
		{
			$details_item[] = $row_item;
		}
		
$result = mysql_query("SELECT outlet_name FROM rem_outlet WHERE outlet_id='$_GET[outlet]'");
	while($row = mysql_fetch_array($result))
  	{
 		$outlet_name=$row[0];
	}		
?>


<div class="shadow-lg p-3 mb-1 bg-white rounded" style="position:fixed; width:100%; z-index:9999;">
   <a href="merchantstatus.php" class="btn btn-success btn-sm">Back</a>
 
</div>
 
 <br/>
<br/>
<br/>



  <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #ddd;
}

th, td {
    padding: 5px;
	font-size:10px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<h2>&nbsp;Merchant Live Status&nbsp;&nbsp;  <a data-toggle="modal" href="#myModals" style="background-color:#666;" class="btn btn-success btn-sm"><i class="fa fa-filter"></i> More Filter</a> </h2>
<center><h4>OUTLET : <?php echo $outlet_name; ?></h4></center>
<div >
  <p align="right"><font color="#000000">Smart Search  : &nbsp;</font><input type="search" class="light-table-filter" data-table="table-bordered" placeholder="Filter">&nbsp;&nbsp;</p>    
  </div>
   <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg" style="width:95%; padding-top:100px;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Merchant Status</h4>
           <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body ">
                <label id='ur_id'><label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>   
  <button style="display:none" type="button" class="btn btn-info btn-lg btn_open_modal" data-toggle="modal" data-target="#myModal">Open Modal</button>   
<div style="overflow-x:auto;">
  
  
<table class="table-bordered">
  <thead>
    <tr>
      <th width="5%">SLNO</th>
       <th width="5%">C.NO</th>
       <th width="40%">MERCHANT NAME</th>
     
      <th width="20%">TYPE</th>
      <th width="10%">SIZE</th>
       <th width="20%">STATUS</th>
    </tr>
    </thead>
    <?php
	$counter=0;
	foreach($details_item as $i):				
	?>
    <tr>
      <td><?php echo ++$counter; ?></td>
      <td align="center"><?php print_r($i['counter_no']) ;?></td>
      <td><b><?php print_r($i['merchant_name']) ;?></b></td>
      
      <td align="center"><?php print_r($i['cuisine']); ?></td>
      <td align="center"><?php print_r($i['size']); ?></td>
      <td align="center"><b><?php if($i['status'] == 'LIVE') { echo "<font color='#009933'>LIVE</font>"; } else { echo "<font color='#FF0000'>$i[status]</font>"; } ?></b></td>
    </tr>
    <?php
	endforeach;
	?>
  </table>
</div>

</body>
</html>
<div class="modal fade" id="myModals" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-dialog" style="padding-top:70px;">
						<div class="modal-content">
							<div class="modal-header">
								
								<h2 class="modal-title">Filter</h2>
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div>
							 <form class="form-horizontal" role="form" method="post">
<div class="modal-body">
					
                     <div class="form-group">
                        <label for="inputLinkPp" class="hidden-xs col-sm-3 control-label">Choose Outlet:</label>
                        <div class="input-group col-sm-8 xs-margin">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
                      <?php 
								$vendor = mysql_query("SELECT outlet_id,outlet_name FROM rem_outlet WHERE outlet_id!='$_GET[outlet]'");
								?>
		<select  class="form-control"  name="outlet" id="outlet" onkeydown='if(event.keyCode == 13){document.getElementById("type").focus();return false;}'  >
        <?php 
								
								$vendor6 = mysql_query("SELECT outlet_id,outlet_name FROM rem_outlet WHERE outlet_id='$_GET[outlet]'");
								while($area_vendor6 = mysql_fetch_array($vendor6))
								{
								?>
		  <option value="<?php echo $area_vendo6r[0]; ?>"><?php echo $area_vendor6[1]; }?></option>
           			
		  <?php 
   								while($area_vendor = mysql_fetch_array($vendor))
								{
								?>
		  <option value="<?php echo $area_vendor[0]; ?>"><?php echo $area_vendor[1]; }?></option>
	    </select>
                       </div>
                    </div>
                    
</div>
<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								<button type="submit" name="submit" id="submit" class="btn btn-primary">Search</button>
							</div>
                            </form>
						</div><!-- /.modal-content -->
					</div><!-- /.modal-dialog -->
				</div>  
   <script>
    function priceSorter(a, b) {
        a = +a.substring(1); // remove $
        b = +b.substring(1);
        if (a > b) return 1;
        if (a < b) return -1;
        return 0;
    }
</script>
<script>
  
$(document).on('click','.lbl_item',function(){
	var item_id = $(this).attr('itm_id');
	console.log(item_id);
	$.ajax({
			url:"getmerchantstatus.php",
			data:{'item_id':item_id},
			type:'POST',
			success:function(data)
			{
				$("#ur_id").html(data);
			}
	});	
	
	$(".btn_open_modal").click();
});
</script>
 <script>
(function(document) {
    'use strict';

    var LightTableFilter = (function(Arr) {

          var _input;

          function _onInputEvent(e) {
              _input = e.target;
              var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
				});
			});
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
		};
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			LightTableFilter.init();
		}
	});

})(document);
</script>

<script>
$.tablesorter.addParser({ 
    id: 'price', 
    is: function(s) { 
        return false; 
    }, 
    format: function(s) { 
        return s.replace(/Free/,0).replace(/ CHF/,""); 
    }, 
    type: 'numeric' 
}); 

$(function() { 
    $("table").tablesorter({ 
        headers: { 
            1: { 
                sorter:'price' 
            } 
        } 
    }); 
});
</script>