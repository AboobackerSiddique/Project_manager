<?php
ob_start();
error_reporting(E_ERROR | E_PARSE);
session_start();
include("header.php"); 
include("dbconnection.php"); 
?>
 <style> 
 body, html {
    height: 100%;
    margin: 0;
}

.bg {
    /* The image used */
    background-image: url("img/bg.jpg");

    /* Full height */
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
	
}
.start {
 position: absolute;
     margin: auto;
     top: 0;
     right: 0;
     bottom: 0;
     left: 0;
     width: 100%;
     height: 100%;

} 

.btn {
  background-color: #F9F9F9;
  width:100%;
  border: none;
  color: black;
  padding: 16px 32px;
  text-align: center;
  font-size: 14px;
  margin:2px;
  transition: 0.3s;
}

.btn:hover {
  background-color: #B92626;
  color: white;
}
</style>


<div class="shadow-lg p-3 mb-1 bg-white rounded" style="position:fixed; width:100%; z-index:9999;">
   <a href="../index.php" >Home</a> | PROJECT MANAGER
 
</div>
 
	<div class="bg">
	<div class="start">
	<center>
	<br/><br/><br/><br/>
	<div class="form-group col-md-6">
  <?php if($_SESSION["user_name"] == 'junaiz' || $_SESSION["user_name"] == 'Junaiz' || $_SESSION["user_name"] == 'firdos' || $_SESSION["user_name"] == 'Firdos' || $_SESSION["user_name"] == 'admin') 
	{ ?>
   <a href="poapprove.php" class="btn" >PO/WO Approval   (<b><font color="#FF0000"><?php $resultlogin = mysql_query("SELECT COUNT(*) FROM rem_order WHERE order_process='1'");
	while($row = mysql_fetch_array($resultlogin))
	{
		if($row[0] == '0')
		{
			echo "0";
		}
		else
		{
			echo $row[0];
		}; 
	} ?></font></b>)</a>
   <?php  }  ?>
  
              
                <a href="itemquote.php" class="btn"><?php echo $_SESSION["user_name"]; ?>Item Quotation Reports</a> 
            	<a href="poreports.php?vendor=ALL&type=ALL" class="btn">PO/WO Reports</a>
                <a href="advancereports.php?vendor=ALL" class="btn">Advance Paid Reports</a>
                <a href="itemwisereports.php" class="btn">Itemwise Reports</a> 
            	<a href="deliverypending.php" class="btn">Delivery Pending Reports</a>
                
            	<a href="balancereports.php?outlet=ALL" class="btn">Outlet Item	 Excess Reports</a>
                <a href="merchantreport.php?outlet=1&merchant=1" class="btn">Merchantwise Item Excess Report</a>
                <a href="itemrequiredlist.php" class="btn">Item Required List Report</a>
                   <a href="merchantstatusupdate.php?outlet=1" class="btn">Merchant Status Update Report</a>
                    <a href="merchantalotlist.php?outlet=1&merchant=1" class="btn">Merchantwise Item Aloted Report</a>
    </div>	
	</center>
	</div>
	</div>