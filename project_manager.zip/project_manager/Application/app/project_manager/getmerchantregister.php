
<?php
ob_start();
session_start();
include("dbconnection.php");
error_reporting(E_ERROR | E_PARSE);// set time-out period (in seconds)
$d =  $_POST['item_id'];
$details = explode('$',$d);
$header_id = $details[0];

  $query_merchant_assign=mysql_query("SELECT a.merchant_id id,a.merchant_brand brand_name,a.merchant_trade trade_name,a.merchant_established established,a.merchant_promoter promoter,a.merchant_contact_person contact_person,a.merchant_contact_no contact_no,a.merchant_email email,a.merchant_no_of_branches no_of_branch,a.merchant_ratings ratings,a.merchant_turnover turnover,a.merchant_orders no_of_order,b.cuisine_name cuisine,c.segment_name segment,a.merchant_menu_pricing pricing,a.merchant_timings timings,a.merchant_zomato zomato,a.merchant_message message,d.name state,e.name cities,a.merchant_mobile1 mobile1,a.merchant_email1 email1,a.merchant_type type FROM rem_merchant_register a
  LEFT JOIN rem_cuisine_master b ON a.merchant_cuisine = b.cuisine_id
  LEFT JOIN rem_segment_master c ON a.merchant_segment = c.segment_id
  LEFT JOIN states d ON a.merchant_state = d.id
  LEFT JOIN cities e ON a.merchant_cities = e.id
  WHERE a.merchant_id='$header_id'");
  while($row_item = mysql_fetch_array($query_merchant_assign))
  {
      $id=$row_item['id'];
      $brand_name=$row_item['brand_name'];
      $trade_name=$row_item['trade_name'];
      $established=$row_item['established'];
      $promoter=$row_item['promoter'];
      $contact_person=$row_item['contact_person'];
      $contact_no=$row_item['contact_no'];
      $email=$row_item['email'];
      $no_of_branch=$row_item['no_of_branch'];
      $ratings=$row_item['ratings'];
      $turnover=$row_item['turnover'];
      $no_of_order=$row_item['no_of_order'];
      $cuisine=$row_item['cuisine'];
      $segment=$row_item['segment'];
      $pricing=$row_item['pricing'];
      $timings=$row_item['timings'];
      $zomato=$row_item['zomato'];
      $message=$row_item['message'];
      $state=$row_item['state'];
      $cities=$row_item['cities'];
      $types=$row_item['type'];
      $email1=$row_item['email1'];
      $mobile1=$row_item['mobile1'];

  }


?>

<table class="table table-bordered" id="table"
               data-toggle="table"
               data-height="460"
               data-sort-name="price"
               data-sort-order="desc" width="100%">
  
    <tbody>
	
			<tr>
        	<td width="50%" id="smallfont"><font size="2">Brand Name :</font></td>
        	<td width="50%" id="smallfont" align="right"><font size="2"><?php echo $brand_name; ?></font></td>
     	</tr>

        <tr>
          <td width="50%" id="smallfont"><font size="2">Trade Name :</font></td>
          <td width="50%" id="smallfont" align="right"><font size="2"><?php echo $trade_name; ?></font></td>
      </tr>

        <tr>
          <td width="50%" id="smallfont"><font size="2">State:</font></td>
          <td width="50%" id="smallfont" align="right"><font size="2"><?php echo $state; ?></font></td>
      </tr>
        <tr>
          <td width="50%" id="smallfont"><font size="2">City :</font></td>
          <td width="50%" id="smallfont" align="right"><font size="2"><?php echo $city; ?></font></td>
      </tr>
        <tr>
          <td width="50%" id="smallfont"><font size="2">Established From :</font></td>
          <td width="50%" id="smallfont" align="right"><font size="2"><?php echo $established; ?></font></td>
      </tr>

        <tr>
          <td width="50%" id="smallfont"><font size="2">Brand Promoters Name :</font></td>
          <td width="50%" id="smallfont" align="right"><font size="2"><?php echo $promoter; ?></font></td>
      </tr>

        <tr>
          <td width="50%" id="smallfont"><font size="2">Contact Person :</font></td>
          <td width="50%" id="smallfont" align="right"><font size="2"><?php echo $contact_person; ?></font></td>
      </tr>

        <tr>
          <td width="50%" id="smallfont"><font size="2">Contact Number:</font></td>
          <td width="50%" id="smallfont" align="right"><font size="2"><?php echo $contact_no; ?></font></td>
      </tr>

        <tr>
          <td width="50%" id="smallfont"><font size="2">Email-ID :</font></td>
          <td width="50%" id="smallfont" align="right"><font size="2"><?php echo $email; ?></font></td>
      </tr>
       <tr>
          <td width="50%" id="smallfont"><font size="2">Alternate Contact Number:</font></td>
          <td width="50%" id="smallfont" align="right"><font size="2"><?php echo $mobile1; ?></font></td>
      </tr>

        <tr>
          <td width="50%" id="smallfont"><font size="2">Alternate Email-ID :</font></td>
          <td width="50%" id="smallfont" align="right"><font size="2"><?php echo $email1; ?></font></td>
      </tr>

        <tr>
          <td width="50%" id="smallfont"><font size="2">Branches in India :</font></td>
          <td width="50%" id="smallfont" align="right"><font size="2"><?php echo $no_of_branch; ?></font></td>
      </tr>

        <tr>
          <td width="50%" id="smallfont"><font size="2">Brand Ratings :</font></td>
          <td width="50%" id="smallfont" align="right"><font size="2"><?php echo $ratings; ?></font></td>
      </tr>

        <tr>
          <td width="50%" id="smallfont"><font size="2">Turnover :</font></td>
          <td width="50%" id="smallfont" align="right"><font size="2"><?php echo $turnover; ?></font></td>
      </tr>

        <tr>
          <td width="50%" id="smallfont"><font size="2">Orders Per Outlet  :</font></td>
          <td width="50%" id="smallfont" align="right"><font size="2"><?php echo $no_of_order; ?></font></td>
      </tr>

     

        <tr>
          <td width="50%" id="smallfont"><font size="2">Cuisine Type :</font></td>
          <td width="50%" id="smallfont" align="right"><font size="2"><?php echo $cuisine; ?></font></td>
      </tr>

        <tr>
          <td width="50%" id="smallfont"><font size="2">Segement Type:</font></td>
          <td width="50%" id="smallfont" align="right"><font size="2"><?php echo $segment; ?></font></td>
      </tr>

        <tr>
          <td width="50%" id="smallfont"><font size="2">Menu Pricing :</font></td>
          <td width="50%" id="smallfont" align="right"><font size="2"><?php echo $pricing; ?></font></td>
      </tr> 

      <tr>
          <td width="50%" id="smallfont"><font size="2">Operation Timings:</font></td>
          <td width="50%" id="smallfont" align="right"><font size="2"><?php echo $timings; ?></font></td>
      </tr> 

      <tr>
          <td width="50%" id="smallfont"><font size="2">Message:</font></td>
          <td width="50%" id="smallfont" align="right"><font size="2"><?php echo $message; ?></font></td>
      </tr>

      <tr>
          <td width="50%" id="smallfont"><font size="2">Consider as a:</font></td>
          <td width="50%" id="smallfont" align="right"><font size="2"><?php if($type == '1'){ echo "OUTLET"; } else { echo "MERCHANT"; } ?></font></td>
      </tr>
				
 </tbody>
  </table>
