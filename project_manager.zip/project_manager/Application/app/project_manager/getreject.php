<?php
session_start();
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
$d =  $_POST['item_id'];
$details = explode('$',$d);
$order_id = $details[0];
$order_type = $details[1];

?>
<form method="post">
  <div class="form-group">
                        <label for="inputLinkPp" class="hidden-xs col-sm-3 control-label">Reject Reason:</label>
                        <div class="input-group col-sm-8 xs-margin">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
                           <input type="hidden" name="order_id" id="order_id" value="<?php echo $order_id; ?>" >
                            <input type="hidden" name="order_type" id="order_type" value="<?php echo $order_type; ?>" >
                           <textarea class="form-control" rows="4"  cols="80" name="message" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("submit").focus();return false;}' id="message" required="required" placeholder="Enter Reason "></textarea>
                        </div>
                    </div>
</div>
<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								<button type="submit" name="submit" id="submit" class="btn btn-danger">Reject</button>
							</div></div>
</form>