<?php
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php"); 
include("header.php"); 

if(isset($_POST["submit"]))
{
	header("Location: warehousestock.php?outlet=$_POST[outlet]");
}		
	
	
	/*if($_GET['outlet'] == 'ALL')
	{
		$query_item=mysql_query("SELECT a.item_id item_id,a.item_name item_name,b.cat_name item_category,c.stock stock,d.sales sales,e.transfer transfer FROM rem_item a LEFT JOIN rem_vendor_category b ON a.item_category=b.cat_id LEFT JOIN (SELECT stock_item,SUM(stock_qty) stock FROM rem_stock WHERE stock_to_type=2 AND stock_from_type=1 AND stock_to='6' GROUP BY stock_item) AS c ON c.stock_item = a.item_id LEFT JOIN (SELECT stock_item,SUM(stock_qty) sales FROM rem_stock WHERE stock_from_type=2 AND stock_from='6' GROUP BY stock_item) AS d ON d.stock_item = a.item_id LEFT JOIN (SELECT stock_item,SUM(stock_qty) transfer FROM rem_stock WHERE stock_to_type=2 AND stock_from_type!=1 AND stock_to='6' GROUP BY stock_item) AS e ON e.stock_item = a.item_id WHERE a.item_id IN (SELECT stock_item FROM rem_stock WHERE stock_to_type=2 AND stock_to='6' GROUP BY stock_item) ORDER BY a.item_category ASC");
	}
	else
	{
		$query_item=mysql_query("SELECT a.item_id item_id,a.item_name item_name,b.cat_name item_category,c.stock stock,d.sales sales,e.transfer transfer FROM rem_item a LEFT JOIN rem_vendor_category b ON a.item_category=b.cat_id LEFT JOIN (SELECT stock_item,SUM(stock_qty) stock FROM rem_stock WHERE stock_to_type=2 AND stock_from_type=1 AND stock_to='6' GROUP BY stock_item) AS c ON c.stock_item = a.item_id LEFT JOIN (SELECT stock_item,SUM(stock_qty) sales FROM rem_stock WHERE stock_from_type=2 AND stock_from='6' GROUP BY stock_item) AS d ON d.stock_item = a.item_id LEFT JOIN (SELECT stock_item,SUM(stock_qty) transfer FROM rem_stock WHERE stock_to_type=2 AND stock_from_type!=1 AND stock_to='6' GROUP BY stock_item) AS e ON e.stock_item = a.item_id WHERE a.item_id IN (SELECT stock_item FROM rem_stock WHERE stock_to_type=2 AND stock_to='6' GROUP BY stock_item) AND a.item_category='$_GET[outlet]' ORDER BY a.item_category ASC");
	} */
	
	if($_GET['outlet'] == 'ALL')
	{
		$query_item=mysql_query("SELECT a.stock_item item_id,SUM(a.stock_qty) stock,b.item_name item_name,d.sales sales,e.transfer transfer FROM rem_stock a JOIN rem_item b ON a.stock_item=b.item_id LEFT JOIN (SELECT stock_item,SUM(stock_qty) sales FROM rem_stock WHERE stock_from_type=2 AND stock_from='6' GROUP BY stock_item) AS d ON d.stock_item = a.stock_item LEFT JOIN (SELECT stock_item,SUM(stock_qty) transfer FROM rem_stock WHERE stock_to_type=2 AND stock_from_type!=1 AND stock_to='6' GROUP BY stock_item) AS e ON e.stock_item = a.stock_item WHERE a.stock_to_type=2 AND a.stock_from_type=1 AND a.stock_to='6' GROUP BY a.stock_item ORDER BY b.item_category ");
	}
	else
	{
		$query_item=mysql_query("SELECT a.stock_item item_id,SUM(a.stock_qty) stock,b.item_name item_name,d.sales sales,e.transfer transfer FROM rem_stock a JOIN rem_item b ON a.stock_item=b.item_id LEFT JOIN (SELECT stock_item,SUM(stock_qty) sales FROM rem_stock WHERE stock_from_type=2 AND stock_from='6' GROUP BY stock_item) AS d ON d.stock_item = a.stock_item LEFT JOIN (SELECT stock_item,SUM(stock_qty) transfer FROM rem_stock WHERE stock_to_type=2 AND stock_from_type!=1 AND stock_to='6' GROUP BY stock_item) AS e ON e.stock_item = a.stock_item WHERE a.stock_to_type=2 AND a.stock_from_type=1 AND a.stock_to='6' AND b.item_category='$_GET[outlet]' GROUP BY a.stock_item ORDER BY b.item_category");
	}

	while($row_item = mysql_fetch_assoc($query_item))
	{
		$details_item[] = $row_item;
	}
?>


<div class="shadow-lg p-3 mb-1 bg-white rounded" style="position:fixed; width:100%; z-index:9999;">
   <a href="dashboard.php" class="btn btn-success btn-sm">Back</a>
 
</div>
 
 <br/>
<br/>
<br/>



  <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #ddd;
}

th, td {
    padding: 5px;
	font-size:10px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<h2>&nbsp;Warehouse Stock&nbsp;&nbsp;  <a data-toggle="modal" href="#myModals" style="background-color:#666;" class="btn btn-success btn-sm"><i class="fa fa-filter"></i> More Filter</a></h2>

<div >
  <p align="right"><font color="#000000">Smart Search  : &nbsp;</font><input type="search" class="light-table-filter" data-table="table-bordered" placeholder="Filter">&nbsp;&nbsp;</p>    
  </div>
 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg" style="width:95%; padding-top:100px;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Choose Outlet</h4>
           <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body ">
                <label id='ur_id'><label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>   
  <button style="display:none" type="button" class="btn btn-info btn-lg btn_open_modal" data-toggle="modal" data-target="#myModal">Open Modal</button> 
<div style="overflow-x:auto;">
  
  <table class="table-bordered">
  <thead>
    <tr>
      <th width="5%">SLNO</th>
      <th width="71%">ITEM NAME</th>
      <th width="8%">RECVD</th>
      <th width="8%">TRNFRD</th>
       <th width="8%">BAL</th>

    </tr>
    </thead>
    <?php
	$counter=0;
	foreach($details_item as $i):				
	?>
    <tr>
      <td><?php echo ++$counter; ?></td>
      <td><?php print_r($i['item_name']) ;?></td>
     	<td align="center"><b><?php print_r($stock=round($i['stock'],0)) ;?></b></td>
      <td align="center"><b><?php print_r($ordered=round($i['sales']-$i['transfer'],0)) ;?></b></td>
        <td align="center"><b><?php print_r($delivered=round($i['stock']+$i['transfer']-$i['sales'],0)) ;?></b></td>
        
    </tr>
    <?php
	endforeach;
	?>
  </table>
  <div class="modal fade" id="myModals" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-dialog" style="padding-top:70px;">
						<div class="modal-content">
							<div class="modal-header">
								
								<h2 class="modal-title">Filter</h2>
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div>
							 <form class="form-horizontal" role="form" method="post">
<div class="modal-body">
					
                     <div class="form-group">
                        <label for="inputLinkPp" class="hidden-xs col-sm-3 control-label">Choose Category:</label>
                        <div class="input-group col-sm-8 xs-margin">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
                      <?php 
								$vendor = mysql_query("SELECT cat_id,cat_name FROM rem_vendor_category WHERE cat_id!='$_GET[outlet]'");
								?>
		<select  class="form-control"  name="outlet" id="outlet" onkeydown='if(event.keyCode == 13){document.getElementById("type").focus();return false;}'  >
        <?php 
								if($_GET['outlet'] == 'ALL')
								{?>
                                <option value="ALL">ALL Category..</option>
                                <?php 
								} 
								else
								{
								$vendor6 = mysql_query("SELECT cat_id,cat_name FROM rem_vendor_category WHERE cat_id='$_GET[outlet]'");
								while($area_vendor6 = mysql_fetch_array($vendor6))
								{
								?>
		  <option value="<?php echo $area_vendo6r[0]; ?>"><?php echo $area_vendor6[1]; }?></option>
           				<option value="ALL">ALL Category..</option>
                      <?php  }?>
		  <?php 
   								while($area_vendor = mysql_fetch_array($vendor))
								{
								?>
		  <option value="<?php echo $area_vendor[0]; ?>"><?php echo $area_vendor[1]; }?></option>
	    </select>
                       </div>
                    </div>
                    
</div>
<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								<button type="submit" name="submit" id="submit" class="btn btn-primary">Search</button>
							</div>
                            </form>
						</div><!-- /.modal-content -->
					</div><!-- /.modal-dialog -->
				</div>  
</div>

</body>
</html>
   <script>
    function priceSorter(a, b) {
        a = +a.substring(1); // remove $
        b = +b.substring(1);
        if (a > b) return 1;
        if (a < b) return -1;
        return 0;
    }
</script>
<script>
  
$(document).on('click','.lbl_item',function(){
	var item_id = $(this).attr('itm_id');
	console.log(item_id);
	$.ajax({
			url:"getitemwisereports.php",
			data:{'item_id':item_id},
			type:'POST',
			success:function(data)
			{
				$("#ur_id").html(data);
			}
	});	
	
	$(".btn_open_modal").click();
});
</script>
 <script>
(function(document) {
    'use strict';

    var LightTableFilter = (function(Arr) {

          var _input;

          function _onInputEvent(e) {
              _input = e.target;
              var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
				});
			});
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
		};
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			LightTableFilter.init();
		}
	});

})(document);
</script>

<script>
$.tablesorter.addParser({ 
    id: 'price', 
    is: function(s) { 
        return false; 
    }, 
    format: function(s) { 
        return s.replace(/Free/,0).replace(/ CHF/,""); 
    }, 
    type: 'numeric' 
}); 

$(function() { 
    $("table").tablesorter({ 
        headers: { 
            1: { 
                sorter:'price' 
            } 
        } 
    }); 
});
</script>