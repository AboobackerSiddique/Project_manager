<?php 
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");

$result1 = mysql_query("SELECT a.order_header_id,a.order_date,b.vendor_name,b.vendor_description,c.merchant_name,a.order_approved_by FROM rem_order a LEFT JOIN rem_vendor b ON a.order_vendor=b.vendor_id  LEFT JOIN rem_merchant c ON a.order_merchant=c.merchant_id  WHERE a.order_header_id='9878' AND a.order_type='1'");
echo "SELECT a.order_header_id,a.order_date,b.vendor_name,b.vendor_description,c.merchant_name,a.order_approved_by FROM rem_order a LEFT JOIN rem_vendor b ON a.order_vendor=b.vendor_id  LEFT JOIN rem_merchant c ON a.order_merchant=c.merchant_id  WHERE a.order_header_id='9878' AND a.order_type='1'";

print_r($result1)
?>

               