<?php
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php"); 
include("header.php"); 
$_SESSION["user_id"] =$_GET['userid'];
$_SESSION["user_name"] =$_GET['username'];
$_SESSION["pass_word"] =$_GET['password'];
$_SESSION["user_type"] = $_GET['usertype'];
$_SESSION["user_outlet"] = $_GET['user_outlet'];

if(isset($_POST["submit"]))
{
  $current_date=date("Y-m-d h:i:s");
  mysql_query("UPDATE rem_merchant_outlet_assign SET assign_process='3',assign_rejected_by='JK',assign_rejected_time='$current_date',assign_rejected_reason='$_POST[message]' WHERE assign_id='$_POST[order_id]'");

}



if(isset($_GET['ids']))
{
	if($_GET['process'] == 'accept')
  {
    
    $result = mysql_query("SELECT merchant_brand,merchant_trade,merchant_cuisine,merchant_segment FROM manager_project_lh.rem_merchant_register WHERE merchant_id='$_GET[merchant]'",$con);
    while($row = mysql_fetch_array($result))
    {
      $merchant_brand = $row['merchant_brand'];
      $merchant_trade = $row['merchant_trade'];
      $merchant_cuisine = $row['merchant_cuisine'];
      $merchant_segment = $row['merchant_segment'];
    } 

    

  $resultsssse = mysql_query("SELECT merchant_old_id FROM manager_project_lh.rem_merchant_register WHERE merchant_id='$_GET[merchant]'");
    while($rowsss3 = mysql_fetch_array($resultsssse))
    {
      $old_merchant_idsss = $rowsss3['merchant_old_id'];
    }

      if($old_merchant_idsss == '0' || $old_merchant_idsss == '')
      {

          $sql2="INSERT INTO manager_project_lh.rem_merchant(merchant_name,merchant_description)
          VALUES
          ('$merchant_brand','$merchant_trade')";
        
              if (!mysql_query($sql2,$con))
              {
                die('Error: ' . mysql_error());
              }
        
      }
      else
      {         

       
      }

 
    $max_header_result = mysql_query("SELECT MAX(merchant_id) FROM manager_project_lh.rem_merchant",$con);
    while($row_id = mysql_fetch_array($max_header_result))
    {
      $max_merchant_id = $row_id[0];
    }
    

     $sql3="INSERT INTO manager_project_lh.cfms_party_master(party_name,party_type_id,party_type)
      VALUES
      ('$merchant_brand','$max_merchant_id','merchant')";
    
      if (!mysql_query($sql3,$con))
          {
            die('Error: ' . mysql_error());
          }
    

    $sql2="INSERT INTO manager_project_lh.rem_assign_cuisine_segment(assign_merchant,assign_cuisine,assign_segment)
    VALUES
    ('$max_merchant_id','$merchant_cuisine','$merchant_segment')";
    
    if (!mysql_query($sql2,$con))
        {
          die('Error: ' . mysql_error());
        } 

    $current_date=date("Y-m-d h:i:s");

   
    mysql_query("UPDATE manager_project_lh.rem_merchant_outlet_assign SET assign_process='0',assign_approved_by='JK',assign_approved_time='$current_date' WHERE assign_id='$_GET[ids]'");

$header_id=$_GET['merchant']; 
     //Mail Start here
        $query_merchant_assign=mysql_query("SELECT a.merchant_id id,a.merchant_brand brand_name,a.merchant_trade trade_name,a.merchant_established established,a.merchant_promoter promoter,a.merchant_contact_person contact_person,a.merchant_contact_no contact_no,a.merchant_email email,a.merchant_no_of_branches no_of_branch,a.merchant_ratings ratings,a.merchant_turnover turnover,a.merchant_orders no_of_order,b.cuisine_name cuisine,c.segment_name segment,a.merchant_menu_pricing pricing,a.merchant_timings timings,a.merchant_zomato zomato,a.merchant_message message,d.name state,e.name cities FROM rem_merchant_register a
  LEFT JOIN rem_cuisine_master b ON a.merchant_cuisine = b.cuisine_id
  LEFT JOIN rem_segment_master c ON a.merchant_segment = c.segment_id
  LEFT JOIN states d ON a.merchant_state=d.id 
  LEFT JOIN cities e ON a.merchant_cities=e.id
  WHERE a.merchant_id='$header_id'");
  while($row_item = mysql_fetch_array($query_merchant_assign))
  {
      $id=$row_item['id'];
      $brand_name=$row_item['brand_name'];
      $trade_name=$row_item['trade_name'];
      $established=$row_item['established'];
      $promoter=$row_item['promoter'];
      $contact_person=$row_item['contact_person'];
      $contact_no=$row_item['contact_no'];
      $email=$row_item['email'];
      $no_of_branch=$row_item['no_of_branch'];
      $ratings=$row_item['ratings'];
      $turnover=$row_item['turnover'];
      $no_of_order=$row_item['no_of_order'];
      $cuisine=$row_item['cuisine'];
      $segment=$row_item['segment'];
      $pricing=$row_item['pricing'];
      $timings=$row_item['timings'];
      $zomato=$row_item['zomato'];
      $message=$row_item['message'];
      $states=$row_item['state'];
      $cities=$row_item['cities'];
  }


$subject = "Important!!! New Merchant ON-BOARD to ".$_GET['outlet']."-".$brand_name."";

        $message = "
        <html>
        <head>
        <title>Onboarding Merchant Details </title>
        </head>
        <body>
        <p>On-boarding merchant details below. </p>
        <table border=1>

            <tr>
                <td >Outlet Name :</td>
                <td  >".$_GET['outlet']."</td>
        </tr>
                <tr>
                <td >Brand Name :</td>
                <td  >".$brand_name."</td>
        </tr>

        <tr>
          <td >Trade Name :</td>
          <td  >".$trade_name."</td>
      </tr>
    <tr>
          <td >State :</td>
          <td  >".$states."</td>
      </tr>
      <tr>
          <td >City :</td>
          <td  >".$cities."</td>
      </tr>


        <tr>
          <td >Established From :</td>
          <td  >".$established."</td>
      </tr>

        <tr>
          <td >Brand Promoters Name :</td>
          <td  >".$promoter."</td>
      </tr>

        <tr>
          <td >Contact Person :</td>
          <td  >".$contact_person."</td>
      </tr>

        <tr>
          <td >Contact Number:</td>
          <td  >".$contact_no."</td>
      </tr>

        <tr>
          <td >Email-ID :</td>
          <td  >".$email."</td>
      </tr>

        <tr>
          <td >Branches in India :</td>
          <td  >".$no_of_branch."</td>
      </tr>

        <tr>
          <td >Brand Ratings :</td>
          <td  >".$ratings."</td>
      </tr>

        <tr>
          <td >Turnover :</td>
          <td  >".$turnover."</td>
      </tr>

        <tr>
          <td >Orders Per Outlet  :</td>
          <td  >".$no_of_order."</td>
      </tr>

     

        <tr>
          <td >Cuisine Type :</td>
          <td  >".$cuisine."</td>
      </tr>

        <tr>
          <td >Segement Type:</td>
          <td  >".$segment."</td>
      </tr>

        <tr>
          <td >Menu Pricing :</td>
          <td  >".$pricing."</td>
      </tr> 

      <tr>
          <td >Operation Timings:</td>
          <td  >".$timings."</td>
      </tr> 

      <tr>
          <td >Message:</td>
          <td  >".$message."</td>
      </tr>


        </table>
        </body>
        </html>
        ";

        // Always set content-type when sending HTML email
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

        // More headers
        $headers .= 'From: JK <jk@loyalhospitality.in>' . "\r\n";

        $dtls = mail('iqbal@loyalhospitality.in, dhanya@loyalhospitality.in, junaiz@loyalhospitality.in, khalid@loyalhospitality.in, lobo@loyalhospitality.in, sales@loyalhospitality.in, vaishnavi@loyalhospitality.in, assign@loyalhospitality.in, projects@loyalhospitality.in, la@loyalhospitality.in, rekha@loyalhospitality.in, niyas@loyalhospitality.in, mustafa@loyalhospitality.in, yahiya@loyalhospitality.in, shabnam@loyalhospitality.in, sj@loyalhospitality.in, manzoor@loyalhospitality.in, faisal@loyalhospitality.in, crm@loyalhospitality.in, firdos@loyalhospitality.in, smo@loyalhospitality.in, noor@loyalhospitality.in, zahid@loyalhospitality.in, siddique@loyalhospitality.in, designs@oyalhospitality.in, deril@oyalhospitality.in',$subject,$message,$headers);

  }
  else
  {
    // You can type anything for jK rejection NOw nothing is happening
    
    
  }
}


 $query_merchant_assign=mysql_query("SELECT assign_id id,assign_merchant merchant,assign_outlet outlet,assign_server_company company,assign_server_brand brand FROM manager_project_lh.rem_merchant_outlet_assign WHERE assign_process='2'",$con);
    
  while($row_item = mysql_fetch_assoc($query_merchant_assign))
  {
      $details_item[] = $row_item;
  }

?>


<div class="shadow-lg p-3 mb-1 bg-white rounded" style="position:fixed; width:100%; z-index:9999;">
   <a href="dashboard.php" class="btn btn-success btn-sm">Back</a>
 
</div>
 
 <br/>
<br/>
<br/>



  <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #ddd;
}

th, td {
    padding: 5px;
	font-size:10px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<h3>&nbsp;Onboarding Merchant Approval</h3>

<div >
  <p align="right"><font color="#000000">Smart Search  : &nbsp;</font><input type="search" class="light-table-filter" data-table="table-bordered" placeholder="Filter">&nbsp;&nbsp;</p>    
  </div>
   <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg" style="width:95%; padding-top:100px;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Merchant Details</h4>
           <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body ">
                <label id='ur_id'><label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>   
  <button style="display:none" type="button" class="btn btn-info btn-lg btn_open_modal" data-toggle="modal" data-target="#myModal">Open Modal</button>   
<div style="overflow-x:auto;">
  
  <table class="table-bordered">
  <thead>
    <tr>
      
      <th width="88%" colspan="2" align="right">MERCHANT DETAILS</th>
    

        
    </tr>
    </thead>
    <?php

	$counter=0;
	foreach($details_item as $i):	
			
	?>
    <tr>
      
      <td align="right" width="50%"><font size="1">TRADE NAME<br/>BRAND NAME<BR/>OUTLET</font></td>
      <td width="50%"><font size="1">
        <?php 
        $companys=mysql_query("SELECT name FROM shadow_kitchen.users WHERE id='$i[company]'",$con1);
        while($companys_row = mysql_fetch_array($companys))
        {
            echo $companys_row['name'];
        }
        ?><br/>
        <?php 
        $brands=mysql_query("SELECT name FROM shadow_kitchen.users WHERE id='$i[brand]'",$con1);
        while($brands_row = mysql_fetch_array($brands))
        {
            echo $brands_row['name'];
        }
        ?>
        <br/>
      <?php 
        $outlets=mysql_query("SELECT name FROM shadow_kitchen.users WHERE id='$i[outlet]'",$con1);
        while($outlets_row = mysql_fetch_array($outlets))
        {
            echo $outlets_row['name'];
        }
        ?></font></td>
      
       <td width="12%" align="center">
       		<br/>
       		
       	
   </td>
        
       
        
    </tr>
    <tr>
      <td align="center"> <a href="javascript:confirmApprove('onboardingmerchantapproval.php?process=accept&ids=<?php print_r($i['id']); ?>&merchant=<?php print_r($i['merchant']); ?>')" class="btn btn-success btn-sm">Accept</a></td>
      <td align="center">
       <!--  <a href="javascript:confirmDelete('onboardingmerchantapproval.php?process=reject&ids=<?php print_r($i['id']); ?>&merchant=<?php print_r($i['merchant']); ?>')" class="btn btn-danger btn-sm">Reject</a> -->
       <a href="#" class="lbl_item btn btn-danger btn-sm" itm_id="<?php print_r($i['id']); ?>" >Reject</a>
      </td>
    
    </tr>
    <?php
	endforeach;
	?>
   
  </table>
</div>

</body>
</html>
<div class="modal fade" id="myModals" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-dialog" style="padding-top:70px;">
						<div class="modal-content">
							<div class="modal-header">
								
								<h2 class="modal-title">Filter</h2>
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div>
							 <form class="form-horizontal" role="form" method="post">
<div class="modal-body">
					 <div class="form-group">
                        <label for="inputLinkPp" class="hidden-xs col-sm-3 control-label">Choose Vendor:</label>
                        <div class="input-group col-sm-8 xs-margin">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
                      	<?php 
								$vendor = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor WHERE vendor_id!='$_GET[vendor]'");
								?>
                             	<select  class="form-control"  name="vendor" id="vendor" onkeydown='if(event.keyCode == 13){document.getElementById("type").focus();return false;}'  >
         						
                                
                                
                                <?php 
								if($_GET['vendor'] == 'ALL')
								{?>
                                <option value="ALL">ALL Vendor..</option>
                                <?php 
								} 
								else
								{
								$vendor6 = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor WHERE vendor_id='$_GET[vendor]'");
								while($area_vendor6 = mysql_fetch_array($vendor6))
								{
								?>
								<option value="<?php echo $area_vendo6r[0]; ?>"><?php echo $area_vendor6[1]; }?></option>
                                 <option value="ALL">ALL Vendor..</option>
                                  <?php } ?>
                               
         						<?php 
   								while($area_vendor = mysql_fetch_array($vendor))
								{
								?>
								<option value="<?php echo $area_vendor[0]; ?>"><?php echo $area_vendor[1]; }?></option>
      							</select>
                       </div>
                    </div>
                   
                  
                    
</div>
<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								<button type="submit" name="submit" id="submit" class="btn btn-primary">Search</button>
							</div>
                            </form>
						</div><!-- /.modal-content -->
					</div><!-- /.modal-dialog -->
				</div>  
   <script>
    function priceSorter(a, b) {
        a = +a.substring(1); // remove $
        b = +b.substring(1);
        if (a > b) return 1;
        if (a < b) return -1;
        return 0;
    }
</script>
<script>
function confirmDelete(delUrl) {
  if (confirm("Are you sure you want to Reject")) {
    document.location = delUrl;
  }
}
</script>
<script>
function confirmApprove(delUrl) {
  if (confirm("Are you sure you want to Approve")) {
    document.location = delUrl;
  }
}
</script> 
<script>
  
$(document).on('click','.lbl_item',function(){
  var item_id = $(this).attr('itm_id');
  console.log(item_id);
  $.ajax({
      url:"getonboardreject.php",
      data:{'item_id':item_id},
      type:'POST',
      success:function(data)
      {
        $("#ur_id").html(data);
      }
  }); 
  
  $(".btn_open_modal").click();
});
</script>
 <script>
(function(document) {
    'use strict';

    var LightTableFilter = (function(Arr) {

          var _input;

          function _onInputEvent(e) {
              _input = e.target;
              var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
				});
			});
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
		};
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			LightTableFilter.init();
		}
	});

})(document);
</script>

<script>
$.tablesorter.addParser({ 
    id: 'price', 
    is: function(s) { 
        return false; 
    }, 
    format: function(s) { 
        return s.replace(/Free/,0).replace(/ CHF/,""); 
    }, 
    type: 'numeric' 
}); 

$(function() { 
    $("table").tablesorter({ 
        headers: { 
            1: { 
                sorter:'price' 
            } 
        } 
    }); 
});
</script>