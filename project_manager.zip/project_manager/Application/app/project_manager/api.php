<?php
// echo "Hai";
// die;

// session_start();
include("dbconnection.php");
//Login to admin account
// print_r($_POST);

$pos = mysql_query("SELECT COUNT(*) FROM rem_order WHERE order_process='1'");
while($row_po = mysql_fetch_array($pos))
{
    if($row_po == '0')
    {
      $po_count=0;
    }
    else
    {
      $po_count=$row_po[0];
    }
    
}

$advances = mysql_query("SELECT COUNT(*) FROM rem_order_payment_request");
while($row_advance = mysql_fetch_array($advances))
{
    if($row_advance == '0')
    {
        $advance_count=0;
    }
    else
    {
        $advance_count=$row_advance[0];
    }
    
}

$registers = mysql_query("SELECT COUNT(*) FROM rem_merchant_register WHERE merchant_process='0'");
while($row_register = mysql_fetch_array($registers))
{
    if($row_register == '0')
    {
        $register_count=0;
    }
    else
    {
        $register_count=$row_register[0];
    }
    
}

$onboards = mysql_query("SELECT COUNT(*) FROM rem_merchant_outlet_assign WHERE assign_process='2'");
while($row_onboard = mysql_fetch_array($onboards))
{
    if($row_onboard == '0')
    {
        $onboard_count=0;
    }
    else
    {
        $onboard_count=$row_onboard[0];
    }

}

$offboards = mysql_query("SELECT COUNT(*) FROM rem_merchant_offboard WHERE off_process='0'");
while($row_offboard = mysql_fetch_array($offboards))
{
    if($row_offboard == '0')
    {
        $offboard_count=0;
    }
    else
    {
        $offboard_count=$row_offboard[0];
    }
}
  

  
    
      $a =array("po_count"=> $po_count,"advance_count"=> $advance_count,"register_count"=> $register_count,"onboard_count"=> $onboard_count,"offboard_count"=> $offboard_count);
    
       echo json_encode($a);



?>