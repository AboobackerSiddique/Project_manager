<?php
ob_start();
session_start();
include("dbconnection.php");
error_reporting(E_ERROR | E_PARSE);// set time-out period (in seconds)
$d =  $_POST['item_id'];
$details = explode('$',$d);

$ids =  $details[0];
$outlets=$details[1];
$merchants=$details[2];
$transfer_type=$details[3];

?>
   <form method="post">    
<table class="table table-bordered" id="table"
               data-toggle="table"
               data-height="460"
               data-sort-name="price"
               data-sort-order="desc" width="100%">
  
      <tr>
       
         <td ><b>SL.NO</b></th>
         <td  ><b>ITEM NAME</b></td>
       <td align="center"><b>BARCODE</b></td>
                  
      </tr>
   
    <tbody>
<?php
		
		
$result_item = mysql_query("SELECT a.stock_barcode barcode,b.stock,c.sales,d.item_name,d.item_id item_id,e.cat_name item_category FROM rem_stock a 
LEFT JOIN (SELECT stock_barcode,COUNT(*) stock FROM rem_stock WHERE stock_to_type='3' AND stock_to_outlet='$outlets' AND stock_to='$merchants' GROUP BY stock_barcode) AS b ON b.stock_barcode=a.stock_barcode 
LEFT JOIN (SELECT stock_barcode,COUNT(*) sales FROM rem_stock WHERE stock_from_type='3' AND stock_from_outlet='$outlets' AND stock_from='$merchants' GROUP BY stock_barcode) AS c ON c.stock_barcode=a.stock_barcode 
LEFT JOIN rem_item d ON a.stock_item=d.item_id 
LEFT JOIN rem_vendor_category e ON d.item_category=e.cat_id
WHERE a.stock_item='$ids' GROUP BY a.stock_barcode");
$counter=0;
while($row_item = mysql_fetch_array($result_item))
{
	$balance = $row_item['stock']-$row_item['sales'];
	if($balance>0)
	{ ?>
      <tr>
        <td width="5%"><font size="1"><?php echo ++$counter; ?></font></td>
        <td width="20%"><font size="1"><?php echo $row_item['item_name']; ?></td>
        
       
       	<td align="right" width="20%">
        
         <font size="1" color="#FF0000"><b><?php echo $row_item['barcode']; ?></b></font><br/>
        <?php 
		$results = mysql_query("select update_old_barcode old,update_new_barcode new from rem_barcode_update where update_old_barcode='$row_item[barcode]' AND update_item='$row_item[item_id]' and update_to_outlet='$outlets' and update_to='$merchants'");
		while($rows= mysql_fetch_array($results))
		{
			$old_barcode=$rows['old'];
			$new_barcode=$rows['new'];
		
		
		
		if($rows)
		{?>
     	<font size="1" color="#009900"><b><?php echo $new_barcode; ?></b></font>
		<?php 
		}
		
		}
		?>
        
        
        <!--<font size="1">
        <input type="hidden" name="chk1[]" id="chk1[]" value="<?php echo $row_item['item_id']; ?>">
        <input type="hidden" name="chk2[]" id="chk2[]" value="3">
        <input type="hidden" name="chk3[]" id="chk3[]" value="<?php echo $outlets; ?>">
        <input type="hidden" name="chk4[]" id="chk4[]" value="<?php echo $merchants; ?>">
        <input type="hidden" name="chk5[]" id="chk5[]" value="<?php echo $row_item['barcode']; ?>">
        <?php
		$strbar = "'0'";
        $query = mysql_query("SELECT  update_new_barcode FROM rem_barcode_update  where update_item='$row_item[item_id]'");
		while($row_items  = mysql_fetch_array($query ))
		{
			 $strbar.=",'".$row_items[0]."'";
		}
		
		 $items1 = mysql_query("SELECT barcode_no  FROM rem_barcode WHERE barcode_item_id='$row_item[item_id]' AND barcode_no NOT IN($strbar)");
		?>  
<select name="chk6[]" id="chk6[]" class="form-control" autocomplete="off" required>
		
		<?php 
		while($row  = mysql_fetch_array($items1))
		{
			
		?>
		<option value="<?php echo $row['barcode_no'];  ?>"><font size="1"><?php echo $row['barcode_no'];  ?></font></option>
		<?php
			
		}
		?>
		</select> </font>  -->
        
        </td>
		
        
      </tr>
<?php } else { } } ?>
 </tbody>
  </table>
 <!-- <center>
 <button type="submit" class="btn btn-success"  name="submit" id="submit">Change Barcode</button>
 </center> -->
 </form>