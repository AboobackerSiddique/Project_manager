<?php
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php"); 
include("header.php"); 


if(isset($_GET['ids']))
{
	
		date_default_timezone_set('Asia/Calcutta');
		$current_date=date("Y-m-d H:i");
		
		mysql_query("UPDATE rem_order SET order_process='0',order_approved_by='$_SESSION[user_name]',order_approved_time='$current_date' WHERE order_header_id='$_GET[ids]' AND order_type='$_GET[types]'");
		mysql_query("UPDATE rem_order_details SET details_process='0' WHERE details_header_id='$_GET[ids]' AND details_order_type='$_GET[types]'");
		
}

if(isset($_POST['submit']))
{

		date_default_timezone_set('Asia/Calcutta');
		$current_date=date("Y-m-d H:i");
		mysql_query("UPDATE rem_order SET order_process='2',order_approved_by='$_SESSION[user_name]',order_approved_time='$current_date',order_reject_reason='$_POST[message]' WHERE order_header_id='$_POST[order_id]' AND order_type='$_POST[order_type]'");
		mysql_query("UPDATE rem_order_details SET details_process='2' WHERE details_header_id='$_POST[order_id]' AND details_order_type='$_POST[order_type]'");
	
}


		$query_merchant_assign=mysql_query("SELECT a.order_header_id pono,a.order_date order_date,a.order_delivery_date delivery_date,b.vendor_name vendor,a.order_total_amount total,a.order_advance advance,a.order_type type,a.order_vendor vendor_id  FROM rem_order a LEFT JOIN rem_vendor b ON a.order_vendor=b.vendor_id 
 WHERE  a.order_process=1 GROUP BY a.order_header_id,a.order_type  ORDER BY a.order_header_id");
	
	
	while($row_item = mysql_fetch_assoc($query_merchant_assign))
		{
			$details_item[] = $row_item;
		}
		
?>


<div class="shadow-lg p-3 mb-1 bg-white rounded" style="position:fixed; width:100%; z-index:9999;">
   <a href="dashboard.php" class="btn btn-success btn-sm">Back</a>
 
</div>
 
 <br/>
<br/>
<br/>



  <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #ddd;
}

th, td {
    padding: 5px;
	font-size:10px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<h2>&nbsp;PO/WO Approval</h2>

<div >
  <p align="right"><font color="#000000">Smart Search  : &nbsp;</font><input type="search" class="light-table-filter" data-table="table-bordered" placeholder="Filter">&nbsp;&nbsp;</p>    
  </div>
  <div class="modal fade" id="myModal1" role="dialog">
    <div class="modal-dialog modal-lg" style="width:100%; padding-top:100px;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Reject Reason</h4>
           <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body ">
                <label id='ur_id1'><label>
        </div>
        
      </div>
      
    </div>
  </div>   
  <button style="display:none" type="button" class="btn btn-info btn-lg btn_open_modal1" data-toggle="modal" data-target="#myModal1">Open Modal</button> 
  
   <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg" style="width:100%; padding-top:100px;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Reject Reason</h4>
           <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body ">
                <label id='ur_id'><label>
        </div>
        
      </div>
      
    </div>
  </div>   
  <button style="display:none" type="button" class="btn btn-info btn-lg btn_open_modal" data-toggle="modal" data-target="#myModal">Open Modal</button>   
<div style="overflow-x:auto;">
  
  <table class="table-bordered">
  <thead>
    <tr>
      <th width="8%">PO/WO</th>
      <th width="60%">VENDOR NAME</th>
      <th width="7%">TOTAL</th>
       <th width="7%">PAID</th>
        <th width="7%">BAL</th>
        <th width="14%" colspan="2">ACTION</th>
    </tr>
    </thead>
    <?php
	$total_Advance=0;
	$counter=0;
	foreach($details_item as $i):	
	$total_Advance+=$i['advance'];			
	?>
    <tr>
     
      <td><a href="#" class="btn btn-<?php if($i['type'] == '1') { echo "info"; } else { echo "success"; } ?> btn-sm lbl_item1" itm_id1="<?php print_r($i['pono'].'$'.$i['type'].'$'.$i['vendor_id'].'$'.$i['vendor']); ?>"><font size="1"><?php if($i['type'] == '1') { echo "PO"; } else { echo "WO"; } ?>-<?php print_r($i['pono']); ?></font></a></td>
     
	 
       <td><?php print_r($i['vendor']) ;?></td>
        <td align="right"><?php 
	
		$query_merchant_total=mysql_query("SELECT SUM(details_amount) amount FROM rem_order_details WHERE details_header_id='$i[pono]' AND details_order_type='$i[type]'");
		
	
	while($row_total = mysql_fetch_assoc($query_merchant_total))
		{
			echo $total_amt=round($row_total['amount'],0);
		}?></td>
        <td align="right">
		<?php 
$result212 = mysql_query("SELECT SUM(payment_amount) FROM rem_order_payment WHERE payment_order_id='$i[pono]' AND payment_order_type='$i[type]'");
while($row212 = mysql_fetch_array($result212))
{
	$advance_paid=round($row212[0],0);	
}

echo $advance_amount=round($i['advance']+$advance_paid); 
?></td>
        <td align="right"><?php echo $total_amt-$advance_amount;?></td>
        <td><a href="javascript:confirmApprove('poapprove.php?process=accept&ids=<?php print_r($i['pono']); ?>&types=<?php print_r($i['type']); ?>')" class="btn btn-success btn-sm">Accept</a></td>
        <td><div><a href="#" class="lbl_item btn btn-danger btn-sm" itm_id="<?php print_r($i['pono'].'$'.$i['type']); ?>" >Reject</a></div>
          </td>
        
    </tr>
    <?php
	endforeach;
	?>
    
  </table>
</div>

</body>
</html>
<div class="modal fade" id="myModals" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-dialog" style="padding-top:70px;">
						<div class="modal-content">
							<div class="modal-header">
								
								<h2 class="modal-title">Filter</h2>
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div>
							 <form class="form-horizontal" role="form" method="post">
<div class="modal-body">
					 <div class="form-group">
                        <label for="inputLinkPp" class="hidden-xs col-sm-3 control-label">Choose Vendor:</label>
                        <div class="input-group col-sm-8 xs-margin">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
                      	<?php 
								$vendor = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor WHERE vendor_id!='$_GET[vendor]'");
								?>
                             	<select  class="form-control"  name="vendor" id="vendor" onkeydown='if(event.keyCode == 13){document.getElementById("type").focus();return false;}'  >
         						
                                
                                
                                <?php 
								if($_GET['vendor'] == 'ALL')
								{?>
                                <option value="ALL">ALL Vendor..</option>
                                <?php 
								} 
								else
								{
								$vendor6 = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor WHERE vendor_id='$_GET[vendor]'");
								while($area_vendor6 = mysql_fetch_array($vendor6))
								{
								?>
								<option value="<?php echo $area_vendo6r[0]; ?>"><?php echo $area_vendor6[1]; }?></option>
                                 <option value="ALL">ALL Vendor..</option>
                                  <?php } ?>
                               
         						<?php 
   								while($area_vendor = mysql_fetch_array($vendor))
								{
								?>
								<option value="<?php echo $area_vendor[0]; ?>"><?php echo $area_vendor[1]; }?></option>
      							</select>
                       </div>
                    </div>
                   
                     <div class="form-group">
                        <label for="inputLinkPp" class="hidden-xs col-sm-3 control-label">Choose Vendor:</label>
                        <div class="input-group col-sm-8 xs-margin">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
                      <?php 
								$vendor1 = mysql_query("SELECT type_id,type_shortname FROM rem_order_type WHERE type_id!='$_GET[type]'");
								?>
                             	<select  class="form-control"  name="type" id="type" onkeydown='if(event.keyCode == 13){document.getElementById("submit").focus();return false;}'  >
         						
                                
                                
                                <?php 
								if($_GET['type'] == 'ALL')
								{?>
                                <option value="ALL">ALL PO & WO..</option>
                                <?php 
								} 
								else
								{
								$vendor61 = mysql_query("SELECT type_id,type_shortname FROM rem_order_type WHERE type_id='$_GET[type]'");
								while($area_vendor61 = mysql_fetch_array($vendor61))
								{
								?>
								<option value="<?php echo $area_vendo61[0]; ?>"><?php echo $area_vendor61[1]; }?></option>
                                 <option value="ALL">ALL PO & WO..</option>
                                  <?php } ?>
                               
         						<?php 
   								while($area_vendor1 = mysql_fetch_array($vendor1))
								{
								?>
								<option value="<?php echo $area_vendor1[0]; ?>"><?php echo $area_vendor1[1]; }?></option>
      							</select>
                       </div>
                    </div>
                    
</div>
<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								<button type="submit" name="submit" id="submit" class="btn btn-primary">Search</button>
							</div>
                            </form>
						</div><!-- /.modal-content -->
					</div><!-- /.modal-dialog -->
				</div>  
 <script>
function confirmDelete(delUrl) {
  if (confirm("Are you sure you want to Reject")) {
    document.location = delUrl;
  }
}
</script>
<script>
function confirmApprove(delUrl) {
  if (confirm("Are you sure you want to Approve")) {
    document.location = delUrl;
  }
}
</script>  <script>
    function priceSorter(a, b) {
        a = +a.substring(1); // remove $
        b = +b.substring(1);
        if (a > b) return 1;
        if (a < b) return -1;
        return 0;
    }
</script>
<script>
  
$(document).on('click','.lbl_item',function(){
	var item_id = $(this).attr('itm_id');
	console.log(item_id);
	$.ajax({
			url:"getreject.php",
			data:{'item_id':item_id},
			type:'POST',
			success:function(data)
			{
				$("#ur_id").html(data);
			}
	});	
	
	$(".btn_open_modal").click();
});
</script>
<script>
  
$(document).on('click','.lbl_item1',function(){
	var item_id = $(this).attr('itm_id1');
	console.log(item_id);
	$.ajax({
			url:"getporeports.php",
			data:{'item_id':item_id},
			type:'POST',
			success:function(data)
			{
				$("#ur_id1").html(data);
			}
	});	
	
	$(".btn_open_modal1").click();
});
</script>
 <script>
(function(document) {
    'use strict';

    var LightTableFilter = (function(Arr) {

          var _input;

          function _onInputEvent(e) {
              _input = e.target;
              var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
				});
			});
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
		};
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			LightTableFilter.init();
		}
	});

})(document);
</script>

<script>
$.tablesorter.addParser({ 
    id: 'price', 
    is: function(s) { 
        return false; 
    }, 
    format: function(s) { 
        return s.replace(/Free/,0).replace(/ CHF/,""); 
    }, 
    type: 'numeric' 
}); 

$(function() { 
    $("table").tablesorter({ 
        headers: { 
            1: { 
                sorter:'price' 
            } 
        } 
    }); 
});
</script>