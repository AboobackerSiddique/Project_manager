<?php
session_start();
include("dbconnection.php");
// Login to admin account
function loginfuntion($loginid,$password)
{

$resultlogin = mysql_query("SELECT user_id,user_name,user_password,user_type,user_freeze,user_outlet FROM rem_user WHERE user_name ='$loginid' AND user_password='$password'");
while($row = mysql_fetch_array($resultlogin))
{
	$user_id = $row["user_id"];
	$user_name = $row["user_name"];
	$password = $row["user_password"];
	$user_type = $row["user_type"];
	$user_freeze = $row["user_freeze"];
	$user_outlet = $row["user_outlet"];
	
}


	if(mysql_num_rows($resultlogin) == 1)
	{
		if($user_freeze == 1)
		{
			$in= "User Freezed Contact Administrator..! ";
			return $in;
		}
		else
		{
			$_SESSION["user_id"] =$user_id;
 			$_SESSION["user_name"] =$loginid;
			$_SESSION["pass_word"] =$password;
			$_SESSION["user_type"] = $user_type;
			$_SESSION["user_outlet"] = $user_outlet;
		}
	}
	else
	{
	$in= "Invalid Username or Invalid Password. ";
	return $in;
	}

}

?>