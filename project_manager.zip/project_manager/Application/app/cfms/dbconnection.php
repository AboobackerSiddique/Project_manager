<?php
$con = mysql_connect("13.250.72.191","admin","bridge@team");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("lease_management", $con);


$conn=mysql_connect("13.250.72.191","admin","bridge@team") or die(mysql_error());

$sdb=mysql_select_db("lease_management",$conn) or die(mysql_error());

?>