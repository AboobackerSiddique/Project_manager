    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<footer>
  <table width="100%" >
  <tr>
  <td width="70%">Location:&nbsp;<span class="badge badge-pill badge-success"><?php echo $_SESSION["display_location"]; ?></span></td>
 
  <td width="30%"><button type="button" class="btn btn-secondary btn-sm"">
  Profile <span class="badge badge-light">9</span>
  <span class="sr-only">unread messages</span>
</button></td>
  </tr></table>
     </footer>
  </body>
</html>