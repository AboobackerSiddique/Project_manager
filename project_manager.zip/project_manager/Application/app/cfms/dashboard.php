<?php
ob_start();
error_reporting(E_ERROR | E_PARSE);
session_start();
include("header.php"); 
include("../dbconnection.php");
?>
 <style> 
 body, html {
    height: 100%;
    margin: 0;
}

.bg {
    /* The image used */
    background-image: url("img/bg.jpg");

    /* Full height */
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
	
}
.start {
 position: absolute;
     margin: auto;
     top: 0;
     right: 0;
     bottom: 0;
     left: 0;
     width: 100%;
     height: 100%;

} 

.btn {
  background-color: #F9F9F9;
  width:100%;
  border: none;
  color: black;
  padding: 16px 32px;
  text-align: center;
  font-size: 14px;
  margin:2px;
  transition: 0.3s;
}

.btn:hover {
  background-color: #B92626;
  color: white;
}
</style>


<div class="shadow-lg p-3 mb-1 bg-white rounded" style="position:fixed; width:100%; z-index:9999;">
   <a href="../index.php" >Home</a> | CFMS REPORTS
 
</div>
 
	<div class="bg">
	<div class="start">
	<center>
	<br/><br/><br/><br/>
	<div class="form-group col-md-6">
            	<a href="expenseapproval.php" class="btn" >EXPENSE APPROVAL(<b><font color="#FF0000"><?php $resultlogin = mysql_query("SELECT COUNT(*) FROM cfms_expense WHERE exp_process='0'");
	while($row = mysql_fetch_array($resultlogin))
	{
		if($row[0] == '0')
		{
			echo "0";
		}
		else
		{
			echo $row[0];
		}; 
	} ?></font></b>)</a>

    <a href="incomeapproval.php" class="btn" >INCOME APPROVAL(<b><font color="#FF0000"><?php $resultlogin = mysql_query("SELECT COUNT(*) FROM cfms_income WHERE exp_process='0'");
  while($row = mysql_fetch_array($resultlogin))
  {
    if($row[0] == '0')
    {
      echo "0";
    }
    else
    {
      echo $row[0];
    }; 
  } ?></font></b>)</a>
 <?php if($_SESSION["user_name"] == 'junaiz' || $_SESSION["user_name"] == 'Junaiz' || $_SESSION["user_name"] == 'Z'  || $_SESSION["user_name"] == 'z'|| $_SESSION["user_name"] == 'firdos' || $_SESSION["user_name"] == 'Firdos' || $_SESSION["user_name"] == 'admin') 
  { ?>
  <a href="balancereports.php?outlet=ALL" class="btn" >CAPITAL INVESTMENT REPORTS</a>
<?php } ?>
  <a href="expensereports.php?outlet=ALL" class="btn" >EXPENSE REPORTS</a>
  <a href="balancereports.php?outlet=ALL" class="btn" >CREDIT REPORTS</a>
  <a href="balancereports.php?outlet=ALL" class="btn" >BANK TRANSFER REPORTS</a>
                
    </div>	
	</center>
	</div>
	</div>