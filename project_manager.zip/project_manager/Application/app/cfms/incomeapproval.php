<?php
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);
include("../dbconnection.php"); 
include("header.php"); 

date_default_timezone_set('Asia/Calcutta');
$time=date("Y-m-d h:i:s");

if(isset($_GET['expense_id']))
{
  mysql_query("UPDATE cfms_income SET exp_process='1',exp_approved_by='$_SESSION[user_name]',exp_approved_time='$time' WHERE exp_id='$_GET[expense_id]'");
}

if(isset($_POST["reject"]))
{
  mysql_query("UPDATE cfms_income SET exp_process='2',exp_rejected_by='$_SESSION[user_name]',exp_rejected_time='$time',exp_rejected_reason='$_POST[reason]' WHERE exp_id='$_POST[expense_id]'");
}

	

?>


<div class="shadow-lg p-3 mb-1 bg-white rounded" style="position:fixed; width:100%; z-index:9999;">
   <a href="dashboard.php" class="btn btn-success btn-sm">Back</a>
 
</div>
 
 <br/>
<br/>
<br/>



  <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #ddd;
}

th, td {
    padding: 5px;
	font-size:10px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<h2>&nbsp;Expense Approval &nbsp;&nbsp;</h2>

<div >
  <p align="right"><font color="#000000">Smart Search  : &nbsp;</font><input type="search" class="light-table-filter" data-table="table-bordered" placeholder="Filter">&nbsp;&nbsp;</p>    
  </div>
   
 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg" style="width:95%; padding-top:100px;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Income Details</h4>
           <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body ">
          
                <label id='ur_id'><label>
                
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>   
  <button style="display:none" type="button" class="btn btn-info btn-lg btn_open_modal" data-toggle="modal" data-target="#myModal">Open Modal</button>   
<div style="overflow-x:auto;">
    

<table class="table-bordered">
    <thead>
      <tr>
        <th width="4%" >SNo</th>
        <th width="96%" colspan="3" >Income Details</th>
        
        
         
      </tr>
    </thead>
    <tbody>
<?php 


      $query_merchant_assign=mysql_query("SELECT a.exp_id id,a.exp_date date,b.outlet_name outlet,c.ledger_name ledger,d.party_name party,a.exp_grosstotal gross_total,e.bank_name bank FROM cfms_income a
      LEFT JOIN rem_outlet b ON a.exp_outlet = b.outlet_id
      LEFT JOIN cfms_ledger_master c ON a.exp_ledger = c.ledger_id
      LEFT JOIN cfms_party_master d ON a.exp_party = d.party_id
      LEFT JOIN cfms_bank_master e ON a.exp_bank = e.bank_id
       WHERE a.exp_process='0'  ORDER BY a.exp_id ASC");
    
    $counter=0;
    while($row = mysql_fetch_array($query_merchant_assign))
    {
      ?>
      <tr>
       
        <td align="center"><?php echo ++$counter; ?></td>

        <td align="right" width="25%"><b>Date :<br/>Outlet :<br/>Ledger :<br/>Party :<br/>Amount :<br/>Bank :</td>
        <td align="left" width="75%" colspan="2"><b><?php echo date("d-m-Y", strtotime($row['date'])); ?></b><br/><b><?php echo $row['outlet']; ?></b><br/>
          <b><font color="#FF0000"><?php echo $row['ledger']; ?></font></b> <br/><b><?php echo $row['party']; ?></b><br/><b><?php echo $row['gross_total']; ?></b><br/><b><?php echo $row['bank']; ?></b></td>
       
       
      
       
       
      </tr>
      <tr>
       <td align="center"  colspan="2"><div><a href="#" class="lbl_item btn btn-danger btn-sm" itm_id="<?php echo $row['id'].'$'.'reject'; ?>" >&nbsp;&nbsp;Reject&nbsp;&nbsp;</a></div></td>

         <td align="center"> <div><a href="#" class="lbl_item btn btn-warning btn-sm" itm_id="<?php echo $row['id'].'$'.'view'; ?>" >&nbsp;&nbsp;View &nbsp;&nbsp;</a></div></td>

         <td align="center" ><div><a href="javascript:confirmApprove('incomeapproval.php?expense_id=<?php echo $row['id']; ?>')" class="btn btn-success btn-sm">&nbsp;&nbsp;Accept&nbsp;&nbsp;</a></div></td>
       
        
      </tr>
		<?php
    }
		?> 

 
    </tbody>
  </table>

</div>

</body>
</html>
<div class="modal fade" id="myModals" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-dialog" style="padding-top:70px;">
						<div class="modal-content">
							<div class="modal-header">
								
								<h2 class="modal-title">Filter</h2>
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div>
							 <form class="form-horizontal" role="form" method="post">
<div class="modal-body">
					
                      <div class="form-group">
                        <label for="inputLinkPp" class="hidden-xs col-sm-3 control-label">Sales_From:</label>
                        <div class="input-group col-sm-8 xs-margin">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
                      <input type="date" name="from" id="from" class="form-control" value="<?php echo $_GET['from']; ?>">
                       </div>
                    </div>
                     <div class="form-group">
                        <label for="inputLinkPp" class="hidden-xs col-sm-3 control-label">Sales_To:</label>
                        <div class="input-group col-sm-8 xs-margin">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
                     <input type="date" name="to" id="to" class="form-control" value="<?php echo $_GET['to']; ?>">
                       </div>
                    </div>
                    <?php if($_SESSION[user_type] !='Outlet')
                {?>
                    <div class="form-group">
                        <label for="inputLinkPp" class="hidden-xs col-sm-3 control-label">Choose_Agreement_Type:</label>
                        <div class="input-group col-sm-8 xs-margin">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
                      
   <?php 
                $vendor = mysql_query("SELECT outlet_id,outlet_name FROM rem_outlet WHERE outlet_id!='$_GET[outlet]'");
                ?>
                <select  class="form-control"  name="outlet" id="outlet" onkeydown='if(event.keyCode == 13){document.getElementById("submit").focus();return false;}'  >
                
                <?php 
                if($_GET['outlet'] == 'ALL')
                {?>
                <option value="ALL">ALL Outlet..</option>
                                <?php 
                } 
                else
                {
                $vendor6 = mysql_query("SELECT outlet_id,outlet_name FROM rem_outlet WHERE outlet_id='$_GET[outlet]'");
                while($area_vendor6 = mysql_fetch_array($vendor6))
                {
                ?>
                <option value="<?php echo $area_vendor6[0]; ?>"><?php echo $area_vendor6[1]; }?></option>
                                 <option value="ALL">ALL Outlet..</option>
                                  <?php } ?>
                               
                    <?php 
                  while($area_vendor = mysql_fetch_array($vendor))
                {
                ?>
                <option value="<?php echo $area_vendor[0]; ?>"><?php echo $area_vendor[1]; }?></option>
                </select>


                       </div>
                    </div>

                   <?php   }
        else
        {?>
          <input type="hidden" name="outlet" id="outlet" value="<?php echo $_GET['outlet']; ?>" >

        <?php  
        }
        ?>
</div>
<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								<button type="submit" name="submit" id="submit" class="btn btn-primary">Search</button>
							</div>
                            </form>
						</div><!-- /.modal-content -->
					</div><!-- /.modal-dialog -->
				</div>  
   <script>
    function priceSorter(a, b) {
        a = +a.substring(1); // remove $
        b = +b.substring(1);
        if (a > b) return 1;
        if (a < b) return -1;
        return 0;
    }
</script>
<script>
function confirmApprove(delUrl) {
  if (confirm("Are you sure you want to Approve")) {
    document.location = delUrl;
  }
}
</script> 
<script>
  
$(document).on('click','.lbl_item',function(){
	var item_id = $(this).attr('itm_id');
	console.log(item_id);
	$.ajax({
			url:"getbalance.php",
			data:{'item_id':item_id},
			type:'POST',
			success:function(data)
			{
				$("#ur_id").html(data);
			}
	});	
	
	$(".btn_open_modal").click();
});
</script>
 <script>
(function(document) {
    'use strict';

    var LightTableFilter = (function(Arr) {

          var _input;

          function _onInputEvent(e) {
              _input = e.target;
              var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
				});
			});
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
		};
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			LightTableFilter.init();
		}
	});

})(document);
</script>

<script>
$.tablesorter.addParser({ 
    id: 'price', 
    is: function(s) { 
        return false; 
    }, 
    format: function(s) { 
        return s.replace(/Free/,0).replace(/ CHF/,""); 
    }, 
    type: 'numeric' 
}); 

$(function() { 
    $("table").tablesorter({ 
        headers: { 
            1: { 
                sorter:'price' 
            } 
        } 
    }); 
});
</script>