<?php
session_start();
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("../dbconnection.php");
$d =  $_POST['item_id'];
$details = explode('$',$d);
 $header_id = $details[0];
 $process = $details[1];


$query_merchant_assign=mysql_query("SELECT a.exp_id id,a.exp_date date,b.outlet_name outlet,c.ledger_name ledger,d.party_name party,a.exp_total total,a.exp_cgst cgst,a.exp_sgst sgst,a.exp_cess cess,a.exp_igst igst,a.exp_tds tds,a.exp_grosstotal gross_total,e.bank_name bank,f.method_name pay_method,a.exp_reference reference,a.exp_description description,a.exp_entryby entry_by,a.exp_entytime entry_time FROM cfms_expense a
      LEFT JOIN rem_outlet b ON a.exp_outlet = b.outlet_id
      LEFT JOIN cfms_ledger_master c ON a.exp_ledger = c.ledger_id
      LEFT JOIN cfms_party_master d ON a.exp_party = d.party_id
      LEFT JOIN cfms_bank_master e ON a.exp_bank = e.bank_id
      LEFT JOIN  rem_payment_method f ON a.exp_paymethod = f.method_id
       WHERE a.exp_id='$header_id'");
   
  while($row_item = mysql_fetch_array($query_merchant_assign))
    {
      $id=$row_item['id'];
      $date=$row_item['date'];
      $outlet=$row_item['outlet'];
      $ledger=$row_item['ledger'];
      $party=$row_item['party'];
      $total=$row_item['total'];
      $cgst=$row_item['cgst'];
      $sgst=$row_item['sgst'];
      $cess=$row_item['cess'];
      $igst=$row_item['igst'];
      $tds=$row_item['tds'];
      $gross_total=$row_item['gross_total'];
      $bank=$row_item['bank'];
      $pay_method=$row_item['pay_method'];
      $reference=$row_item['reference'];
      $description=$row_item['description'];
      $entry_by=$row_item['entry_by'];
      $entry_time=$row_item['entry_time'];
    }

    if($process == 'view')
    {
?>

	<table class="table table-bordered" id="table"
               data-toggle="table"
               data-height="460"
               data-sort-name="price"
               data-sort-order="desc" width="100%">
  
    <tbody>

      <tr>
        <td width="30%" id="smallfont"><font size="2">DATE</font></td>
        <td width="80%" id="smallfont" align="right"><font size="2"><?php echo date("d-m-Y", strtotime($date));?></font></td>
        </tr>
    <tr>
        <td width="30%" id="smallfont"><font size="2">OUTLET</font></td>
        <td width="80%" id="smallfont" align="right"><font size="2" align="right"><?php echo $outlet;?></font></td>
    </tr> <tr>
        <td width="30%" id="smallfont"><font size="2">LEDGER</font></td>
        <td width="80%" id="smallfont" align="right"><font size="2" align="right"><?php echo $ledger;?></font></td>
    </tr> <tr>
        <td width="30%" id="smallfont"><font size="2">PARTY</font></td>
        <td width="80%" id="smallfont" align="right"><font size="2" align="right"><?php echo $party;?></font></td>
    </tr> <tr>
        <td width="30%" id="smallfont"><font size="2">TOTAL</font></td>
        <td width="80%" id="smallfont" align="right"><font size="2" align="right"><?php echo $total;?></font></td>
    </tr> <tr>
        <td width="30%" id="smallfont"><font size="2">CGST<br/>SGST<br/>CESS<br/>IGST<br/>TDS</font></td>
        <td width="80%" id="smallfont" align="right"><font size="2" align="right"><?php echo $cgst;?><br/><?php echo $sgst;?><br/><?php echo $cess;?><br/><?php echo $igst;?><br/><?php echo $tds;?></font></td>
    </tr> <tr>
        <td width="30%" id="smallfont"><font size="2">GROSS TOTAL</font></td>
        <td width="80%" id="smallfont" align="right"><font size="2" align="right"><?php echo $gross_total;?></font></td>
    </tr> <tr>
        <td width="30%" id="smallfont"><font size="2">PAY METHOD</font></td>
        <td width="80%" id="smallfont" align="right"><font size="2" align="right"><?php echo $pay_method;?></font></td>
    </tr> <tr>
        <td width="30%" id="smallfont"><font size="2">BANK</font></td>
        <td width="80%" id="smallfont" align="right"><font size="2" align="right"><?php echo $bank;?></font></td>
    </tr> <tr>
        <td width="30%" id="smallfont"><font size="2">REFERENCE</font></td>
        <td width="80%" id="smallfont" align="right"><font size="2" align="right"><?php echo $reference;?></font></td>
    </tr> <tr>
        <td width="30%" id="smallfont"><font size="2">DESCRIPTION</font></td>
        <td width="80%" id="smallfont" align="right"><font size="2" align="right"><?php echo $description;?></font></td>
    </tr> <tr>
        <td width="30%" id="smallfont"><font size="2">ENTRY BY</font></td>
        <td width="80%" id="smallfont" align="right"><font size="2" align="right"><?php echo $entry_by;?></font></td>
    </tr> <tr>
        <td width="30%" id="smallfont"><font size="2">ENTERY TIME</font></td>
        <td width="80%" id="smallfont" align="right"><font size="2" align="right"><?php echo $entry_time;?></font></td>
    </tr>

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
 </tbody>
  </table> 
<?php } else { ?>
<form method="post">
<center>
 <input type="hidden" name="expense_id" id="expense_id" value="<?php echo $header_id; ?>">
  <textarea name="reason" id="reason" class="form-control"></textarea>
  <button type="submit" class="btn btn-danger" name="reject" id="reject">Reject Expense</button>
</center>
</form>
<?php } ?>
