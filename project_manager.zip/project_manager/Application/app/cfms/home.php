<?php 
ob_start();
session_start(); 
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
include("header.php");

$sess_outlet_id=$_SESSION["outlet_id"];
$order_section=$_SESSION["order_section"];

if(isset($_SESSION["outlet_id"]))
{
 ?>
 <style>
.carousel-item .btn {
    position: absolute;
    top: 85%;
    left: 80%;
    transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    background-color: #555;
    color: white;
    font-size: 12px;
    padding: 8px 18px;
    border: none;
    cursor: pointer;
    border-radius: 5px;
    text-align: center;
}

.carousel-item .btn:hover {
    background-color: black;
}
</style>
<style>
.carousel-item .bg-success {
    position: absolute;
    top: 48%;
    left:81%;
    transform: translate(-50%, -50%);
    -ms-transform: translate(-50%, -50%);
    background-color: #555;
    color: white;
    font-size: 12px;
    padding: 6px 28px;
    border: none;
    cursor: pointer;
    border-radius: 5px;
    text-align: center;
}

.carousel-item .bg-success:hover {
    background-color: black;
}
a {
	text-decoration:none;
	color:#000;
}
</style>

<div class="shadow-lg p-2 mb-1 bg-white rounded" style="position:fixed; padding-top:100px; width:100%; z-index:9999; background-color:#FFF !important;">
   
      <h3 class="d-flex justify-content-between align-items-center mb-3	" style="margin: 0 0;">
       <span class="badge badge-secondary badge-pill w3-button w3-black" onclick="myFunction()" style="padding-right:0.5em; padding-top:0.5em; padding-bottom:0.5em; padding-left:0.5em; border-radius: 0.2em;"><i class="fa fa-bars" ></i><div id="Demo" class="w3-dropdown-content w3-bar-block w3-border" style="min-width:200px !important;">
      <a href="index.php" class="w3-bar-item w3-button" ><font size="2" >Change Location/ Branch</font></a>
      <a href="#" class="w3-bar-item w3-button"><font size="2" >Order History</font></a>
      <a href="#" class="w3-bar-item w3-button"><font size="2" >Profile</font></a>
      <a href="logout.php" class="w3-bar-item w3-button"><font size="2" >Logout</font></a>
    </div></span>
      <span class="text-muted"><a href="home.php"><img src="img/logo.png" width="120" /></a></span>
      <span class="badge badge-secondary badge-pill" style="padding-right:0.5em; padding-left:0.5em; padding-top:0.5em; padding-bottom:0.5em; border-radius: 0.2em;"><a href="cart.php" style="text-decoration:none; color:#FFF;"><i class="fa fa-shopping-cart" id="update-cart-value-mobile"> <?php if($gqty >0){ echo $gqty; } else { echo ""; } ?></i></a></span>
      
       </h3>
 
</div>
 


<div id="carouselExampleIndicators" class="carousel slide " data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
   <?php 
	$today_special = mysql_query("SELECT id,dish_id,dish_name,image FROM app_spl_dishes  WHERE dish_id<>''");
	$counter=0;
	while($today_row = mysql_fetch_array($today_special))
	{
	++$counter;?>
    
    	<div class="carousel-item <?php if($counter == 1){ echo "active"; } else { } ?>">
       <br/>
       
    <br/> <!--<div class="shadow-lg p-3 mb-1 bg-white rounded" align="center"><b>TODAY'S SPECIAL</b></div>  -->
    <br/>
</nav>
     		<img class="d-block w-100" src="<?php if($today_row["image"]){?>http://empireapps.in/empire/<?php echo $today_row["image"]; } else { ?>img/noimage.jpg<?php } ?>" alt="First slide">
            <p class="bg-success">Today's Special</p>
            
            
            
            
            
<?php if(isset($_SESSION["order_section"]))
{
		$available_branch_result = mysql_query("select ta.ids,ta.id,hd.dish_id,hd.ids as hdoids,dm.image,dm.dish_name from (select group_concat(outlet_id) ids,dish_id id from outlet_dishes where takeaway_price!=0 and (IsAvailable = 1 or IsAvailable = 'true') and dish_id IN (".$today_row[1].") and outlet_id not in (select ifnull(group_concat(outlet_id),'false')  FROM empire.outletwise_dish_availability_table where date_format(from_date,'%Y-%m-%d') = '2018-04-03' and dish_id in (".$today_row[1].")) group by dish_id ) ta left JOIN (select group_concat(outlet_id) as ids,dish_id from outlet_dishes where homedelivery_price!=0 and (IsAvailable = 1 or IsAvailable = 'true') and dish_id IN (".$today_row[1].") and outlet_id not in (select ifnull(group_concat(outlet_id),'false')  FROM empire.outletwise_dish_availability_table where date_format(from_date,'%Y-%m-%d') = '2018-04-03' and dish_id in (".$today_row[1].")) group by dish_id) hd on ta.id = hd.dish_id JOIN dish_master dm on dm.dish_id = ta.id");
			 
			
			
			while($today_branch = mysql_fetch_array($available_branch_result))
			{
				$today_dishid= $today_branch[1];
				$today_ta_branch= $today_branch[0]; //ta outlet ids
				$today_hd_branch= $today_branch[3]; //hd outlet ids
				$today_dish_image = $today_branch[4]; // dish image
				$today_dish_name = $today_branch[5]; // dih name
		    }
				
				
		
				
				if($order_section == 'TA')
				{
					$usersJoined = $today_ta_branch;
				} 
				else if($order_section == 'HD')
				{
					$usersJoined = $today_hd_branch;
				}
				
					$branches = explode(',', $usersJoined);
   					$check = 0;
					$counter=0;
					foreach($branches as $branch)
					{
						$counter++;
						if(in_array($sess_outlet_id,$branches))
						{?>
							<a class="btn"  href="aboutdish.php?dish=<?php echo $today_row[1]; ?>&dishname=<?php echo $today_dish_name; ?>">
						<?php 
						}
						else
						{?>
              				<!--<a  id="test" class="testd btn" data-toggle="modal" style="color:#FFF;" >-->
              				<a  data-toggle="modal" data-target="#exampleModal" class="btn"  style="color:#FFF;" >
						<?php 
						}
					}
}
else 
{ 
	$available_branch_result = mysql_query("select ta.ids,ta.id,hd.dish_id,hd.ids as hdoids,dm.image,dm.dish_name from (select group_concat(outlet_id) ids,dish_id id from outlet_dishes where takeaway_price!=0 and (IsAvailable = 1 or IsAvailable = 'true') and dish_id IN (".$today_row[1].") and outlet_id not in (select ifnull(group_concat(outlet_id),'false')  FROM empire.outletwise_dish_availability_table where date_format(from_date,'%Y-%m-%d') = '2018-04-03' and dish_id in (".$today_row[1].")) group by dish_id ) ta left JOIN (select group_concat(outlet_id) as ids,dish_id from outlet_dishes where homedelivery_price!=0 and (IsAvailable = 1 or IsAvailable = 'true') and dish_id IN (".$today_row[1].") and outlet_id not in (select ifnull(group_concat(outlet_id),'false')  FROM empire.outletwise_dish_availability_table where date_format(from_date,'%Y-%m-%d') = '2018-04-03' and dish_id in (".$today_row[1].")) group by dish_id) hd on ta.id = hd.dish_id JOIN dish_master dm on dm.dish_id = ta.id");
	while($today_branch = mysql_fetch_array($available_branch_result))
	{
		$today_dishid= $today_branch[1];
		$today_ta_branch= $today_branch[0]; //ta outlet ids
		$today_hd_branch= $today_branch[3]; //hd outlet ids
		$today_dish_image = $today_branch[4]; // dish image
		$today_dish_name = $today_branch[5]; // dih name
	}?>
  	<a href="choosedelivery.php?dish=<?php echo $today_row[1]; ?>&ta=<?php echo $today_ta_branch; ?>&hd=<?php echo $today_hd_branch; ?>">    	
<?php	
} 
?>
Grab Now</a>
         
           
   		</div>
    <?php } ?>
    
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<div class="shadow-lg p-3 mb-1 bg-white rounded" >
    <label for="exampleInputEmail1"><font color="#000000"><b>Search Dishes :</b></font></label>
    <input type="text" class="form-control" i name="search" id="search" autofocus="autofocus"  onkeyup="showdish1(this.value)"  aria-describedby="emailHelp" placeholder="Search Dishes">
   
  </div>
<div id="DisplayDish1">
<div class="shadow-lg p-3 mb-1 bg-white rounded" > <small id="emailHelp" class="form-text text-muted"><font color="#000000"><b>List Of Categories</b></font></small></div>

<?php
$categories = mysql_query("select od.dish_cat_id,dcm.category_name,dcm.image from dish_master  as dm join outlet_dishes od  ON dm.dish_id=od.dish_id and dm.dish_category_id=od.dish_cat_id join dish_category_master  dcm on dcm.dish_category_master_id= dm.dish_category_id join hdcategory_outletlist hdl on hdl.hdcategory_id=dcm.dish_category_master_id  where dcm.is_offer=0 and od.outlet_id='$sess_outlet_id' and hdl.outlet_id='$sess_outlet_id' group by dcm.category_name order by hdl.order_priority ASC");
		while($category_row = mysql_fetch_array($categories))
		{ ?>
			<a href="ordernow.php?category=<?php echo $category_row[0]; ?>" style="text-decoration:none; color:#000;"><div class="shadow-lg p-3 mb-1 bg-white rounded"><img src="<?php if($category_row[2]){?>http://empireapps.in/empire/<?php echo $category_row[2]; } else { ?>assets/images/noimage.jpg<?php } ?>" class="rounded-rounded"  alt="" width="20%"><font size="2">&nbsp;<?php echo strtoupper($category_row[1]); ?></font></div>
<?php   } ?>
</div>
<!--<br/><br/>
 --><script>
function myFunction() {
    var x = document.getElementById("Demo");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
</script>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-sm" role="document">
  <br/><br/><br/>
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel" align="center"> <center> Alert Message</center></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Dish is not available in current location..
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>
<script>
function showdish1(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("DisplayDish1").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getdish.php?q="+str,true);
  xmlhttp.send();
}
</script> 

<script>
   //ajax + click event
   $(document).on('click','.update-class',function(event){
	   event.preventDefault()
   	var this1 = this;
   	var cart_update_url = $(this1).attr('url');
	 console.log(this1);
   	var current_qty = $(this1).closest('.qty-wrapper-class').find('.cart-qty').val();
   	if(current_qty>=0){
   		$.ajax({
   			url:cart_update_url,
   			type:'POST',
   			data:{current_qty:current_qty},
   			success:function(data){ 
			response = $.parseJSON(data);
			
			qty = response.qty;
			cart_message = response.cart_message;
			html = response.html;
			mobile_cart = response.mobile_cart;
			$('#update-cart-value').html(html);
			$('#update-cart-value-mobile').html(mobile_cart);
			$('#update-cart-message').html(cart_message);
			
			$(this1).closest('.qty-wrapper-class').find('.cart-qty').val(qty);
   			}
   		});
   	}else{
   		$(this1).closest('.qty-wrapper-class').find('.cart-qty').val('0');
   	}
   });
   </script>
   
  <?php  } else { 
  header("Location: index.php");
  } ?>
