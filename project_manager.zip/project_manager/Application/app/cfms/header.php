<!DOCTYPE html>
<html lang="en">
  <head>
  
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Hotel Empire Online Food Order | Home Delivery</title>
	<link rel="shortcut icon" href="img/fav-icon.png">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
  <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
 
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>	
 <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 
<style>
footer {
    /* just for demo */
    background-color: #CCC;
    border-top: 1px solid #E7E7E7;
    text-align:center;
	padding-top:3px;
	color:#000;
   
   /* just for demo */ 
  
    position: fixed;
    left: 0;
    bottom: 0;
    height: 40px;
    width: 100%;
}
</style>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('img/loader.gif') 50% 50% no-repeat rgb(249,249,249);
	background-size: 100px;
    opacity: .8;
	
	
}
</style>
<div class="loader"></div>
   

<script type="text/javascript">

	$(window).load(function () {
        setTimeout(function(){
            $('.loader').fadeOut('slow', function () {
            });
        },250); // set the time here
    });  
	
</script>
<?php     
$srno = 0;
	$gtot=0;
	for($i=1;$i<$_SESSION["cnt"];$i++)
	{
		$srno++;
		$tot=$_SESSION["qty$i"]*$_SESSION["price$i"]; 
		$quantity = $_SESSION["qty$i"];
		$gqty+=$quantity;
		$gtot+=$tot;
	}
?>
  </head>
  <body class="bg-light">