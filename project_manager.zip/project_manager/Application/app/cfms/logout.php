<?php 
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE); 
include("../..dbconnection.php");
session_destroy();
header("Location: index.php");
?>
