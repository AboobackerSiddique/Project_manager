<div class="shadow-lg p-2 mb-1 bg-white rounded" style="position:fixed; padding-top:100px; width:100%; z-index:9999; background-color:#FFF !important;">
   
      <h3 class="d-flex justify-content-between align-items-center mb-3	" style="margin: 0 0;">
       <span class="badge badge-secondary badge-pill w3-button w3-black" onclick="myFunction()" style="padding-right:0.5em; padding-top:0.5em; padding-bottom:0.5em; padding-left:0.5em; border-radius: 0.2em;"><i class="fa fa-bars" ></i><div id="Demo" class="w3-dropdown-content w3-bar-block w3-border" style="min-width:200px !important;">
      <a href="index.php" class="w3-bar-item w3-button" ><font size="2" >Change Location/ Branch</font></a>
      <a href="#" class="w3-bar-item w3-button"><font size="2" >Order History</font></a>
      <a href="#" class="w3-bar-item w3-button"><font size="2" >Profile</font></a>
    </div></span>
      <span class="text-muted"><a href="home.php"><img src="img/logo.png" width="120" /></a></span><span class="badge badge-secondary badge-pill" style="padding-right:0.5em; padding-left:0.5em; padding-top:0.5em; padding-bottom:0.5em; border-radius: 0.2em;"><a href="cart.php" style="text-decoration:none; color:#FFF;"><i class="fa fa-shopping-cart" id="update-cart-value-mobile"><span class="d-flex justify-content-between align-items-center mb-3	" style="margin: 0 0;"><span class="badge badge-secondary badge-pill" style="padding-right:0.5em; padding-left:0.5em; padding-top:0.5em; padding-bottom:0.5em; border-radius: 0.2em;"><a href="cart.php" style="text-decoration:none; color:#FFF;"><i class="fa fa-shopping-cart" id="update-cart-value-mobile2">
      <?php if($gqty >0){ echo $gqty; } else { echo ""; } ?>
      </i></a></span></span></i></a></span></h3>
 
</div>
 