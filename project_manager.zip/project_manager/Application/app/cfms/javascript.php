<script type="text/javascript">
if (screen.width >= 699) {
document.location = "http://empireapps.in/";
}
</script> 
<script language=javascript>

if ((navigator.userAgent.match(/iPhone/i)) || (navigator.userAgent.match(/iPod/i))) {
   location.replace("http://url-to-send-them/empireapps.in");
}

</script> 


<style>
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url('img/loader.gif') 50% 50% no-repeat rgb(249,249,249);
	background-size: 100px;
    opacity: .8;
	
	
}
</style>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
<div class="loader"></div>
<script type="text/javascript">

	$(window).load(function () {
        setTimeout(function(){
            $('.loader').fadeOut('slow', function () {
            });
        },250); // set the time here
    });  
	
</script>