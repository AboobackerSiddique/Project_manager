<?php
// echo "Hai";
// die;

// session_start();
include("dbconnection.php");
//Login to admin account

  $usernames = $_POST["user_name"];
  $passwords = $_POST["password"];

  // print_r($_POST);

  

$resultlogin = mysql_query("SELECT user_id,user_name,user_password,user_type,user_freeze,user_outlet FROM rem_user WHERE user_name ='$usernames' AND user_password='$passwords'");

  // print_r(mysql_fetch_array($resultlogin));
while($row = mysql_fetch_array($resultlogin))
{
  $user_id = $row["user_id"];
  $user_name = $row["user_name"];
  $password = $row["user_password"];
  $user_type = $row["user_type"];
  $user_freeze = $row["user_freeze"];
  $user_outlet = $row["user_outlet"];

  // print_r($row);die;
  
}
  // print_r($user_id);die;
  

  if(mysql_num_rows($resultlogin) == 1)
  {
    
      $a =array("status"=> "success","username"=> $user_name,"usertype"=> $user_type,"userid"=> $user_id,"password"=> $password,"useroutlet"=> $useroutlet);
    
  }
  else
  {
      $a =array("status"=> "failed","message"=>"Invalid Username Or Password");
  }
      echo json_encode($a);



?>