
<?php
$con = mysql_connect("localhost","root","admin");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }

mysql_select_db("manager_project_lh", $con);


$conn=mysql_connect("localhost","root","admin") or die(mysql_error());

$sdb=mysql_select_db("manager_project_lh",$conn) or die(mysql_error());
$test ='';
?>