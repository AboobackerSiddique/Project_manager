<?php
ob_start();
session_start();
include("dbconnection.php");
error_reporting(E_ERROR | E_PARSE);// set time-out period (in seconds)
$item_id =  $_POST['item_id'];
?>
       
<table class="table table-bordered" id="table"
               data-toggle="table"
               data-height="460"
               data-sort-name="price"
               data-sort-order="desc" width="100%">

<tr>
<td colspan="2"><b>Item Name & Description</b></td>

	
<?php 
	$items = mysql_query("SELECT item_id,item_name FROM rem_item WHERE item_id='$item_id'");
	$counter=0;
   	while($row_item = mysql_fetch_array($items))
	{?>
<tr>
<td colspan="2" align="center"><font size="2" color="#FF0000"><B><?php echo $row_item[1]; ?></B></font><br/> <?php 
	$result_mapping = mysql_query("SELECT b.name,a.map_values FROM rem_item_mapping a LEFT JOIN rem_item_specification b ON a.map_specification_id=b.id WHERE a.map_item_id='$row_item[0]'");
	while($row_mapping = mysql_fetch_array($result_mapping))
  	{
		echo "<b>".$row_mapping[0]." :</b>&nbsp;".$row_mapping[1].",&nbsp;";
	}
	?>
</td>
                   
</tr>
<?php } ?>

<tr style="background-color:#CCC;">
<td width="75%" ><b>Vendor Name </b>&nbsp;</td>
<td align="right" width="25%"><b>Item Price</b></td>
</tr>
<?php 
$result_vendor = mysql_query("SELECT a.assign_id,b.vendor_name,a.assign_item_price FROM rem_vendor_item_assign a LEFT JOIN rem_vendor b ON a.assign_vendor=b.vendor_id WHERE a.assign_item='$item_id'");
	while($row_vendor = mysql_fetch_array($result_vendor))
  	{?>
<tr >
<td ><?php echo $row_vendor[1]; ?> &nbsp;</td>
<td align="right"> &#8377 <?php echo round($row_vendor[2], 0); ?>/-</td>
</tr>

<?php } ?>
</table>