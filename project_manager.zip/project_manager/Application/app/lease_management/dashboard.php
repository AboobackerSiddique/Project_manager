<?php
ob_start();
error_reporting(E_ERROR | E_PARSE);
session_start();
include("header.php"); 
include("dbconnection.php");
?>
 <style> 
 body, html {
    height: 100%;
    margin: 0;
}

.bg {
    /* The image used */
    background-image: url("img/bg.jpg");

    /* Full height */
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
	
}
.start {
 position: absolute;
     margin: auto;
     top: 0;
     right: 0;
     bottom: 0;
     left: 0;
     width: 100%;
     height: 100%;

} 

.btn {
  background-color: #F9F9F9;
  width:100%;
  border: none;
  color: black;
  padding: 16px 32px;
  text-align: center;
  font-size: 14px;
  margin:2px;
  transition: 0.3s;
}

.btn:hover {
  background-color: #B92626;
  color: white;
}
</style>


<div class="shadow-lg p-3 mb-1 bg-white rounded" style="position:fixed; width:100%; z-index:9999;">
   <a href="../index.php" >Home</a> | LEASE MANAGEMENT
 
</div>
 
	<div class="bg">
	<div class="start">
	<center>
	<br/><br/><br/><br/>
	<div class="form-group col-md-6">
            	<a href="balancereports.php?outlet=ALL" class="btn" >View All Agreements (<b><font color="#FF0000"><?php $resultlogin = mysql_query("SELECT COUNT(*) FROM rem_agreement");
	while($row = mysql_fetch_array($resultlogin))
	{
		if($row[0] == '0')
		{
			echo "0";
		}
		else
		{
			echo $row[0];
		}; 
	} ?></font></b>)</a>
                
    </div>	
	</center>
	</div>
	</div>