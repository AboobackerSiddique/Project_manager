<?php
ob_start();
session_start();
include("dbconnection.php");
error_reporting(E_ERROR | E_PARSE);// set time-out period (in seconds)
$d =  $_POST['item_id'];
$details = explode('$',$d);
$item_id = $details[0];
$category = $details[1];

$query_assign=mysql_query("SELECT a.assign_id id,a.assign_item itemid,b.item_name itemname,c.outlet_name outlet,d.merchant_name merchant,a.assign_price price,a.assign_qty qty,a.assign_amount total,b.item_ordertype type FROM rem_merchant_item_assign a LEFT JOIN rem_item b ON a.assign_item=b.item_id
LEFT JOIN rem_outlet c ON a.assign_outlet=c.outlet_id 
LEFT JOIN rem_merchant d ON a.assign_merchant=d.merchant_id WHERE b.item_id='$item_id' ");
			
		while($row_assign = mysql_fetch_assoc($query_assign))
		{
			$details_assign[] = $row_assign;
		}
		
		$query_order=mysql_query("SELECT a.details_id id,a.details_header_id pono,a.details_item itemid,b.item_name itemname,c.vendor_name vendor,d.merchant_name merchant,a.details_price price,a.details_qty qty,a.details_amount total,a.details_order_type type,a.details_delivery_date delivery_date FROM rem_order_details a LEFT JOIN rem_item b ON a.details_item=b.item_id
LEFT JOIN rem_vendor c ON a.details_vendor_id=c.vendor_id 
LEFT JOIN rem_merchant d ON a.details_merchant=d.merchant_id WHERE a.details_item='$item_id' ");
			
		while($row_order = mysql_fetch_assoc($query_order))
		{
			$details_order[] = $row_order;
		}			
		
		
		$query_delivery=mysql_query("SELECT a.details_id id,a.details_po pono,a.details_item itemid,b.item_name itemname,c.vendor_name vendor,a.details_qty qty FROM rem_delivery_details a LEFT JOIN rem_item b ON a.details_item=b.item_id
LEFT JOIN rem_vendor c ON a.details_vendor=c.vendor_id  WHERE a.details_process=1 AND a.details_item='$item_id' ");
			
		while($row_delivery = mysql_fetch_assoc($query_delivery))
		{
			$details_delivery[] = $row_delivery;
		}
		$result = mysql_query("SELECT item_name FROM rem_item WHERE item_id='$item_id'");
	while($row = mysql_fetch_array($result))
  	{
		$item_name = $row[0];
	}
?>
<center><font size="2"><?php echo $item_name; ?></font></center>
<?php 
if($category == 'assign') 
{?>
<table class="table table-bordered" id="table"
               data-toggle="table"
               data-height="460"
               data-sort-name="price"
               data-sort-order="desc" width="100%">
    <thead>
      <tr>
        <th width="5%">SLNo</th>
       
      
         <th width="75%">Outlet<br/>Merchant</th>
         
        <th width="10%">PRICE<br/>QTY</th>
        
        <th width="10%">TOTAL</th>
 
        
              
      </tr>
    </thead>
    <tbody>
    <?php
				
	$counter=0;
	foreach($details_assign as $i):				
					
	  ?>
      <tr>
        <td><?php echo ++$counter; ?></td>
        
        <td><?php print_r($i['outlet']) ;?> - (<?php print_r($i['merchant']) ;?>)</td>
       
        <td><?php print_r(round($i['price'],0)); ?>*<?php print_r(round($i['qty'],0)) ;?></td>
        <td><?php print_r(round($i['total'],0)) ;?></td> 
        

      </tr>
		<?php
		endforeach;
		?> 

  <tr>
        <td colspan="2">TOTAL</td>
        <td ><?php 	
		$category = mysql_query("SELECT SUM(assign_qty) FROM rem_merchant_item_assign WHERE assign_item='$item_id'");
						while($row_category  = mysql_fetch_array($category))
						{ 
						echo round($row_category[0],0);
						}?></td>
                        <td></td>
        
      </tr>
    </tbody>
  </table>
<?php 
}
else if($category == 'order') 
{?>
<table class="table table-bordered" id="table"
               data-toggle="table"
               data-height="460"
               data-sort-name="price"
               data-sort-order="desc" width="100%">
    <thead>
      <tr>
        <th width="5%">SLNO</th>
        <th width="20%">PONO<br/>DLVRYDATE</th>
      
 <th width="55%">VENDOR</th>
        <th width="10%">PRICE<br/>QTY</th> 
        <th width="10%">TOTAL</th>
 
        
              
      </tr>
    </thead>
    <tbody>
    <?php
				
	$counter=0;
	foreach($details_order as $r):				
					
	  ?>
      <tr>
        <td><?php echo ++$counter;?></td>
        <td><?php if($r['type'] == '1'){ echo "PO"; } else { echo "WO"; } ?>-<?php print_r($r['pono']) ;?><BR/><?php print_r($r['delivery_date']) ;?></td>
       

     <td><?php print_r($r['vendor']) ;?></td>
     <td><?php print_r(round($r['price'],0)) ;?>*<?php print_r(round($r['qty'],0)) ;?></td>
     <td><?php print_r(round($r['total'],0)) ;?></td>
        

      </tr>
		<?php
		endforeach;
		?> 
 <tr>
        <td colspan="3">TOTAL</td>
        <td><?php 	
		$category = mysql_query("SELECT SUM(details_qty) FROM rem_order_details WHERE details_item='$item_id'");
						while($row_category  = mysql_fetch_array($category))
						{ 
						echo $row_category[0];
						}?></td>
                        <td></td>
        
      </tr>
 
    </tbody>
  </table>
 
<?php 
}

else if($category == 'delivery') 
{?>
<table class="table table-bordered" id="table"
               data-toggle="table"
               data-height="460"
               data-sort-name="price"
               data-sort-order="desc" width="100%">
    <thead>
      <tr>
        <th width="5%">SLNO</th>
        <th  width="10%">PO NO</th>

        <th  width="75%">VENDOR</th>
        <th  width="10%">QTY</th>
 
        
              
      </tr>
    </thead>
    <tbody>
    <?php
				
	$counter=0;
	foreach($details_delivery as $k):				
					
	  ?>
      <tr>
        <td><?php echo ++$counter;?></td>
        <td><?php print_r($k['pono']) ;?></td>
        <td><?php print_r($k['vendor']) ;?></td>
       	<td><?php print_r($k['qty']) ;?></td>
       
        

      </tr>
		<?php
		endforeach;
		?> 

 <tr>
        <td colspan="3">TOTAL</td>
        <td ><?php 	
		$category = mysql_query("SELECT SUM(details_qty) FROM rem_delivery_details WHERE details_item='$item_id'");
						while($row_category  = mysql_fetch_array($category))
						{ 
						echo $row_category[0];
						}?></td>
        
      </tr>
    </tbody>
  </table>

<?php 
}

else if($category == 'balance') 
{?>
<table class="table table-bordered" id="table"
               data-toggle="table"
               data-height="460"
               data-sort-name="price"
               data-sort-order="desc" width="100%">
    <thead>
      <tr>
        <th width="5%">SL No</th>
        <th  width="40%">ORDR Date<br/>DLVR Date</th>
 
      
         <th  width="10%">PONO</th>
      
        <th  width="35%">VENDOR NAME</th>
        <th  width="10%">QTY</th> 
       
      </tr>
    </thead>
    <tbody>
   <?php 
$counter=0;

		$query_item=mysql_query("SELECT a.details_header_id po,DATE(a.details_date) orderdate,e.delivery deliverydate,b.item_name itemname,c.vendor_name vendorname,a.details_qty order_qty,d.deliveryqty,a.details_item itemid,a.details_vendor_id vendorid FROM rem_order_details a LEFT JOIN rem_item b ON a.details_item=b.item_id LEFT JOIN rem_vendor c ON a.details_vendor_id=c.vendor_id LEFT JOIN(SELECT details_item,SUM(details_qty) deliveryqty FROM rem_delivery_details GROUP BY details_po,details_item) AS d ON d.details_item=a.details_item  LEFT JOIN (SELECT order_header_id,order_delivery_date delivery FROM rem_order WHERE order_type=1) AS e ON e.order_header_id=a.details_header_id  WHERE a.details_order_type=1 AND a.details_item='$item_id' GROUP BY a.details_header_id,a.details_item ORDER BY a.details_header_id");
	
	while($row_item =  mysql_fetch_array($query_item))
	{
		if(isset($_GET['vendor_id']))
		{ 
		$query_items=mysql_query("SELECT SUM(details_qty) FROM rem_delivery_details WHERE details_po='$row_item[0]' AND details_item='$row_item[7]' AND details_vendor='$_GET[vendor_id]'");
		}
		else
		{
		$query_items=mysql_query("SELECT SUM(details_qty) FROM rem_delivery_details WHERE details_po='$row_item[0]' AND details_item='$row_item[7]'");
		}
		while($row_items =  mysql_fetch_array($query_items))
		{
			$delivered_qty1=$row_items[0];
		}
		
		$ordered_qty=$row_item[5];
		$delivered_qty=$row_item[6];
		$required_qty=$ordered_qty-$delivered_qty1;
		
			
	if($required_qty>0)
	{
		date_default_timezone_set('Asia/Calcutta');
		$current_date=date("Y-m-d");
		if($current_date<=$row_item[2])
		{
	?>
      <tr>
  <?php }
  		else
		{?>
        <tr style="background-color:#FC9;">
        <?php 
		} 
		?> 
	
        <td><?php echo ++$counter; ?></td>
        <td><?php echo date("d-m-Y",strtotime($row_item[1])); ?><br/><?php  echo date("d-m-Y",strtotime($row_item[2])); ?></td>
      
       
        <td><?php echo $row_item[0]; ?></td>
     
        <td><?php echo $row_item[4]; ?></td>
        <td><?php 
$ordered_qty1= $row_item[5];


echo $required_qty1=$ordered_qty1-$delivered_qty1;
?></td> 
       
 </tr>
		<?php }} ?>

 
    </tbody>
  </table>
<?php } ?>
      