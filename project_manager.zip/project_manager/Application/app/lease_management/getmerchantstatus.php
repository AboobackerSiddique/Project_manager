<?php
session_start();
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
$d =  $_POST['item_id'];
$details = explode('$',$d);
$merchant_id = $details[0];
$outlet_id = $details[1];

$result_merchant = mysql_query("SELECT a.assign_counter counter_id,b.counter_name counter_name,c.merchant_name merchant_name,a.assign_merchant merchant_id,d.outlet_name outlet_name FROM rem_counter_assign a LEFT JOIN rem_counter_master b ON a.assign_counter=b.counter_id LEFT JOIN rem_merchant c ON a.assign_merchant=c.merchant_id LEFT JOIN rem_outlet d ON a.assign_outlet=d.outlet_id  WHERE a.assign_outlet='$outlet_id' AND a.assign_counter='$merchant_id'");
					
while($row_merchant = mysql_fetch_array($result_merchant))
  {
	  $counter_id = $row_merchant['counter_id'];
	  $merchant_name =$row_merchant['merchant_name'];
	  $counter_name=$row_merchant['counter_name'];
	  $merchant_id =$row_merchant['merchant_id'];
	  $outlet_name =$row_merchant['outlet_name'];
 }
?>
<center><h4><?php echo $outlet_name; ?>(<?php echo $counter_name; ?>-<?php echo $merchant_name; ?>)</h4></center>

	<table class="table table-bordered" id="table"
               data-toggle="table"
               data-height="460"
               data-sort-name="price"
               data-sort-order="desc" width="100%">
  
      <tr>
       

         <td width="50%" ><b>MERCHANT_DETAIL</b></td>
        
        <td align="center" width="50%"><b>STATUS</b></td>
        
                  
      </tr>
   
    <tbody>
 <?php
							$result_item = mysql_query("SELECT cat_id,cat_name FROM rem_merchant_category");
							$counter=0;
							while($row_item = mysql_fetch_array($result_item))
  							{ ?>
      <tr>
        <td width="50%"><?php echo $row_item['cat_name']; ?></td>
        <td width="50%" align="center">
        <?php 
		$result_items = mysql_query("SELECT a.assign_status,b.status_name FROM rem_merchant_category_assign a LEFT JOIN rem_status_master b ON a.assign_status=b.status_id WHERE a.assign_outlet='$outlet_id' AND a.assign_merchant='$merchant_id' AND a.assign_category='$row_item[0]'");
							$counter=0;
							while($row_items = mysql_fetch_array($result_items))
  							{ 
								echo $row_items[1];
							}
							?></td>
    
       
    
      </tr>
	<?php
  }
	?>
 </tbody>
  </table>


