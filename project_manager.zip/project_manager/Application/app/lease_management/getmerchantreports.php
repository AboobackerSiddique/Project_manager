<?php
session_start();
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
$d =  $_POST['item_id'];
$details = explode('$',$d);
$pono = $details[0];
$type = $details[1];
$vendor = $details[2];
$vendor_name = $details[3];
$max = mysql_query("SELECT a.order_date,a.order_advance,a.order_advance_desc,b.method_name FROM rem_order a LEFT JOIN rem_payment_method b ON a.order_advance_paymethod=b.method_id WHERE a.order_header_id='$pono' AND a.order_type='$type'");
	while($row_max = mysql_fetch_array($max))
	{
		$ordered_date = $row_max[0];
		$ordered_amount = $row_max[1];
		$ordered_advance = $row_max[2];
		$ordered_method = $row_max[3];
	}

?>
 <style>

th, td {
    padding: 5px;
	font-size:10px;
}

</style> 
(<?php if($type == '1'){ echo "PO"; } else { echo "WO"; } ?> NO-<?php echo $pono; ?>)- <?php echo $vendor_name; ?> <br/>    
<table class="table table-bordered" id="table"
               data-toggle="table"
               data-height="460"
               data-sort-name="price"
               data-sort-order="desc" width="100%">
<tr>
<td width="5%"><b>SLNO</b></td>
<td width="71%" ><b>ITEM NAME</b></td>
<td align="right" width="8%" ><b>QTY</b></td>
<td align="center" width="8%"><b>TAX AMT</b></td>
<td align="center" width="8%"><b>TOTAL</b></td>

</tr>
<?php 
$result = mysql_query("SELECT b.item_name,b.item_unit,a.details_price,a.details_qty,a.details_amount,a.details_tax,a.details_tax_amount FROM rem_order_details a LEFT JOIN rem_item b ON a.details_item=b.item_id WHERE a.details_header_id='$pono' AND a.details_order_type=$type");
$counter=0;
$sum=0;
while($row = mysql_fetch_array($result))
{
	$tax_sum+=$row[6];
	$sum+=$row[4];

?>
<tr >
<td  ><?php echo ++$counter; ?></td>
<td ><?php echo $row[0]; ?></td>
<td align="center"><?php echo round($row[3],2); ?></td>
<td  align="right" ><?php echo $row[6]; ?></td>
<td  align="right" ><?php echo $row[4]; ?></td>
</tr>

<?php } ?>
 <tr>

<td align="right"  colspan="3"><b>Total Payable</b></td>
<td  align="right" ><b><?php echo $tax_sum; ?></b></td>
<td  align="right"><b><?php echo $sum; ?></b></td>
</tr>
<tr>

<td align="right"  colspan="4"><b>Advance Paid</b></td>
<td  align="right" ><b><?php

 $result212 = mysql_query("SELECT order_advance FROM rem_order  WHERE order_header_id='$_GET[pono]' AND order_type='$_GET[type]'");
while($row212 = mysql_fetch_array($result212))
{
	$advance_paid=round($row212[0],0);	
}

$result213 = mysql_query("SELECT SUM(payment_amount)FROM rem_order_payment WHERE payment_order_id='$_GET[pono]' AND payment_order_type='$_GET[type]'");
while($row213 = mysql_fetch_array($result213))
{
	$payment=round($row213[0],0);
}

echo $advance=$advance_paid+$payment;
 ?></b></td>
</tr>
<tr>

<td align="right"  colspan="4"><b>Balance Payable</b></td>
<td  align="right"><b><?php echo round($sum-$advance,0); ?></b></td>
</tr>	
</table>
<br/>
Payment History
<br/>
 <table class="table table-bordered" id="table"
               data-toggle="table"
               data-height="460"
               data-sort-name="price"
               data-sort-order="desc">
<tr>
<td width="5%" ><font size="2"><b>SL NO</b></font></td>
<td width="15%" ><font size="2"><b>Date of Payment</b></font></td>
<td width="15%" align="center"><font size="2"><b>Pay Method</b></font></td>
<td align="right" width="10%" ><font size="2"><b>Amount Paid</b></font></td>

<td  width="20%"><font size="2"><b>Payment Description</b></font></td>

</tr>
<?php if($ordered_amount == 0)
{
}
else
{?>
<tr >
<td ><?php echo "1"; ?></td>
<td ><?php echo date("d-m-Y h:i:a",strtotime($ordered_date)); ?></td>
<td  align="center"><?php echo $ordered_method; ?></td>
<td align="right" ><?php echo round($ordered_amount,2); ?></td>

<td ><?php echo $ordered_advance; ?></td>

</tr>
<?php } ?>
<?php 
$result = mysql_query("SELECT a.payment_id,a.payment_date,a.payment_amount,b.method_name,a.payment_description FROM rem_order_payment a LEFT JOIN rem_payment_method b ON a.payment_type=b.method_id WHERE a.payment_order_id='$pono' AND a.payment_order_type='$type'");
$counter=1;
$sum=0;
while($row = mysql_fetch_array($result))
{
	$sum+=$row[2];
?>
<tr >
<td ><?php echo ++$counter; ?></td>
<td ><?php echo date("d-m-Y h:i:a",strtotime($row[1])); ?></td>
<td  align="center"><?php echo $row[3]; ?></td>
<td align="right" ><?php echo $row[2]; ?></td>

<td ><?php echo $row[4]; ?></td>

</tr>

<?php } ?>
 <tr>

<td align="right"  colspan="3"><b>Total Paid</b></td>
<td  align="right" width="10%"><b><?php echo $sum+$ordered_amount; ?></b></td>
<td ></td>
</tr>

</table>