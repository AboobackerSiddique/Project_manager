<?php
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php"); 
include("header.php"); 

if(isset($_POST["submit"]))
{
	header("Location: advancereports.php?vendor=$_POST[vendor]");
}

if($_GET['vendor'] == 'ALL')
		{
			$query_merchant_assign=mysql_query("SELECT a.order_advance_no advance_no,a.order_header_id pono,a.order_type type,a.order_date date,b.vendor_name vendor,a.order_advance amount,c.method_name method,a.order_advance_desc description,a.display display,a.order_vendor vendor_id,d.advance_nos advance_nos FROM rem_order a LEFT JOIN rem_vendor b ON a.order_vendor=b.vendor_id LEFT JOIN rem_payment_method c ON a.order_advance_paymethod=c.method_id LEFT JOIN rem_advance d ON a.order_advance_no=d.advance_no  WHERE a.order_advance_no!='0' UNION ALL SELECT j.payment_advance_no advance_no,j.payment_order_id pono,j.payment_order_type type,j.payment_date date,k.vendor_name vendor,j.payment_amount amount,l.method_name method,j.payment_description description,j.display display,j.payment_vendor_id vendor_id,m.advance_nos advance_nos FROM rem_order_payment j LEFT JOIN rem_vendor k ON j.payment_vendor_id=k.vendor_id LEFT JOIN rem_payment_method l ON j.payment_type=l.method_id LEFT JOIN rem_advance m ON j.payment_advance_no=m.advance_no  ORDER BY 1 DESC");
		}
		else
		{
			$query_merchant_assign=mysql_query("SELECT a.order_advance_no advance_no,a.order_header_id pono,a.order_type type,a.order_date date,b.vendor_name vendor,a.order_advance amount,c.method_name method,a.order_advance_desc description,a.display display,a.order_vendor vendor_id,d.advance_nos advance_nos FROM rem_order a 
LEFT JOIN rem_vendor b ON a.order_vendor=b.vendor_id 
LEFT JOIN rem_payment_method c ON a.order_advance_paymethod=c.method_id LEFT JOIN rem_advance d ON a.order_advance_no=d.advance_no
WHERE a.order_advance_no!='0' AND a.order_vendor='$_GET[vendor]'
UNION ALL
SELECT j.payment_advance_no advance_no,j.payment_order_id pono,j.payment_order_type type,j.payment_date date,k.vendor_name vendor,j.payment_amount amount,l.method_name method,j.payment_description description,j.display display,j.payment_vendor_id vendor_id,m.advance_nos advance_nos FROM rem_order_payment j 
LEFT JOIN rem_vendor k ON j.payment_vendor_id=k.vendor_id 
LEFT JOIN rem_payment_method l ON j.payment_type=l.method_id LEFT JOIN rem_advance m ON j.payment_advance_no=m.advance_no  WHERE j.payment_vendor_id='$_GET[vendor]'
ORDER BY 1 DESC");
		}
		
	while($row_item = mysql_fetch_assoc($query_merchant_assign))
		{
			$details_item[] = $row_item;
		}
		
?>


<div class="shadow-lg p-3 mb-1 bg-white rounded" style="position:fixed; width:100%; z-index:9999;">
   <a href="dashboard.php" class="btn btn-success btn-sm">Back</a>
 
</div>
 
 <br/>
<br/>
<br/>



  <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #ddd;
}

th, td {
    padding: 5px;
	font-size:10px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<h2>&nbsp;Advance Reports &nbsp;<a data-toggle="modal" href="#myModals" style="background-color:#666;" class="btn btn-success btn-sm"><i class="fa fa-filter"></i> More Filter</a> </h2>

<div >
  <p align="right"><font color="#000000">Smart Search  : &nbsp;</font><input type="search" class="light-table-filter" data-table="table-bordered" placeholder="Filter">&nbsp;&nbsp;</p>    
  </div>
   <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg" style="width:95%; padding-top:100px;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">PO/WO Details</h4>
           <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body ">
                <label id='ur_id'><label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>   
  <button style="display:none" type="button" class="btn btn-info btn-lg btn_open_modal" data-toggle="modal" data-target="#myModal">Open Modal</button>   
<div style="overflow-x:auto;">
  
  <table class="table-bordered">
  <thead>
    <tr>
      <th width="4%">SLNO</th>
      <th width="84%" colspan="2">DATE,ADV NO,VENDOR & NARRATION</th>
    <th width="12%">AMOUNT</th>

        
    </tr>
    </thead>
    <?php
	$total_Advance=0;
	$counter=0;
	foreach($details_item as $i):	
	$total_Advance+=$i['advance'];			
	?>
    <tr>
      <td width="4%"><?php echo ++$counter; ?></td>
      <td align="right" width="20%"><font size="1">PAID DATE<br/>PO/WO NO<br/>ADVNCE NO<br/>VENDOR<br/>NARRATIION</font></td>
      <td width="64%"><font size="1"><?php echo date("d-m-Y h:i:a", strtotime($i['date'])) ;?><br/><?php if($i['type'] == '1') { print_r("<font color='#009966'>PO- ".$i['pono']); } else { print_r("<font color='#FF0000'>WO- ".$i['pono']); } ?></font><br/><?php  print_r($i['advance_nos']); ?><br/><?php print_r($i['vendor']) ;?><br/><?php print_r($i['description']) ;?></font></td>
      
       <td width="12%" align="right"><font size="1"><?php $amount=$i['amount'];
		$fmt = new NumberFormatter($locale = 'en_IN', NumberFormatter::DECIMAL);
	echo $fmt->format($amount);?></font></td>
        
       
        
    </tr>
    <?php
	endforeach;
	?>
    <tr>
<td colspan="3" align="right"><b>TOTAL</b>&nbsp;</td>  
<td align="right"><b><?php 
if($_GET['vendor'] == 'ALL')
{
	$query = mysql_query("SELECT SUM(order_advance) FROM rem_order");
}
else
{
	$query = mysql_query("SELECT SUM(order_advance) FROM rem_order WHERE order_vendor='$_GET[vendor]'");
}
while($row = mysql_fetch_array($query))
{
	$total_Amount1 = round($row[0],0);
}
if($_GET['vendor'] == 'ALL')
{
	$query1 = mysql_query("SELECT SUM(payment_amount) FROM rem_order_payment");
}
else
{
	$query1 = mysql_query("SELECT SUM(payment_amount) FROM rem_order_payment WHERE payment_vendor_id='$_GET[vendor]'");
}
while($row1 = mysql_fetch_array($query1))
{
	$total_Amount2 = round($row1[0],0);
}
	$total_Amount=$total_Amount1+$total_Amount2;
	$fmt = new NumberFormatter($locale = 'en_IN', NumberFormatter::DECIMAL);
	echo $fmt->format($total_Amount);
 
?></b></td>

</tr>
  </table>
</div>

</body>
</html>
<div class="modal fade" id="myModals" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-dialog" style="padding-top:70px;">
						<div class="modal-content">
							<div class="modal-header">
								
								<h2 class="modal-title">Filter</h2>
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div>
							 <form class="form-horizontal" role="form" method="post">
<div class="modal-body">
					 <div class="form-group">
                        <label for="inputLinkPp" class="hidden-xs col-sm-3 control-label">Choose Vendor:</label>
                        <div class="input-group col-sm-8 xs-margin">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
                      	<?php 
								$vendor = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor WHERE vendor_id!='$_GET[vendor]'");
								?>
                             	<select  class="form-control"  name="vendor" id="vendor" onkeydown='if(event.keyCode == 13){document.getElementById("type").focus();return false;}'  >
         						
                                
                                
                                <?php 
								if($_GET['vendor'] == 'ALL')
								{?>
                                <option value="ALL">ALL Vendor..</option>
                                <?php 
								} 
								else
								{
								$vendor6 = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor WHERE vendor_id='$_GET[vendor]'");
								while($area_vendor6 = mysql_fetch_array($vendor6))
								{
								?>
								<option value="<?php echo $area_vendo6r[0]; ?>"><?php echo $area_vendor6[1]; }?></option>
                                 <option value="ALL">ALL Vendor..</option>
                                  <?php } ?>
                               
         						<?php 
   								while($area_vendor = mysql_fetch_array($vendor))
								{
								?>
								<option value="<?php echo $area_vendor[0]; ?>"><?php echo $area_vendor[1]; }?></option>
      							</select>
                       </div>
                    </div>
                   
                  
                    
</div>
<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								<button type="submit" name="submit" id="submit" class="btn btn-primary">Search</button>
							</div>
                            </form>
						</div><!-- /.modal-content -->
					</div><!-- /.modal-dialog -->
				</div>  
   <script>
    function priceSorter(a, b) {
        a = +a.substring(1); // remove $
        b = +b.substring(1);
        if (a > b) return 1;
        if (a < b) return -1;
        return 0;
    }
</script>
<script>
  
$(document).on('click','.lbl_item',function(){
	var item_id = $(this).attr('itm_id');
	console.log(item_id);
	$.ajax({
			url:"getporeports.php",
			data:{'item_id':item_id},
			type:'POST',
			success:function(data)
			{
				$("#ur_id").html(data);
			}
	});	
	
	$(".btn_open_modal").click();
});
</script>
 <script>
(function(document) {
    'use strict';

    var LightTableFilter = (function(Arr) {

          var _input;

          function _onInputEvent(e) {
              _input = e.target;
              var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
				});
			});
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
		};
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			LightTableFilter.init();
		}
	});

})(document);
</script>

<script>
$.tablesorter.addParser({ 
    id: 'price', 
    is: function(s) { 
        return false; 
    }, 
    format: function(s) { 
        return s.replace(/Free/,0).replace(/ CHF/,""); 
    }, 
    type: 'numeric' 
}); 

$(function() { 
    $("table").tablesorter({ 
        headers: { 
            1: { 
                sorter:'price' 
            } 
        } 
    }); 
});
</script>