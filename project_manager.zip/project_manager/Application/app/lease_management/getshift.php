<?php
session_start();
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
$d =  $_POST['item_id'];
$details = explode('$',$d);
$qty = $details[0];
$outlet = $details[1];
$merchant = $details[2];
$types = $details[3];
$item_id = $details[4];
?>
<form method="post">
<?php 
if($types == 'PLUS'){
	?>
Somewhere From

<input type="hidden" name="types" id="types" value="PLUS" />
	<table class="table table-bordered" id="table"
               data-toggle="table"
               data-height="460"
               data-sort-name="price"
               data-sort-order="desc" width="100%">
  
      <tr>
       
         <td ><b>SLNO</b></th>
          <td><b>OUTLET</b></td>
         <td><b>MERCHANT</b></td>
        <td align="right"><b>AVAILABLE</b></td>
        
      
                  
      </tr>
   
    <tbody>
    <?php 
	$result = mysql_query("SELECT a.item_name name,b.stock stock,c.sales sales FROM rem_item a LEFT JOIN (SELECT stock_item,SUM(stock_qty) stock FROM rem_stock WHERE stock_to_type=2 GROUP BY stock_item) AS b ON b.stock_item=a.item_id LEFT JOIN (SELECT stock_item,SUM(stock_qty) sales FROM rem_stock WHERE stock_from_type=2 GROUP BY stock_item) AS c ON c.stock_item=a.item_id WHERE a.item_id='$item_id'");
	while($row = mysql_fetch_array($result))
  	{
		 $warehouse=$row['stock']-$row['sales'];
	}
	if($warehouse > 0){ } else {?>
    <tr>
        <td width="5%"><font size="2">1</font></td>
         <td width="15%"><font size="2">WAREHOUSE</font></td>
         <td width="25%"><font size="2">ACW</font></td>
         
       
       	<td align="right" width="10%"><font size="2"><?php echo $warehouse; ?></font></td>
     
      
      
      </tr>
      <?php } ?>	
 <?php
							$result_item = mysql_query("SELECT a.assign_counter counter_id,b.counter_name counter_name,c.merchant_name merchant_name,d.outlet_name outlet_name,a.assign_merchant merchant_id,a.assign_outlet outlet_id FROM rem_counter_assign a LEFT JOIN rem_counter_master b ON a.assign_counter=b.counter_id LEFT JOIN rem_merchant c ON a.assign_merchant=c.merchant_id LEFT JOIN rem_outlet d ON a.assign_outlet=d.outlet_id");
							$counter=1;
							while($row_item = mysql_fetch_array($result_item))
  							{
								
	$result = mysql_query("SELECT a.item_name name,b.stock stock,c.sales sales FROM rem_item a LEFT JOIN (SELECT stock_item,SUM(stock_qty) stock FROM rem_stock WHERE stock_to_type='3' AND stock_to_outlet='$row_item[outlet_id]' AND stock_to='$row_item[counter_id]' AND stock_item='$item_id') AS b ON b.stock_item=a.item_id LEFT JOIN (SELECT stock_item,SUM(stock_qty) sales FROM rem_stock WHERE stock_from_type='3' AND stock_from_outlet='$row_item[outlet_id]' AND stock_from='$row_item[counter_id]' AND stock_item='$item_id') AS c ON c.stock_item=a.item_id WHERE a.item_id='$item_id'");
	while($row = mysql_fetch_array($result))
  	{
		 $alot=$row['stock']-$row['sales'];
	}
	
	$result1 = mysql_query("SELECT SUM(assign_qty) qty FROM rem_merchant_item_assign WHERE assign_outlet='$row_item[outlet_id]' AND assign_merchant='$row_item[merchant_id]' AND assign_item='$item_id'");
	while($row1 = mysql_fetch_array($result1))
  	{
		  $assign=round($row1['qty'],0);
	}
		
	 $balance=$assign-$alot;
	 if($balance > -1)
	 {
	 }
	 else
	 {?>
								 
						
      <tr>
        <td width="5%"><font size="2"><?php echo ++$counter; ?></font></td>
         <td width="15%"><font size="2"><?php echo $row_item['outlet_name']; ?></font></td>
         <td width="25%"><font size="2"><?php echo $row_item['counter_name']."-".$row_item['merchant_name']; ?></font></td>
         
       
       	<td align="right" width="10%"><font size="2"><?php
	$result = mysql_query("SELECT a.item_name name,b.stock stock,c.sales sales FROM rem_item a LEFT JOIN (SELECT stock_item,SUM(stock_qty) stock FROM rem_stock WHERE stock_to_type='3' AND stock_to_outlet='$row_item[outlet_id]' AND stock_to='$row_item[counter_id]' AND stock_item='$item_id') AS b ON b.stock_item=a.item_id LEFT JOIN (SELECT stock_item,SUM(stock_qty) sales FROM rem_stock WHERE stock_from_type='3' AND stock_from_outlet='$row_item[outlet_id]' AND stock_from='$row_item[counter_id]' AND stock_item='$item_id') AS c ON c.stock_item=a.item_id WHERE a.item_id='$item_id'");
	while($row = mysql_fetch_array($result))
  	{
		 $alot=$row['stock']-$row['sales'];
	}
	
	$result1 = mysql_query("SELECT SUM(assign_qty) qty FROM rem_merchant_item_assign WHERE assign_outlet='$row_item[outlet_id]' AND assign_merchant='$row_item[merchant_id]' AND assign_item='$item_id'");
	while($row1 = mysql_fetch_array($result1))
  	{
		  $assign=round($row1['qty'],0);
	}
		
	echo $balance=$assign-$alot;
 		
	 ?></font></td>
     
     
      
      </tr>
      <?php }} ?>
      </tbody>
      </table>
      <?php } else { ?>
      To somewhere
    <input type="hidden" name="types" id="types" value="MINUS" />
     <table class="table table-bordered" id="table"
               data-toggle="table"
               data-height="460"
               data-sort-name="price"
               data-sort-order="desc" width="100%">
  
      <tr>
       
         <td ><b>SLNO</b></th>
          <td><b>OUTLET</b></td>
         <td><b>MERCHANT</b></td>
        <td align="right"><b>REQUIRE</b></td>
       
      
                  
      </tr>
   
    <tbody>
   
 <?php
							$result_item = mysql_query("SELECT a.assign_counter counter_id,b.counter_name counter_name,c.merchant_name merchant_name,d.outlet_name outlet_name,a.assign_merchant merchant_id,a.assign_outlet outlet_id FROM rem_counter_assign a LEFT JOIN rem_counter_master b ON a.assign_counter=b.counter_id LEFT JOIN rem_merchant c ON a.assign_merchant=c.merchant_id LEFT JOIN rem_outlet d ON a.assign_outlet=d.outlet_id ");
							$counter=0;
							while($row_item = mysql_fetch_array($result_item))
  							{
								
	$result = mysql_query("SELECT a.item_name name,b.stock stock,c.sales sales FROM rem_item a LEFT JOIN (SELECT stock_item,SUM(stock_qty) stock FROM rem_stock WHERE stock_to_type='3' AND stock_to_outlet='$row_item[outlet_id]' AND stock_to='$row_item[counter_id]' AND stock_item='$item_id') AS b ON b.stock_item=a.item_id LEFT JOIN (SELECT stock_item,SUM(stock_qty) sales FROM rem_stock WHERE stock_from_type='3' AND stock_from_outlet='$row_item[outlet_id]' AND stock_from='$row_item[counter_id]' AND stock_item='$item_id') AS c ON c.stock_item=a.item_id WHERE a.item_id='$item_id'");
							while($row = mysql_fetch_array($result))
  							{
		 						$alot=$row['stock']-$row['sales'];
							}
	
							$result1 = mysql_query("SELECT SUM(assign_qty) qty FROM rem_merchant_item_assign WHERE assign_outlet='$row_item[outlet_id]' AND assign_merchant='$row_item[merchant_id]' AND assign_item='$item_id'");
							while($row1 = mysql_fetch_array($result1))
  							{
		  						$assign=round($row1['qty'],0);
							}
		
	 						$balance=$assign-$alot;
							if($balance < 1)
	 						{
	 						}
	 else
	 {?>
								 
	<tr>
        <td width="5%"><font size="2"><?php
	$result = mysql_query("SELECT a.item_name name,b.stock stock,c.sales sales FROM rem_item a LEFT JOIN (SELECT stock_item,SUM(stock_qty) stock FROM rem_stock WHERE stock_to_type=2 GROUP BY stock_item) AS b ON b.stock_item=a.item_id LEFT JOIN (SELECT stock_item,SUM(stock_qty) sales FROM rem_stock WHERE stock_from_type=2 GROUP BY stock_item) AS c ON c.stock_item=a.item_id WHERE a.item_id='$item_id'");
	while($row = mysql_fetch_array($result))
  	{
		 $warehouse=$row['stock']-$row['sales'];
	}
	
	
		

 		
	 ?></font>1</td>
         <td width="15%"><font size="2">WAREHOUSE</font></td>
         <td width="25%"><font size="2">ACW</font></td>
         
       
       	<td align="right" width="10%"><font size="2"><?php echo $warehouse; ?></font></td>
     
     
      
      </tr>							
      <tr>
        <td width="5%"><font size="2"><?php echo ++$counter; ?></font></td>
        <td width="15%"><font size="2"><?php echo $row_item['outlet_name']; ?></font></td>
         <td width="25%"><font size="2"><?php echo $row_item['counter_name']."-".$row_item['merchant_name']; ?></font></td>
       
       	<td align="right" width="10%"><font size="2"><?php
	$result = mysql_query("SELECT a.item_name name,b.stock stock,c.sales sales FROM rem_item a LEFT JOIN (SELECT stock_item,SUM(stock_qty) stock FROM rem_stock WHERE stock_to_type='3' AND stock_to_outlet='$row_item[outlet_id]' AND stock_to='$row_item[counter_id]' AND stock_item='$item_id') AS b ON b.stock_item=a.item_id LEFT JOIN (SELECT stock_item,SUM(stock_qty) sales FROM rem_stock WHERE stock_from_type='3' AND stock_from_outlet='$row_item[outlet_id]' AND stock_from='$row_item[counter_id]' AND stock_item='$item_id') AS c ON c.stock_item=a.item_id WHERE a.item_id='$item_id'");
	while($row = mysql_fetch_array($result))
  	{
		 $alot=$row['stock']-$row['sales'];
	}
	
	$result1 = mysql_query("SELECT SUM(assign_qty) qty FROM rem_merchant_item_assign WHERE assign_outlet='$outlet' AND assign_merchant='$row_item[merchant_id]' AND assign_item='$item_id'");
	while($row1 = mysql_fetch_array($result1))
  	{
		  $assign=round($row1['qty'],0);
	}
		
	echo $balance=$assign-$alot;
 		
	 ?></font></td>
     
      
      
      </tr>
      <?php }} ?>
      </tbody>
      </table>
      <?php } ?>
      
	</form>