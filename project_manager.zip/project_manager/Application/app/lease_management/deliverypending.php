<?php
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php"); 
include("header.php"); 

if(isset($_POST["submit"]))
{
		if($_POST["vendor"] == 'ALL')
		{
			header("Location: deliverypending.php");
		}
		else
		{
			header("Location: deliverypending.php?vendor_id=$_POST[vendor]");
		}
}		
?>


<div class="shadow-lg p-3 mb-1 bg-white rounded" style="position:fixed; width:100%; z-index:9999;">
   <a href="dashboard.php" class="btn btn-success btn-sm">Back</a>
 
</div>
 
 <br/>
<br/>
<br/>



  <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #ddd;
}

th, td {
    padding: 5px;
	font-size:10px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<h2>&nbsp;Delivery Pending &nbsp;&nbsp;   <a data-toggle="modal" href="#myModals" style="background-color:#666;" class="btn btn-success btn-sm"><i class="fa fa-filter"></i> More Filter</a> </h2>

<div >
  <p align="right"><font color="#000000">Smart Search  : &nbsp;</font><input type="search" class="light-table-filter" data-table="table-bordered" placeholder="Filter">&nbsp;&nbsp;</p>    
  </div>
   <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg" style="width:95%; padding-top:100px;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Delivery Pending Items</h4>
           <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body ">
                <label id='ur_id'><label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>   
  <button style="display:none" type="button" class="btn btn-info btn-lg btn_open_modal" data-toggle="modal" data-target="#myModal">Open Modal</button>   
<div style="overflow-x:auto;">
  
  <table class="table-bordered">
  <thead>
    <tr>
      <th width="5%">SLNO</th>
      <th width="16%">ORDR DATE<br/>DLVR DATE</th>

      <th width="5%">PONO</th>
      <th width="25%">ITEM NAME</th>
       <th width="25%">VENDOR NAME</th>
        <th width="8%">QTY</th>
    </tr>
    </thead>
     <?php 
$counter=0;
if(isset($_GET['vendor_id'] ))
	{
	$query_item=mysql_query("SELECT a.details_header_id po,DATE(a.details_date) orderdate,e.delivery deliverydate,b.item_name itemname,c.vendor_name vendorname,a.details_qty order_qty,d.deliveryqty,a.details_item itemid,a.details_vendor_id vendorid FROM rem_order_details a LEFT JOIN rem_item b ON a.details_item=b.item_id LEFT JOIN rem_vendor c ON a.details_vendor_id=c.vendor_id LEFT JOIN(SELECT details_item,SUM(details_qty) deliveryqty FROM rem_delivery_details WHERE details_vendor='$_GET[vendor_id]' GROUP BY details_po,details_item) AS d ON d.details_item=a.details_item LEFT JOIN (SELECT order_header_id,order_delivery_date delivery FROM rem_order WHERE order_type=1) AS e ON e.order_header_id=a.details_header_id  WHERE a.details_order_type=1 AND a.details_vendor_id='$_GET[vendor_id]' GROUP BY a.details_header_id,a.details_item ORDER BY a.details_header_id");
	}
	else
	{
		$query_item=mysql_query("SELECT a.details_header_id po,DATE(a.details_date) orderdate,e.delivery deliverydate,b.item_name itemname,c.vendor_name vendorname,a.details_qty order_qty,d.deliveryqty,a.details_item itemid,a.details_vendor_id vendorid FROM rem_order_details a LEFT JOIN rem_item b ON a.details_item=b.item_id LEFT JOIN rem_vendor c ON a.details_vendor_id=c.vendor_id LEFT JOIN(SELECT details_item,SUM(details_qty) deliveryqty FROM rem_delivery_details GROUP BY details_po,details_item) AS d ON d.details_item=a.details_item  LEFT JOIN (SELECT order_header_id,order_delivery_date delivery FROM rem_order WHERE order_type=1) AS e ON e.order_header_id=a.details_header_id  WHERE a.details_order_type=1 GROUP BY a.details_header_id,a.details_item ORDER BY a.details_header_id");
	}
	while($row_item =  mysql_fetch_array($query_item))
	{
		if(isset($_GET['vendor_id']))
		{ 
		$query_items=mysql_query("SELECT SUM(details_qty) FROM rem_delivery_details WHERE details_po='$row_item[0]' AND details_item='$row_item[7]' AND details_vendor='$_GET[vendor_id]'");
		}
		else
		{
		$query_items=mysql_query("SELECT SUM(details_qty) FROM rem_delivery_details WHERE details_po='$row_item[0]' AND details_item='$row_item[7]'");
		}
		while($row_items =  mysql_fetch_array($query_items))
		{
			$delivered_qty1=$row_items[0];
		}
		
		$ordered_qty=$row_item[5];
		$delivered_qty=$row_item[6];
		$required_qty=$ordered_qty-$delivered_qty1;
		
			
	if($required_qty>0)
	{
		date_default_timezone_set('Asia/Calcutta');
		$current_date=date("Y-m-d");
		if($current_date<=$row_item[2])
		{
	?>
      <tr>
  <?php }
  		else
		{?>
        <tr style="background-color:#FC9;">
        <?php 
		} 
		?> 
	
        <td><?php echo ++$counter; ?></td>
        <td><?php echo date("d-m-Y",strtotime($row_item[1])); ?><br/><?php  echo date("d-m-Y",strtotime($row_item[2])); ?></td>
     
       
        <td><?php echo $row_item[0]; ?></td>
         <td><?php echo $row_item[3]; ?></td>
        <td><?php echo $row_item[4]; ?></td>
        <td><?php 
$ordered_qty1= $row_item[5];


echo $required_qty1=$ordered_qty1-$delivered_qty1;
?></td> 
       
 </tr>
		<?php }} ?>

  </table>
</div>

</body>
</html>
<div class="modal fade" id="myModals" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-dialog" style="padding-top:70px;">
						<div class="modal-content">
							<div class="modal-header">
								
								<h2 class="modal-title">Filter</h2>
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div>
							 <form class="form-horizontal" role="form" method="post">
<div class="modal-body">
					 <div class="form-group">
                        <label for="inputLinkPp" class="hidden-xs col-sm-3 control-label">Choose Vendor:</label>
                        <div class="input-group col-sm-8 xs-margin">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
                      	<?php 
								$vendor = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor WHERE vendor_id!='$_GET[vendor]'");
								?>
                               	<select  class="form-control"  name="vendor" id="vendor" onkeydown='if(event.keyCode == 13){document.getElementById("type").focus();return false;}'  >
         						
                                
                                
                                <?php 
								if($_GET['vendor'] == 'ALL')
								{?>
                                <option value="ALL">ALL Vendor..</option>
                                <?php 
								} 
								else
								{
								$vendor6 = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor WHERE vendor_id='$_GET[vendor]'");
								while($area_vendor6 = mysql_fetch_array($vendor6))
								{
								?>
								<option value="<?php echo $area_vendo6r[0]; ?>"><?php echo $area_vendor6[1]; }?></option>
                                 <option value="ALL">ALL Vendor..</option>
                                  <?php } ?>
                               
         						<?php 
   								while($area_vendor = mysql_fetch_array($vendor))
								{
								?>
								<option value="<?php echo $area_vendor[0]; ?>"><?php echo $area_vendor[1]; }?></option>
      							</select>
                       </div>
                    </div>
                    
</div>
<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								<button type="submit" name="submit" id="submit" class="btn btn-primary">Search</button>
							</div>
                            </form>
						</div><!-- /.modal-content -->
					</div><!-- /.modal-dialog -->
				</div>  
   <script>
    function priceSorter(a, b) {
        a = +a.substring(1); // remove $
        b = +b.substring(1);
        if (a > b) return 1;
        if (a < b) return -1;
        return 0;
    }
</script>
<script>
  
$(document).on('click','.lbl_item',function(){
	var item_id = $(this).attr('itm_id');
	console.log(item_id);
	$.ajax({
			url:"getporeports.php",
			data:{'item_id':item_id},
			type:'POST',
			success:function(data)
			{
				$("#ur_id").html(data);
			}
	});	
	
	$(".btn_open_modal").click();
});
</script>
 <script>
(function(document) {
    'use strict';

    var LightTableFilter = (function(Arr) {

          var _input;

          function _onInputEvent(e) {
              _input = e.target;
              var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
				});
			});
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
		};
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			LightTableFilter.init();
		}
	});

})(document);
</script>

<script>
$.tablesorter.addParser({ 
    id: 'price', 
    is: function(s) { 
        return false; 
    }, 
    format: function(s) { 
        return s.replace(/Free/,0).replace(/ CHF/,""); 
    }, 
    type: 'numeric' 
}); 

$(function() { 
    $("table").tablesorter({ 
        headers: { 
            1: { 
                sorter:'price' 
            } 
        } 
    }); 
});
</script>