<?php
ob_start();
session_start();
include("dbconnection.php");
error_reporting(E_ERROR | E_PARSE);// set time-out period (in seconds)

									$merchant = mysql_query("SELECT a.assign_counter,b.counter_name,c.merchant_name FROM rem_counter_assign a LEFT JOIN rem_counter_master b ON a.assign_counter=b.counter_id LEFT JOIN rem_merchant c ON a.assign_merchant=c.merchant_id  WHERE a.assign_outlet='$_GET[q]'");
							
								?>
                                
                      	<select  class="form-control"  name="merchant" id="merchant" onkeydown='if(event.keyCode == 13){document.getElementById("search").focus();return false;}'  >
         					
							<?php 
while($row_merchant = mysql_fetch_array($merchant))
{
if($row_merchant[2] == '' || $row_merchant[2] == '0') 
{ ?>
	<option value="<?php echo $row_merchant[0]; ?>"><?php 
echo $row_merchant[1]."-NOT ASSIGN"; 
 ?></option>
<?php 
} 
else 
{ ?>
	<option value="<?php echo $row_merchant[0]; ?>"><?php 
echo $row_merchant[1]."-".$row_merchant[2]; 
} ?></option>
<?php } ?>
      					</select> 
