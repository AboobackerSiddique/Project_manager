<?php
session_start();
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
$d =  $_POST['item_id'];
$details = explode('$',$d);
$header_id=$details[0];
$agreement = mysql_query("SELECT b.name,c.name,d.name,a.area,a.lessor_rep_name,a.lessee_rep_name,a.property_address,a.scheduled_premises,a.nature_of_trade,a.brand_name,a.rent_amount,a.security_deposit,e.name,a.lease_start_date,a.lease_end_date,f.name,a.escalation_percentage,g.name,a.escalation_start_date,a.car_parking_space,a.lessor_scope_of_work,a.lessee_scope_of_work,h.name,a.rent_commences,a.power,a.generator_backup,a.water_sump,a.overhead_tank,a.building_taxes_by,i.name,j.name,j.label_1,j.label_2,k.name,a.lessor_rep_age,a.lessor_rep_mobile,a.lessor_rep_address,l.name,a.lessee_rep_age,a.lessee_rep_mobile,a.lessee_rep_address FROM rem_agreement a LEFT JOIN countries b ON a.country=b.id LEFT JOIN states c ON a.state=c.id LEFT JOIN cities d ON a.cities=d.id LEFT JOIN month e ON a.lease_term=e.month LEFT JOIN month f ON a.lock_in_period=f.month  LEFT JOIN month g ON a.escalation_every_month=g.month LEFT JOIN month h ON a.grace_period=h.month LEFT JOIN locations i ON a.location=i.id LEFT JOIN rem_categories j ON a.category=j.id LEFT JOIN titles k ON a.lessor_rep_title=k.id LEFT JOIN titles l ON a.lessee_rep_title=l.id WHERE header_id='$header_id'");
	while($row = mysql_fetch_array($agreement))
	{
		$country=$row[0];
		$state=$row[1];
		$cities=$row[2];
		$area=$row[3];
		$lessors=$row[4];
		$lessee=$row[5];
		$address=$row[6];
		$scheduled_premises=$row[7];
		$nature_of_trade=$row[8];
		$brand_name=$row[9];
		$rent_amount=$row[10];
		$security_deposit=$row[11];
		$lease_term=$row[12];
		$lease_start_date=$row[13];
		$lease_end_date=$row[14];
		$lock_in_period=$row[15];
		$escalation_percentage=$row[16];
		$escalation_every_month=$row[17];
		$escalation_start_date=$row[18];
		$car_parking_space=$row[19];
		$lessor_scope_of_work=$row[20];
		$lessee_scope_of_work=$row[21];
		$grace_period=$row[22];
		$rent_commences=$row[23];
		$power=$row[24];
		$generator_backup=$row[25];
		$water_sump=$row[26];
		$overhead_tank=$row[27];
		$building_taxes_by=$row[28];
		$locations=$row[29];
		$agreement_category=$row[30];
		$agreement_label1=$row[31];
		$agreement_label2=$row[32];
		$lessor_title=$row[33];
		$lessor_age=$row[34];
		$lessor_mobile=$row[35];
		$lessor_address=$row[36];
		$lessee_title=$row[37];
		$lessee_age=$row[38];
		$lessee_mobile=$row[39];
		$lessee_address=$row[40];
	}


?><fon size='1'><h6>
	<table class="table-bordered">
<tr >
<td width="100%" align="center" bgcolor="#666666" ><font size="3" color="#FFFFFF"><b><?php echo $agreement_category; ?></b></font></td>
</tr>
<tr>

<td width="100%" align="left"><b>Country :</b> <?php echo $country; ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>State :</b> <?php echo $state; ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>City :</b> <?php echo $cities; ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>Location :</b> <?php echo $locations; ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>Area :</b> <?php echo $area; ?></td>
</tr>
<tr>
<td width="100%" align="left"> <b>Property Address :</b><br/>
<?php echo $address; ?></td>
</tr>
<tr>
<td width="100%" align="left">
<b><?php echo $agreement_label1; ?> :</b><br/>


<table class="table-bordered">
<tr >
<td  bgcolor="#CCCCCC" width="20%"><b><?php echo $agreement_label2; ?></b></td>
<td  bgcolor="#CCCCCC" width="35%"><b>NAME </b></td>
<td bgcolor="#CCCCCC" width="5%"><b>AGE</b></td>
<td bgcolor="#CCCCCC" width="13%" ><b>MOBILE NO</b></td>
<td bgcolor="#CCCCCC" width="27%" ><b>ADDRESS</b></td>
</tr>
<tr >
<td  width="20%"><b>Represented Person</b></td>
<td  width="35%"><?php if($lessee_title == '0') { echo "<b>Company:</b> ".$lessors; } else { echo $lessor_title.".&nbsp;".$lessors; }?> </td>
<td width="5%"><?php echo $lessor_age; ?></td>
<td width="13%" ><?php echo $lessor_mobile; ?></td>
<td  width="27%" ><?php echo $lessor_address; ?></td>
</tr>
<?php
$escalation = mysql_query("SELECT b.name,a.lessor_name,a.age,a.mobile,a.address FROM rem_lessor_details a LEFT JOIN titles b ON a.lessor_title=b.id  WHERE a.header_id='$header_id'");
$counter=0;
while($row_lessor = mysql_fetch_array($escalation))
{?>
<tr>
<td><?php echo $agreement_label1.++$couter; ?></td>
<td><?php echo $row_lessor[0].".&nbsp;".$row_lessor[1]; ?></td>
<td><?php echo $row_lessor[2]; ?></td>
<td><?php echo $row_lessor[3]; ?></td>
<td><?php echo $row_lessor[4]; ?></td>
</tr>
<?php } ?>
</table>



</td>
</tr>
<tr>
<td width="100%" align="left">
<b><?php echo $agreement_label2; ?>:</b><br/>
<table class="table-bordered">
<tr >
<td  bgcolor="#CCCCCC" width="20%"><b><?php echo $agreement_label2; ?></b></td>
<td  bgcolor="#CCCCCC" width="35%"><b>NAME </b></td>
<td bgcolor="#CCCCCC" width="5%"><b>AGE</b></td>
<td bgcolor="#CCCCCC" width="13%" ><b>MOBILE NO</b></td>
<td bgcolor="#CCCCCC" width="27%" ><b>ADDRESS</b></td>
</tr>
<tr >
<td  width="20%"><b>Represented Person</b></td>
<td  width="35%"><?php if($lessee_title == '0') { echo "<b>Company:</b> ".$lessee; } else { echo $lessee_title.".&nbsp;".$lessee; }?> </td>
<td width="5%"><?php echo $lessee_age; ?></td>
<td width="13%" ><?php echo $lessee_mobile; ?></td>
<td  width="27%" ><?php echo $lessee_address; ?></td>
</tr>
<?php
$escalation = mysql_query("SELECT b.name,a.lessee_name,a.age,a.mobile,a.address FROM rem_lessee_details a LEFT JOIN titles b ON a.lessee_title=b.id  WHERE a.header_id='$header_id'");
$counter1=0;
while($row_lessee = mysql_fetch_array($escalation))
{?>
<tr>
<td><?php echo $agreement_label2.++$couter1; ?></td>
<td><?php echo $row_lessee[0].".&nbsp;".$row_lessee[1]; ?></td>
<td><?php echo $row_lessee[2]; ?></td>
<td><?php echo $row_lessee[3]; ?></td>
<td><?php echo $row_lessee[4]; ?></td>
</tr>
<?php } ?>
</table></td>
</tr>

<tr>

<td width="100%" align="left"><b>Scheduled Premises :</b><br/>
 <?php echo $scheduled_premises; ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>Nature of Trade :</b><br/>
<?php echo $nature_of_trade; ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>Brand Name :</b> <?php echo $brand_name; ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>Rent :</b> <?php echo $rent_amount; ?></td>
</tr>
<tr>

<td width="100%" align="left"><b>Refundable Security Deposit (Interest Free) :</b> 
 <?php echo $security_deposit; ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>Lease Term :</b>
 <?php echo $lease_term; ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>Lock In Period :</b>
 <?php echo $lock_in_period; ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>Lease Start date :</b>
<?php echo $lease_start_date; ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>Lease End date :</b> <?php echo $lease_end_date; ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>Rent Escalation Percentage :</b> <?php echo $escalation_percentage; ?>%</td>
</tr>
<tr>
<td width="100%" align="left"><b>Rent Escalation Every :</b> <?php echo $escalation_every_month; ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>Rent Escalation Start Date :</b> <?php echo $escalation_start_date; ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>Rent Escalation Next Payment :</b><br/>

<table class="table-bordered">
<tr >
<td  bgcolor="#CCCCCC" width="30%"><b>ESCLATION DATE</b></td>
<td  bgcolor="#CCCCCC" width="30%"><b>PERCENTAGE</b></td>
<td bgcolor="#CCCCCC" width="40%" align="right"><b>ESCLATION AMOUNT</b></td>
</tr>
<?php
$escalation = mysql_query("SELECT esc_date,esc_percentage,esc_amount FROM rem_escalation  WHERE esc_header_id='$header_id'");
while($row_escalation = mysql_fetch_array($escalation))
{?>
<tr>
<td width="30%"><?php echo date("d-m-Y", strtotime($row_escalation[0])); ?></td>
<td width="30%"><?php echo $row_escalation[1]; ?>%</td>
<td width="40%" align="right"><?php echo $row_escalation[2]; ?></td>
</tr>
<?php } ?>
</table></td>
</tr>

<tr>
<td width="100%" align="left"><b>Grace Period :</b>
 <?php echo $grace_period; ?></td>
</tr><tr>
<td width="100%" align="left"><b>Rent commences :</b><br/>
 <?php echo $rent_commences; ?></td>
</tr><tr>
<td width="100%" align="left"><b>Power :</b><br/>
 <?php echo $power; ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>Genrator back up:</b><br/>
 <?php echo $generator_backup; ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>Water Sump :</b><br/> <?php echo $water_sump; ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>Overhead tank:</b><br/>
 <?php echo $overhead_tank; ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>Building taxes by:</b>
 <?php echo $building_taxes_by; ?></td>
</tr>

<tr>
<td width="100%" align="left"><b>Ownership Proof:</b><br/>

<?php  
$proofs = mysql_query("SELECT b.name FROM rem_owners_proof a LEFT JOIN rem_proofs b ON a.proof=b.id  WHERE a.proof_header_id='$header_id'");
	while($row_proof = mysql_fetch_array($proofs))
	{
		echo $row_proof[0].", ";
	} ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>Car Parking Space :</b><br/>
 <?php echo $car_parking_space; ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>Lessor scope of Work :</b><br/>
 <?php echo $lessor_scope_of_work; ?></td>
</tr>
<tr>
<td width="100%" align="left"><b>Lessee Scope of Work :</b><br/> <?php echo $lessee_scope_of_work; ?></td>
</tr>
<tr >
<td  bgcolor="#CCCCCC" width="100%"><b>Download Document</b></td>

</tr>
<?php
$escalation = mysql_query("SELECT upload_file FROM rem_proof_uploaded  WHERE upload_header_id='$header_id'");
while($row_escalation = mysql_fetch_array($escalation))
{?>
<tr>
<td width="100%"><?php echo $row_escalation[0]; ?> <a href="download.php?filename=<?php echo $row_escalation[0];?>"><img src="img/download.png" / width="20"></a></td>

</tr>
<?php } ?>
</table>
</font>
</h6>
