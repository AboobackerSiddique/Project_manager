<?php
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);

include("header1.php"); 

?>
 <style> 
 body, html {
    height: 100%;
    margin: 0;
}

.bg {
    /* The image used */
   /*background-image: url("img/bg.jpg"); */
    background-color: #AA1414;

    /* Full height */
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
	
}
.start {
 position: absolute;
     margin: auto;
     top: 0;
     right: 0;
     bottom: 0;
     left: 0;
     width: 100%;
     height: 100%;

} 

.btn {
  background-color:#FFF;
  width:100%;
  border: none;
  color: black;
  padding: 16px 32px;
  text-align: center;
  font-size: 14px;
  margin:2px;
  transition: 0.3s;
}

.btn:hover {
  background-color: #B92626;
  color: white;
}

</style>
	<div class="bg">
	<div class="start">
	<center>
	  <br/>
	<div class="form-group col-md-6">
    <br/><img src="images/logo.png" alt="" height="140"/><br/><br/>
      <?php if($_SESSION["user_name"] == 'JPN' || $_SESSION["user_name"] == 'BTM' || $_SESSION["user_name"] == 'HSR' || $_SESSION["user_name"] == 'WFD' || $_SESSION["user_name"] == 'ECT' || $_SESSION["user_name"] == 'MDP'){?>
                <a href="chitti/dashboard.php" class="btn">CHITTY ENTRY</a> 
                <a href="logout.php" class="btn">LOGOUT</a> 
                <?php } else if($_SESSION["user_name"] == 'z' || $_SESSION["user_name"] == 'Z' || $_SESSION["user_name"] == 'rekha' || $_SESSION["user_name"] == 'admin')
                { ?>
    			       <!--<a href="sales/index.php" class="btn">SALES REPORT</a> -->
            	<a href="project_manager/index.php" class="btn">PROJECT MANAGER</a>
                <a href="lease_management/dashboard.php" class="btn">LEASE MANAGEMENT</a> 
                 <a href="cfms/dashboard.php" class="btn">CFMS REPORTS</a> 
                 <a href="chitti/dashboard.php" class="btn">CHITTI ENTRY</a>
                 <a href="logout.php" class="btn">LOGOUT</a>  
             
            	<?php } else {?>
                 <!--<a href="sales/index.php" class="btn">SALES REPORT</a> -->
              <a href="project_manager/index.php" class="btn">PROJECT MANAGER</a>
                <a href="lease_management/dashboard.php" class="btn">LEASE MANAGEMENT</a> 
                <a href="cfms/dashboard.php" class="btn">CFMS REPORTS</a> 
                <a href="logout.php" class="btn">LOGOUT</a> 
              <?php } ?>
    </div>	
	</center>
	</div>
	</div>