<?php

session_start();
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
include("header.php");


if(isset($_POST["btnlogin"]))
{
	
	$resultlogin = mysql_query("SELECT username,password FROM user_permissions where username = '$_POST[loginid]' AND password='$_POST[password]'");
while($row = mysql_fetch_array($resultlogin))
{
	
	$user_name = $row["username"];
	$password = $row["password"];
		
}


	if(mysql_num_rows($resultlogin) == 1)
	{
			$_SESSION["user_name"] =$user_name;
			$_SESSION["pass_word"] =$password;
			$_SESSION["page"] ="1";
					
	}
	else
	{
	$in= "Invalid Username or Invalid Password. ";
	return $in;
	}

}


if(isset($_SESSION["user_name"]))
{
	header("Location: test.php?page=$_SESSION[page]&user=$_SESSION[user_name]");
}
else
{
?>

<div class="shadow-lg p-3 mb-1 bg-white rounded" align="center"><br/><B><h1>POWER BI</h1>Kitchens@</B></div>

<div class="shadow-lg p-3 mb-1 bg-white rounded">

 <div class="container">
  <!-- Content here -->
  <center>
<img src="img/login.gif" width="120">
</center>
<?php if(isset($in)){ ?>
  <div class="alert alert-danger alert-dismissible" style="width:100%;"> 
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <font size="2"><?php echo "Username Or Password Wrong..!"; ?></font>
</div>
<?php } ?>
   <form method="post">
  <div class="form-group">
    <label for="exampleInputEmail1">Enter User Name</label>
    <input type="text" class="form-control" autofocus  placeholder="Enter User Name" name="loginid" id="loginid" value="<?php echo $_GET['username']; ?>" required>
  
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Enter Password</label>
    <input type="password" class="form-control" placeholder="Enter Password"  name="password" id="password" required>
  </div>
  
  <button type="submit" class="btn btn-success btn-lg btn-block" name="btnlogin" id="btnlogin">Login</button>
   <div >
<br/>
  </div>
</form>
</div> 
</div>
</div>
<div class="shadow-lg p-3 mb-1 bg-white rounded" align="center">Powered By : <a href="register.php" style="text-decoration:none; color:#666;" >Loyal Hospitality.</a></div>
<?php } ?>