<?php
session_start();
include("../dbconnection.php");
// Login to admin account
function loginfuntion($loginid,$password)
{

$resultlogin = mysql_query("SELECT username,password FROM user_permissions where username = '$loginid' AND password='$password'");
while($row = mysql_fetch_array($resultlogin))
{
	
	$user_name = $row["username"];
	$password = $row["password"];
		
}


	if(mysql_num_rows($resultlogin) == 1)
	{
		
 			$_SESSION["user_name"] =$loginid;
			$_SESSION["pass_word"] =$password;
					
	}
	else
	{
	$in= "Invalid Username or Invalid Password. ";
	return $in;
	}

}

?>