<?php
session_start();
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
include("header.php");
?>
<div id="reportContainer" style="height:1000px !important;"></div>
<script src="powerbi.js"></script>
<script type="text/javascript" src="http://code.jquery.com/jquery-1.7.1.min.js"></script>

<script>

    <?php

$username=$_GET['user'];
$pageno=$_GET['page'];
        $curl = curl_init();

        curl_setopt_array($curl, array(
          CURLOPT_PORT => "8090",
          CURLOPT_URL => "http://lhpowerbivm.centralindia.cloudapp.azure.com:8090/embbedtoken",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "POST",
          CURLOPT_POSTFIELDS => "{\n\t\"username\":\"$username\",\n\t\"refresh\":false\n}",
          CURLOPT_HTTPHEADER => array(
            "content-type: application/json"
          ),
        ));

        $response = curl_exec($curl);
        $err = curl_error($curl);

        curl_close($curl);

        if ($err) {
          echo "cURL Error #:" . $err;
        }else{
          ?>

        var accessToken = "<?php echo $response; ?>"

            // Read report Id from Model
            var embedReportId = "4c22f555-33df-4960-aa18-139b3575d98a";
            
            // Read embed URL from Model
            var embedUrl = "https://app.powerbi.com/reportEmbed?reportId="+embedReportId+"&groupId=2327c03c-9262-4bfe-95db-3584f7189a48";


            var models = window['powerbi-client'].models;

            // Get models. models contains enums that can be used.
            // var models = window['powerbi-client'].models;

            // Embed configuration used to describe the what and how to embed.
            // This object is used when calling powerbi.embed.
            // This also includes settings and options such as filters.
            // You can find more information at https://github.com/Microsoft/PowerBI-JavaScript/wiki/Embed-Configuration-Details.
            var config = {
                type: 'report',
                tokenType: models.TokenType.Embed,
                accessToken: accessToken,
                embedUrl: embedUrl,
                id: embedReportId,
                permissions: models.Permissions.All,
                settings: {
                    filterPaneEnabled: false,
                    navContentPaneEnabled: true,
                    layoutType: models.LayoutType.MobilePortrait
                }
            };


            // Get a reference to the embedded report HTML element
            var reportContainer = document.querySelector("#reportContainer");//$('#reportContainer')[0];

            // Embed the report and display it within the div container.
            
var r = powerbi.embed(reportContainer, config);


r.on('loaded', function(){
  r.getPages().then(function(p){
    p[<?php echo $pageno; ?>].setActive();
  });
});

          <?php
        }
?>
    
</script>