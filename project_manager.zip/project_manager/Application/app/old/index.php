<?php
session_start();
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
include("header.php");


if(isset($_POST["btnlogin"]))
{
	
	$resultlogin = mysql_query("SELECT user_id,user_name,user_password,user_type,user_freeze,user_outlet FROM rem_user WHERE user_name ='$_POST[loginid]' AND user_password='$_POST[password]'");
	while($row = mysql_fetch_array($resultlogin))
	{
		$user_id = $row["user_id"];
		$user_name = $row["user_name"];
		$password = $row["user_password"];
		$user_type = $row["user_type"];
		$user_freeze = $row["user_freeze"];
		$user_outlet = $row["user_outlet"];
	
	}


	if(mysql_num_rows($resultlogin) == 1)
	{
		if($user_freeze == 1)
		{
			$in= "User Freezed Contact Administrator..! ";
			return $in;
		}
		else
		{
			$_SESSION["user_id"] =$user_id;
 			$_SESSION["user_name"] =$loginid;
			$_SESSION["pass_word"] =$password;
			$_SESSION["user_type"] = $user_type;
			$_SESSION["user_outlet"] = $user_outlet;
		}
	}
	else
	{
	$in= "Invalid Username or Invalid Password. ";
	
	}

}



if(isset($_SESSION["user_name"]) || isset($_SESSION["pass_word"]) || isset($_SESSION["user_type"]) || isset($_SESSION["user_id"]))
{
	
		header("Location: dashboard.php");
	
}
else
{
?>

<div class="shadow-lg p-3 mb-1 bg-white rounded" align="center"><br/><B><h1>PROJECT MANAGER</h1>LOGIN PAGE</B></div>

<div class="shadow-lg p-3 mb-1 bg-white rounded">

 <div class="container">
  <!-- Content here -->
  <center>
<img src="img/login.gif" width="120">
</center>
<?php if(isset($in)){ ?>
  <div class="alert alert-danger alert-dismissible" style="width:100%;"> 
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <font size="2"><?php echo "Username Or Password Wrong..!"; ?></font>
</div>
<?php } ?>
   <form method="post">
  <div class="form-group">
    <label for="exampleInputEmail1">Enter User Name</label>
    <input type="text" class="form-control" autofocus  placeholder="Enter User Name" name="loginid" id="loginid" value="<?php echo $_GET['username']; ?>" required>
  
  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Enter Password</label>
    <input type="password" class="form-control" placeholder="Enter Password"  name="password" id="password" required>
  </div>
  
  <button type="submit" class="btn btn-success btn-lg btn-block" name="btnlogin" id="btnlogin">Login</button>
   <div >
<br/>
  </div>
</form>
</div> 
</div>
</div>
<div class="shadow-lg p-3 mb-1 bg-white rounded" align="center">Powered By : <a href="register.php" style="text-decoration:none; color:#666;" >Loyal Hospitality.</a></div>
<?php } ?>