<?php
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);

include("header.php"); 

?>
 <style> 
 body, html {
    height: 100%;
    margin: 0;
}

.bg {
    /* The image used */
    background-image: url("img/bg.jpg");

    /* Full height */
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
	
}
.start {
 position: absolute;
     margin: auto;
     top: 0;
     right: 0;
     bottom: 0;
     left: 0;
     width: 100%;
     height: 100%;

} 

.btn {
  background-color:#FFF;
  width:100%;
  border: none;
  color: black;
  padding: 16px 32px;
  text-align: center;
  font-size: 14px;
  margin:2px;
  transition: 0.3s;
}

.btn:hover {
  background-color: #B92626;
  color: white;
}

</style>
	<div class="bg">
	<div class="start">
	<center>
	  <br/><br/> <br/><br/><br/><br/> <br/><br/> <br/><br/> <br/><br/> <br/><br/> <br/><br/> <br/><br/> <br/><br/> <br/><br/><br/><br/> <br/><br/><br/>
	<div class="form-group col-md-6">
    <br/><br/>
    			<a href="sales/index.php" class="btn">SALES REPORT</a>
            	<a href="project_manager/index.php" class="btn">PROJECT MANAGER</a>
                <a href="lease_management/dashboard.php" class="btn">LEASE MANAGEMENT</a> 
            	
    </div>	
	</center>
	</div>
	</div>