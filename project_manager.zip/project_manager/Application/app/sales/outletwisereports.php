<?php
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php"); 
include("header.php"); 
$pg_con=pg_connect("host='168.63.249.143' port='5432' dbname='shadow_kitchen_sales' user='postgres' password='P@$$word1234'");

date_default_timezone_set('Asia/Calcutta');
$current_date=date("Y-m-d");

if(isset($_POST["submit"]))
{
	header("Location: outletwisereports.php?from=$_POST[from]&to=$_POST[to]");
}

		$query_item = pg_query($pg_con, "SELECT 
data_bundle->>'outlet_id' AS outlet_id,
	sum((data_bundle -> 'brand_order_details' ->0->>'gross_total')::integer) AS a1,
	sum((data_bundle -> 'brand_order_details' ->1->>'gross_total')::integer) AS a2,
	sum((data_bundle -> 'brand_order_details' ->2->>'gross_total')::integer) AS a3,
	sum((data_bundle -> 'brand_order_details' ->3->>'gross_total')::integer) AS a4,
	sum((data_bundle -> 'brand_order_details' ->4->>'gross_total')::integer) AS a5,
	sum((data_bundle -> 'brand_order_details' ->5->>'gross_total')::integer) AS a6,
	sum((data_bundle -> 'brand_order_details' ->6->>'gross_total')::integer) AS a7,
	sum((data_bundle -> 'brand_order_details' ->7->>'gross_total')::integer) AS a8,
	sum((data_bundle -> 'brand_order_details' ->8->>'gross_total')::integer) AS a9,
	sum((data_bundle -> 'brand_order_details' ->9->>'gross_total')::integer) AS a10
FROM 
	public.bills_data_bundles WHERE order_date BETWEEN '$_GET[from]' AND '$_GET[to]'
 
GROUP BY 
	data_bundle->>'outlet_id' ORDER BY data_bundle->>'outlet_id' ASC");
		
	while($row_item = pg_fetch_assoc($query_item))
		{
			$details_item[] = $row_item;
		}
		
		
?>


<div class="shadow-lg p-3 mb-1 bg-white rounded" style="position:fixed; width:100%; z-index:9999;">
   <a href="dashboard.php" class="btn btn-success btn-sm">Back</a>
 
</div>
 
 <br/>
<br/>
<br/>



  <!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table {
    border-collapse: collapse;
    border-spacing: 0;
    width: 100%;
    border: 1px solid #ddd;
}

th, td {
    padding: 5px;
	font-size:10px;
}

tr:nth-child(even){background-color: #f2f2f2}
</style>
</head>
<body>

<h2>&nbsp;Outletwise Reports&nbsp;&nbsp;  <a data-toggle="modal" href="#myModals" style="background-color:#666;" class="btn btn-success btn-sm"><i class="fa fa-filter"></i> More Filter</a> </h2>
<center><h5><b>From: </b><font size="2"><?php echo date("d-m-Y",strtotime($_GET['from'])); ?></font> <b>To : </b><font size="2"><?php echo date("d-m-Y",strtotime($_GET['to'])); ?></font></h4></center>
<div class="modal fade" id="myModal" role="dialog">
  <div class="modal-dialog modal-lg" style="width:95%; padding-top:100px;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
         
          <h4 class="modal-title">Choose Outlet</h4>
           <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body ">
                <label id='ur_id'><label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>   
  <button style="display:none" type="button" class="btn btn-info btn-lg btn_open_modal" data-toggle="modal" data-target="#myModal">Open Modal</button>   
<div style="overflow-x:auto;">
  
  
        
  <table class="table-bordered">
    <thead>
      <tr>
        
        <th width="50%" >&nbsp;<font size="2">OUTLET NAME</font></th>
        <th width="50%"><font size="2">SALES AMOUNT</font></th>
        
      </tr>
    </thead>
    <tbody>
    <?php
	$a1=0;$a2=0;$a3=0;$a4=0;$a5=0;$a6=0;$a7=0;$a8=0;$a9=0;$a10=0;		
	$counter=0;
	foreach($details_item as $i):
	$a1+=$i['a1'];$a2+=$i['a2'];$a3+=$i['a3'];$a4+=$i['a4'];$a5+=$i['a5'];$a6+=$i['a6'];$a7+=$i['a7'];$a8+=$i['a8'];$a9+=$i['a9'];$a10+=$i['a10'];				  
	?>
      <tr>
      
        <td ><font size="2"><?php  
		$query = mysql_query("SELECT id outlet_id,name outlet_name FROM users WHERE id='$i[outlet_id]'");
		while($row = mysql_fetch_array($query))
		{
			echo $row['outlet_name'];
		}
	?></font></td>
        <td align="center">&nbsp;<font size="2">
       <?php  $total=$i['a1']+$i['a2']+$i['a3']+$i['a4']+$i['a5']+$i['a6']+$i['a7']+$i['a8']+$i['a9']+$i['a10'];
	   $fmt = new NumberFormatter($locale = 'en_IN', NumberFormatter::DECIMAL);
	echo $fmt->format($total); ?></font></td>
       
        
      </tr>
		<?php
		endforeach;
		?> 

 <tr>
 <td ><b><font size="2"><b>GROSS TOTAL SALE</b></font></td>
 <td align="center"><font size="2"><b><?php $gross_total=$a1+$a2+$a3+$a4+$a5+$a6+$a7+$a8+$a9+$a10;
 $fmt = new NumberFormatter($locale = 'en_IN', NumberFormatter::DECIMAL);
	echo $fmt->format($gross_total); ?></b></font></td>
 </tr>
    </tbody>
  </table>
  
</div>

</body>
</html>
<div class="modal fade" id="myModals" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-dialog" style="padding-top:70px;">
						<div class="modal-content">
							<div class="modal-header">
								
								<h2 class="modal-title">Filter</h2>
							<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button></div>
							 <form class="form-horizontal" role="form" method="post">
<div class="modal-body">
					
                     <div class="form-group">
                        <label for="inputLinkPp" class="hidden-xs col-sm-6 control-label">Sales From:</label>
                        <div class="input-group col-sm-8 xs-margin">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
                    <input type="date" class="form-control" name="from" id="from" value="<?php 
					if(isset($_GET['from'])) { echo $_GET['from']; } else { echo $current_date;  } ?>">
                       </div>
                    </div>
                     <div class="form-group">
                        <label for="inputLinkPp" class="hidden-xs col-sm-6 control-label">Sales To:</label>
                        <div class="input-group col-sm-8 xs-margin">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
                    <input type="date" class="form-control" name="to" id="to" value="<?php 
					if(isset($_GET['to'])) { echo $_GET['to']; } else { echo $current_date;  } ?>">
                       </div>
                    </div>
                    
</div>
<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								<button type="submit" name="submit" id="submit" class="btn btn-primary">Search</button>
							</div>
                            </form>
						</div><!-- /.modal-content -->
					</div><!-- /.modal-dialog -->
				</div>  
   <script>
    function priceSorter(a, b) {
        a = +a.substring(1); // remove $
        b = +b.substring(1);
        if (a > b) return 1;
        if (a < b) return -1;
        return 0;
    }
</script>
<script>
  
$(document).on('click','.lbl_item',function(){
	var item_id = $(this).attr('itm_id');
	console.log(item_id);
	$.ajax({
			url:"getbalance.php",
			data:{'item_id':item_id},
			type:'POST',
			success:function(data)
			{
				$("#ur_id").html(data);
			}
	});	
	
	$(".btn_open_modal").click();
});
</script>
 <script>
(function(document) {
    'use strict';

    var LightTableFilter = (function(Arr) {

          var _input;

          function _onInputEvent(e) {
              _input = e.target;
              var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
				});
			});
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
		};
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			LightTableFilter.init();
		}
	});

})(document);
</script>

<script>
$.tablesorter.addParser({ 
    id: 'price', 
    is: function(s) { 
        return false; 
    }, 
    format: function(s) { 
        return s.replace(/Free/,0).replace(/ CHF/,""); 
    }, 
    type: 'numeric' 
}); 

$(function() { 
    $("table").tablesorter({ 
        headers: { 
            1: { 
                sorter:'price' 
            } 
        } 
    }); 
});
</script>