<?php
session_start();
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
$d =  $_POST['item_id'];
$details = explode('$',$d);
$header_id = $details[0];
$query_merchant_assign=mysql_query("SELECT a.header_id id,a.header_date date,b.outlet_name outlet,a.header_total_sale total_sale,a.header_total_expense total_expense,a.header_total_cash cash_deposit,a.header_excess excess FROM sales_header a
      LEFT JOIN rem_outlet b ON a.header_outlet = b.outlet_id
       WHERE a.header_id='$header_id'");
   
  while($row_item = mysql_fetch_array($query_merchant_assign))
    {
      $date=$row_item[1];
      $outlet=$row_item[2];
      $total_sales=$row_item[3];
        $total_expense=$row_item[4];
          $cash_deposit=$row_item[5];
           $excess=$row_item['excess'];
    }


?>
	<table class="table table-bordered" id="table"
               data-toggle="table"
               data-height="460"
               data-sort-name="price"
               data-sort-order="desc" width="100%">
  
    <tbody>

      <tr>
        <td width="80%" id="smallfont"><font size="2">DATE</font></td>
        <td width="50%" id="smallfont" align="right"><font size="2"><?php echo date("d-m-Y", strtotime($date));?></font></td>
        </tr>
    <tr>
        <td width="80%" id="smallfont"><font size="2">OUTLET</font></td>
        <td width="50%" id="smallfont" align="right"><font size="2" align="right"><?php echo $outlet;?></font></td>
        </tr>

      <?php 
        $result_category= mysql_query("SELECT cat_id,cat_name FROM  sales_category WHERE cat_id!='4'");
        while($row_category = mysql_fetch_array($result_category))
        { ?>
        <tr style="background-color: #D3D3D3;">
        <td width="100%" id="smallfont" colspan="2" align="center"><font size="2"><?php echo $row_category['cat_name']; ?></font></td>
        </tr>

          <?php
          $result_sales_item= mysql_query("SELECT item_id,item_name FROM  sales_item WHERE item_category='$row_category[0]'");
          while($row_sales_item = mysql_fetch_array($result_sales_item))
          { ?>
      <tr>
          <td width="80%" id="smallfont"><font size="2"><?php echo $row_sales_item[1]; ?></font></td>
          <td width="50%" id="smallfont" align="right"><font size="2">
          <?php
          $query_amount=mysql_query("SELECT sales_amount FROM sales WHERE sales_header_id='$header_id' AND sales_item='$row_sales_item[0]'");
          while($row_amount = mysql_fetch_array($query_amount))
          {
            echo $row_amount[0];
          }
          //echo "SELECT sales_amount FROM sales WHERE sales_header_id='$header_id' AND sales_item='$row_sales_item[0]'";?>
          </font></td>
          </tr>
      <?php
      }
    }
    ?>
     <tr style="background-color: #696969;">
        <td width="80%" id="smallfont"><font size="2" color="#FFFFFF">TOTAL SALE:</font></td>
        <td width="50%" id="smallfont" align="right"><font size="2" color="#FFFFFF"><?php echo $total_sales; ?></font></td>

        </tr>
        <tr style="background-color: #D3D3D3;">
        <td width="100%" colspan="2" id="smallfont" align="center"><font size="2">EXPENSE</font></td>
        </tr>

        <?php

          $result_sales_item= mysql_query("SELECT item_id,item_name FROM  sales_item WHERE item_category='4'");
          while($row_sales_item = mysql_fetch_array($result_sales_item))
          { ?>
      <tr>
          <td width="80%" id="smallfont"><font size="2"><?php echo $row_sales_item[1]; ?></font></td>
          <td width="50%" id="smallfont" align="right"><font size="2">

          <?php
          $query_amount=mysql_query("SELECT sales_amount FROM sales WHERE sales_header_id='$header_id' AND sales_item='$row_sales_item[0]'");
          while($row_amount = mysql_fetch_array($query_amount))
          {
            echo $row_amount[0];
          }
          //echo "SELECT sales_amount FROM sales WHERE sales_header_id='$header_id' AND sales_item='$row_sales_item[0]'";?>
            

          </font></td>
          </tr>
      <?php
      }?>
       <tr style="background-color: #696969;">
        <td width="80%" id="smallfont"><font size="2" color="#FFFFFF">TOTAL EXPENSE:</font></td>
        <td width="50%" id="smallfont" align="right"><font size="2" color="#FFFFFF"><?php echo $total_expense; ?></font></td>

        </tr>

        <tr style="background-color: #696969;">
        <td width="80%" id="smallfont"><font size="2" color="#FFFFFF">CASH DEPOSIT:</font></td>
        <td width="50%" id="smallfont" align="right"><font size="2" color="#FFFFFF"><?php echo $cash_deposit; ?></font></td>

        </tr>
        <tr style="background-color: #696969;">
        <td width="80%" id="smallfont"><font size="2" color="#FFFFFF">EXCESS/ SHORT:</font></td>
        <td width="50%" id="smallfont" align="right"><font size="2" color="#FFFFFF"><?php echo $excess; ?></font></td>

        </tr>
 </tbody>
  </table>