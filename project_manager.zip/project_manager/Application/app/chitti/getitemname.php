<?php
ob_start();
session_start(); 
include("dbconnection.php");

?>
  
                        
              <table class="table">
                            <thead>
                            <tr>
                                
                                <th width="86%" > Item Name</th>
                                <th width="14%"  >Qty</th>
                         
                            </tr>
                            </thead>
                            <tbody>
                                        <?php
				if($_GET['q'] == 'FAV')
				{
					
					  $result= mysql_query("SELECT a.itemid item_id,a.itemname item_name,a.itemcode item_code,b.catname item_category,c.unitname item_unit,d.price item_price,a.category category,a.unit unit FROM `fav_items` a LEFT JOIN itemcategory b ON a.category=b.catid LEFT JOIN itemunit c ON a.unit=c.unitid LEFT JOIN items d ON a.itemid=d.itemid  where a.branch='$_GET[branch1]' ORDER BY item_category,item_name ASC");
				}
				else
				{
					$result= mysql_query("SELECT * FROM items where category='$_GET[q]' ORDER BY category");
				}
				
				 $counter =0;
				while($row = mysql_fetch_array($result))
  				{	
				 ?>     
                       
                            <form method="post">
            	 <tr class="warning">
                                <td > <?php echo "$row[itemname]";?></td>
                                
                                <td><input type="hidden" class="form-control input-width-xlarge desig-text required" placeholder="" name="orderid1" value="<?php echo $_GET['orderheaderid']; ?>"   id="orderid1" style="display: block;  width: 70px; height: 32px; margin: 5px; padding: 5px;"><input type="hidden" class="form-control input-width-xlarge desig-text required" placeholder="" name="itemid1" value="<?php echo $row["itemid"]; ?>"   id="itemid1" style="display: block;  width: 70px; height: 32px; margin: 5px; padding: 5px;"><input type="hidden" class="form-control input-width-xlarge desig-text required" placeholder="" name="itemcode1" value="<?php echo $row["itemcode"]; ?>"   id="itemcode1" style="display: block;  width: 70px; height: 32px; margin: 5px; padding: 5px;"><input type="hidden" class="form-control input-width-xlarge desig-text required" placeholder="" name="price1" value="<?php echo $row["price"]; ?>"   id="price1" style="display: block;  width: 70px; height: 32px; margin: 5px; padding: 5px;">
                             
 <input type="hidden" class="form-control input-width-xlarge desig-text required" placeholder="" name="category1" value="<?php echo $row["category"]; ?>"   id="category1" style="display: block;  width: 70px; height: 32px; margin: 5px; padding: 5px;">               
             
<input type="number" class="form-control input-width-xlarge desig-text required" placeholder="" name="qty" value="<?php $result191 = mysql_query("SELECT * FROM order_details where orderheaderid='$_GET[orderheaderid]' AND itemid='$row[itemid]'");
while($row191 = mysql_fetch_array($result191))
{
	echo $row191["qty"];
	
} ?>"  onkeyup="showprice(this.value, orderid1.value, itemid1.value, itemcode1.value, price1.value, category1.value)"  id="qty" style="display: block;  width: 70px; height: 32px; margin: 0px; padding: 5px;"></font></td>
                            
                              
                            </tr>
                             </form>
                          <?php } ?>
                        
                            
     
<script>
function showprice(str,orderid1,itemid1,itemcode1,price1,category1) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("txtdisplayprice").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getmrp.php?q="+str+"&orderid1="+orderid1+"&itemid1="+itemid1+"&itemcode1="+itemcode1+"&price1="+price1+"&category1="+category1,true);
  xmlhttp.send();
}
</script>                       
                          
                            </tbody>
                        </table>