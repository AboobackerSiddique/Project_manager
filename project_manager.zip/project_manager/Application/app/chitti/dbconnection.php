<?php
include("../dbconnection.php");
?>