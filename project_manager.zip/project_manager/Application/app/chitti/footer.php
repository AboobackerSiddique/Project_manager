<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!--footer section start-->
            <footer>
               <b> 2019 &copy; Powered By: <a href="#">Loyalhospitality.</a></b>
            </footer>
            <!--footer section end-->
