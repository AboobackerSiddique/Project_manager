<?php
error_reporting(E_ERROR | E_PARSE);
session_start();
ob_start();

include("dbconnection.php");
include("../functions/admin.php");
if(isset($_POST["btnlogin"]))
{
//patient Login funtion..
$loginvalidation =  loginfuntion($_POST["loginid"],$_POST["password"]);
}
if(isset($_SESSION["user_name"]) || isset($_SESSION["user_outlet"]))
{
  header("Location: home.php");
}
else
{
?><!DOCTYPE html>
<html lang="en">

<!-- Mirrored from thevectorlab.net/slicklab/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 02 Apr 2015 23:05:04 GMT -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Admin Template">
    <meta name="keywords" content="admin dashboard, admin, flat, flat ui, ui kit, app, web app, responsive">
    <link rel="shortcut icon" href="img/ico/favicon.png">
    <title>Login</title>

    <!-- Base Styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.min.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->


</head>

  <body class="login-body">

      <div class="login-logo">
          <img src="images/logo.png" alt="" height="110"/>
          <br/><br/>
          <font color="#FFA500" face="MuseoSlab500,"Helvetica Neue","Helvetica","Liberation Sans",Arial,sans serif" size="5"><b>Sales Entry</b></font>
      </div>

     
      <div class="container log-row">
          <form class="form-signin" method="post" >
              <div class="login-wrap">
               <p><center><font color="#FFFF00"><?php echo $loginvalidation; ?></font></center></p> 
                  <input type="text" name="loginid" id="loginid" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("password").focus();return false;}' class="form-control" placeholder="User Name" autofocus>
                  <input type="password"  class="form-control"  name="password" id="password" placeholder="Password">
                  <button class="btn btn-lg btn-success btn-block" name="btnlogin" id="btnlogin" type="submit">LOGIN</button>
                 
                 <br/>
<center>
                  <div class="registration">
                     <font color="#FFFFF">@2019 Powered By :&nbsp;</font>
                      <a class="" href="#">
                         <b><font color="#66FFFF"> Loyalhospitality</font></b>
                      </a>
                  </div>
</center>	
              </div>
	  

            

          </form>
      </div>


      <!--jquery-1.10.2.min-->
      <script src="js/jquery-1.11.1.min.js"></script>
      <!--Bootstrap Js-->
      <script src="js/bootstrap.min.js"></script>
      <script src="js/jrespond..min.html"></script>

  </body>

<!-- Mirrored from thevectorlab.net/slicklab/login.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 02 Apr 2015 23:05:05 GMT -->
</html>
<?php }
?>