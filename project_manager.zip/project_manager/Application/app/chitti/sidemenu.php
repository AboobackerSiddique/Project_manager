 <ul class="nav nav-pills nav-stacked side-navigation">
                    <li>
                        <h3 class="navigation-title"><a href="home.php">Side Menu</a></h3>
                    </li>
                    <li class="active"><a href="home.php"><i class="fa fa-home"></i> <span>Dashboard</span></a></li>
                    
                  <br/><br/><center> <img src="images/logo_big.png"  /></center>

                </ul>