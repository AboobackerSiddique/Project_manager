<?php
ob_start();
error_reporting(E_ERROR | E_PARSE);
session_start();
include("header1.php"); 
include("dbconnection.php");
?>
 <style> 
 body, html {
    height: 100%;
    margin: 0;
}

.bg {
    /* The image used */
    background-image: url("img/bg.jpg");

    /* Full height */
    height: 100%; 

    /* Center and scale the image nicely */
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
	
}
.start {
 position: absolute;
     margin: auto;
     top: 0;
     right: 0;
     bottom: 0;
     left: 0;
     width: 100%;
     height: 100%;

} 

.btn {
  background-color: #F9F9F9;
  width:100%;
  border: none;
  color: black;
  padding: 16px 32px;
  text-align: center;
  font-size: 14px;
  margin:2px;
  transition: 0.3s;
}

.btn:hover {
  background-color: #B92626;
  color: white;
}
</style>


<div class="shadow-lg p-3 mb-1 bg-white rounded" style="position:fixed; width:100%; z-index:9999;">
   <a href="../index.php" >Home</a> | CHITTI FORM
 
</div>
 
	<div class="bg">
	<div class="start">
	<center>
	<br/><br/><br/><br/>
	<div class="form-group col-md-6">
            	<a href="addorder.php" class="btn" >ADD NEW SALES </a>
                
    </div>
    <div class="form-group col-md-6">
            	<a href="balancereports.php?from=<?php echo date("Y-m-d"); ?>&to=<?php echo date("Y-m-d"); ?>&outlet=<?php if($_SESSION['user_type'] !='Outlet'){ echo 'ALL'; } else { echo $_SESSION['user_outlet']; } ?>" class="btn" >HISTORY </a>
                
    </div>	
	</center>
	</div>
	</div>