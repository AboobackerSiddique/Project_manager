<?php
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE); 
include("dbconnection.php");
$total_sales=$_GET['op']+$_GET['cashless_cod']+$_GET['tacash']+$_GET['tacard']+$_GET['paytm']+$_GET['phonepe'];
?>

  <input type="number" readonly="readonly" class="form-control input-width-xlarge desig-text required"  placeholder="" name="total_sale" value="<?php echo $total_sales; ?>"  id="total_sale" style="display: block;  width: 100px; height: 32px; margin: 0px; padding: 5px; text-align:right">