<?php 
ob_start();
session_start();
include("header.php");
include("functions/admin.php");
include("dbconnection.php");
?>
<div class="wrapper col5">
  <div id="container">
    <div id="content">
      <h1>Logout Page.</h1>
      <br /><?php 
 if(isset($_SESSION["user_name"]))
{
session_destroy();
header("Location: index.php");
}
 ?>
 <div id="respond"></div>
    </div>
<div class="clear"></div>
  </div>
</div>
</body>
</html>
