<?php
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE); 
include("dbconnection.php");
$total_cash=$_GET['cash']-$_GET['total_sale'];
?>

    <input type="number" class="form-control input-width-xlarge desig-text required"  placeholder="" name="excess" value=""  id="excess" style="display: block;  width: 100px; height: 32px; margin: 0px; padding: 5px; text-align:right">