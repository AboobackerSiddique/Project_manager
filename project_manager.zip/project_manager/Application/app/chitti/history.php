<?php 
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php"); 
?>
<?php
ob_start();
error_reporting(E_ERROR | E_PARSE); 
// set time-out period (in seconds)
$inactive = 10000000;
 
// check to see if $_SESSION["timeout"] is set
if (isset($_SESSION["timeout"])) {
    // calculate the session's "time to live"
    $sessionTTL = time() - $_SESSION["timeout"];
    if ($sessionTTL > $inactive) {
        session_destroy();
        header("Location: index.php");
    }
}
 
$_SESSION["timeout"] = time();?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from thevectorlab.net/slicklab/index.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 02 Apr 2015 23:00:52 GMT -->

   <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Mosaddek">
    <meta name="keyword" content="slick, flat, dashboard, bootstrap, admin, template, theme, responsive, fluid, retina">
    <link rel="shortcut icon" href="javascript:;" type="image/png">

 <link rel="shortcut icon" href="images/logo.png" type="image/png">
    <title>Hotel Empire</title>

    <!--easy pie chart-->
     <link href="css/slidebars.css" rel="stylesheet">

    <!--switchery-->
    <link href="js/switchery/switchery.min.css" rel="stylesheet" type="text/css" media="screen" />

    <!--iCheck-->
    <link href="js/icheck/skins/all.css" rel="stylesheet">

    <!--tagsinput-->
    <link href="css/tagsinput.css" rel="stylesheet">

    <!--Select2-->
    <link href="css/select2.css" rel="stylesheet">
    <link href="css/select2-bootstrap.css" rel="stylesheet">

    <!--bootstrap-touchspin-->
    <link href="css/bootstrap-touchspin.css" rel="stylesheet">

    <!--bootstrap picker-->
    <link rel="stylesheet" type="text/css" href="js/bootstrap-datepicker/css/datepicker.css"/>
    <link rel="stylesheet" type="text/css" href="js/bootstrap-timepicker/compiled/timepicker.css"/>
    <link rel="stylesheet" type="text/css" href="js/bootstrap-colorpicker/css/colorpicker.css"/>
    <link rel="stylesheet" type="text/css" href="js/bootstrap-daterangepicker/daterangepicker-bs3.css"/>
    <link rel="stylesheet" type="text/css" href="js/bootstrap-datetimepicker/css/datetimepicker.css"/>

    <!--common style-->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/style-responsive.css" rel="stylesheet">

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->
</head>

<body class="sticky-header">

    <section>
        <!-- sidebar left start-->
        <div class="sidebar-left">
            <!--responsive view logo start-->
            <div class="logo dark-logo-bg visible-xs-* visible-sm-*">
                <a href="">
                    <img src="img/logo.png" alt="">
                    <!--<i class="fa fa-maxcdn"></i>-->
                    <span class="brand-name">Hotel Empire</span>
                </a>
            </div>
            <!--responsive view logo end-->

            <div class="sidebar-left-info">
                <!-- visible small devices start-->
                <div class=" search-field">  </div>
                <!-- visible small devices end-->

                <!--sidebar nav start-->
                <?php include("sidemenu.php"); ?>
               
                <!--sidebar nav end-->

              

            </div>
        </div>
        <!-- sidebar left end-->

        <!-- body content start-->
        <div class="body-content" >

            <!-- header section start-->
            <div class="header-section">

               
               <!--logo and logo icon end--><form method="post"><?php if(isset($_GET["from"]))
{?>&nbsp;&nbsp;
&nbsp;&nbsp;
<button type="submit" name="back" id="back" style="margin-top:12px; width:100px;" class="btn-sm"><font color="#000000">BACK</font></button>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="submit" name="logout" id="logout" style="margin-top:12px; ;" class="btn btn-danger btn-sm"><font color="#000000">LOGOUT</font></button><?php } else
{?>
&nbsp;&nbsp;
<button type="submit" name="menu" id="menu" style="margin-top:12px; width:100px;" class="btn btn-warning btn-sm"><font color="#000000">MAIN MENU</font></button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button type="submit" name="logout" id="logout" style="margin-top:12px; ;" class="btn btn-danger btn-sm"><font color="#000000">LOGOUT</font></button>
<?php } ?>
               
</form>
            </div>
            <!-- header section end-->
            
            
  <?php
if(isset($_SESSION["username"]))
{
$result19 = mysql_query("SELECT * FROM branch where branchid='$_POST[branch]'");
while($row19 = mysql_fetch_array($result19))
{
	$branch = $row19["branchid"];
}

if(isset($_POST["select"]))
   {
	   header("Location: history.php?branch=$_POST[branch]&from=$_POST[from]&to=$_POST[to]");
   }
   
   if(isset($_POST["menu"]))
   {
	  header("Location: home.php");
   }
   
   if(isset($_POST["logout"]))
   {
	  header("Location: logout.php");
   }
   
   if(isset($_POST["back"]))
   {
	  header("Location: history.php");
   }
   
   
   if(isset($_POST["all"]))
   {
    header("Location: addorder.php?orderheaderid=$_GET[orderheaderid]&branch=$_GET[branch]&date=$_GET[date]&items=ALL");
   }
   
     if(isset($_POST["fav"]))
   {
    header("Location: addorder.php?orderheaderid=$_GET[orderheaderid]&branch=$_GET[branch]&date=$_GET[date]&items=FAV");
   }
?>


            <!-- page head start-->
            <!-- page head end-->

            <!--body wrapper start-->
            <div class="wrapper">

            
            
            <?php if(isset($_GET["from"]))
			{ ?>
           <div id="txtdisplayprice"></div>   
             <div id="txtdisplayitemname"> 
               
            <div class="row">
              <div class="col-lg-8">
                  <section class="panel">
                        
                <table class="table">
                            <thead>
                            <tr>
                                
                                <th width="51%" > Order Details</th>
                                <th width="32%"  >Branch</th>
                                
                                <th width="17%"  >Amount</th>
                         
                            </tr>
                            </thead>
                            <tbody>
                                        <?php
				
					  $result= mysql_query("SELECT * FROM orderheader1 where branch='$_GET[branch]' AND date BETWEEN '$_GET[from]' AND '$_GET[to]'");
				
				 
				while($row = mysql_fetch_array($result))
  				{	
				 ?>     
                       
                            <form method="post">
            	 <tr class="warning">
                              <td > <a href="viewdetailhistory.php?orderheaderid=<?php echo $row["orderheaderid"]; ?>&branch=<?php echo $_GET['branch']; ?>&from=<?php echo $_GET['from']; ?>&to=<?php echo $_GET['to']; ?>"> <b>Order No:&nbsp;<?php echo "$row[orderheaderid]";?></b><br/><font size="1"><?php echo date("d-m-Y h:i:a", strtotime($row["entrydate"]));?></font></a></td>
                                
                                <td> <a href="viewdetailhistory.php?orderheaderid=<?php echo $row["orderheaderid"]; ?>&branch=<?php echo $_GET['branch']; ?>&from=<?php echo $_GET['from']; ?>&to=<?php echo $_GET['to']; ?>"><b><font color="#0000FF"><?php $result1= mysql_query("SELECT * FROM branch where branchid='$row[branch]'");
				
				 
				while($row1 = mysql_fetch_array($result1))
  				{
					echo $row1["shortname"]; }?></font><b></a></td>
                    
                     <td align="right"><a href="viewdetailhistory.php?orderheaderid=<?php echo $row["orderheaderid"]; ?>&branch=<?php echo $_GET['branch']; ?>&from=<?php echo $_GET['from']; ?>&to=<?php echo $_GET['to']; ?>"><b><font color="#FF0000"><?php $result3= mysql_query("SELECT SUM(total) FROM order_details1 where orderheaderid='$row[orderheaderid]'");
				
				 
				while($row3 = mysql_fetch_array($result3))
  				{
					echo $row3[0]; }?></font><b></a></td>
                            
                              
                            </tr>
                             </form>
                          <?php } ?>
                        
                            
                            
                          
                            </tbody>
                        </table>
                   
                </section>
              </div>
            </div></div>
            <?php }
			else
			{ ?>
           <div class="row">
              <div class="col-sm-8">
                  <section class="panel">
                       <form method="post" action="">
                    
                        <table class="table table-striped">
                            <thead>
                            <tr>
                                <th colspan="2" align="center">&nbsp;<b>History</b></th> 

                                
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                            <td width="142"><b>&nbsp;From :</b></td>
                                <td width="350" >  <input type="date" class="form-control input-width-xlarge desig-text required" placeholder="Enter Branch Name" name="from" value="<?php date_default_timezone_set('Asia/Calcutta');
		echo date("Y-m-d"); ?>"   id="from" style="display: block;  width: 180px; height: 32px; margin: 0px; padding: 5px;"></td>
                            
                               
                                
                            </tr>
                             <tr>
                            <td><b>&nbsp;To :</b></td>
                                <td >  <input type="date" class="form-control input-width-xlarge desig-text required" placeholder="Enter Branch Name" name="to" value="<?php date_default_timezone_set('Asia/Calcutta');
		echo date("Y-m-d"); ?>"   id="to" style="display: block;  width: 180px; height: 32px; margin: 0px; padding: 5px;"></td>
                            
                               
                                
                            </tr>
                              <tr>
                              <td><b>&nbsp;Branch :</b></td>
                            <td>
                   <?php
         $res123 = mysql_query("SELECT * FROM  usermaster where userid='$_SESSION[userid]'");
		 
		 ?><select name="branch" id="branch" style="width:180px; margin-bottom:0%;"  class="form-control input-width-xlarge desig-text " required>
       
        
       
		<?php  
   
     while($rowf = mysql_fetch_array($res123))
  	{
		$res12300 = mysql_query("SELECT * FROM  branch where branchid='$rowf[branchid]'");
		while($row12300 = mysql_fetch_array($res12300))
  	{
		
echo "<option value='$row12300[branchid]'>$row12300[shortname]</option>";
	}}
	?>	</select>
                    </td>
                             
                                
                            </tr>
                              <tr ><td height="65"><b></b></td>
                                <td><button type="submit"  name="select" id="select" class="btn-sm" style="width:180px !important; margin:0% !important;">SEARCH </button></td>
                                
                            </tr>
                             
                           
                            </tbody>
                        </table>
                    
                    </form>
                </section>
              </div>
            </div>
            <?php } ?>
         
            </div>
            <!--body wrapper end-->


            <!--footer section start-->
           <?php include("footer.php"); ?>
            <!--footer section end-->


            <!-- Right Slidebar start --><!-- Right Slidebar end -->

        </div>
        <!-- body content end-->
    </section>
<script>
(function(document) {
    'use strict';

    var LightTableFilter = (function(Arr) {

          var _input;

          function _onInputEvent(e) {
              _input = e.target;
              var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
				});
			});
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
		};
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			LightTableFilter.init();
		}
	});

})(document);
</script>

<script>
function showprice(str,orderid,itemid,itemcode,price,category) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("txtdisplayprice").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getmrp.php?q="+str+"&orderid="+orderid+"&itemid="+itemid+"&itemcode="+itemcode+"&price="+price+"&category="+category,true);
  xmlhttp.send();
}
</script>
<script>
function showitemname(str,order,branch1) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("txtdisplayitemname").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getitemname.php?q="+str+"&orderheaderid="+order+"&branch1="+branch1,true);
  xmlhttp.send();
}
</script>

<script src="js/jquery-1.10.2.min.js"></script>
<script src="js/jquery-migrate.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/modernizr.min.js"></script>

<!--Nice Scroll-->
<script src="js/jquery.nicescroll.js" type="text/javascript"></script>

<!--right slidebar-->
<script src="js/slidebars.min.js"></script>

<!--switchery-->
<script src="js/switchery/switchery.min.js"></script>
<script src="js/switchery/switchery-init.js"></script>

<!--Sparkline Chart-->
<script src="js/sparkline/jquery.sparkline.js"></script>
<script src="js/sparkline/sparkline-init.js"></script>


<!--common scripts for all pages-->
<script src="js/scripts.js"></script>
<script src="js/jquery-1.10.2.min.js"></script>
<script src="js/jquery-ui/jquery-ui-1.10.1.custom.min.js"></script>
<script src="js/jquery-migrate.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/modernizr.min.js"></script>

<!--Nice Scroll-->
<script src="js/jquery.nicescroll.js" type="text/javascript"></script>

<!--right slidebar-->
<script src="js/slidebars.min.js"></script>

<!--switchery-->
<script src="js/switchery/switchery.min.js"></script>
<script src="js/switchery/switchery-init.js"></script>

<!--Sparkline Chart-->
<script src="js/sparkline/jquery.sparkline.js"></script>
<script src="js/sparkline/sparkline-init.js"></script>


<!--bootstrap picker-->
<script type="text/javascript" src="js/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="js/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script>
<script type="text/javascript" src="js/bootstrap-daterangepicker/moment.min.js"></script>
<script type="text/javascript" src="js/bootstrap-daterangepicker/daterangepicker.js"></script>
<script type="text/javascript" src="js/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script>
<script type="text/javascript" src="js/bootstrap-timepicker/js/bootstrap-timepicker.js"></script>

<!--picker initialization-->
<script src="js/picker-init.js"></script>

<!--Icheck-->
<script src="js/icheck/skins/icheck.min.js"></script>
<!--icheck init-->
<script src="js/icheck-init.js"></script>

<!--tags input-->
<script src="js/tags-input.js"></script>

<!--tags input init-->
<script src="js/tags-input-init.js"></script>

<!--bootstrap-inputmask-->
<script src="js/bs-input-mask.min.js"></script>

<!--touchspin spinner-->
<script src="js/touchspin.js"></script>

<!--spinner init-->
<script src="js/spinner-init.js"></script>

<!--select2-->
<script src="js/select2.js"></script>
<!--select2 init-->
<script src="js/select2-init.js"></script>


<!--common scripts for all pages-->
<script src="js/scripts.js"></script>
<script src="js/jquery-1.10.2.min.js"></script>
<script src="js/jquery-ui/jquery-ui-1.10.1.custom.min.js"></script>
<script src="js/jquery-migrate.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/modernizr.min.js"></script>

<!--Nice Scroll-->
<script src="js/jquery.nicescroll.js" type="text/javascript"></script>

<!--right slidebar-->
<script src="js/slidebars.min.js"></script>

<!--switchery-->
<script src="js/switchery/switchery.min.js"></script>
<script src="js/switchery/switchery-init.js"></script>

<!--Sparkline Chart-->
<script src="js/sparkline/jquery.sparkline.js"></script>
<script src="js/sparkline/sparkline-init.js"></script>


<!--bootstrap picker-->
<script type="text/javascript" src="js/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
<script type="text/javascript" src="js/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script>
<script type="text/javascript" src="js/bootstrap-daterangepicker/moment.min.js"></script>
<script type="text/javascript" src="js/bootstrap-daterangepicker/daterangepicker.js"></script>
<script type="text/javascript" src="js/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script>
<script type="text/javascript" src="js/bootstrap-timepicker/js/bootstrap-timepicker.js"></script>

<!--picker initialization-->
<script src="js/picker-init.js"></script>

<!--Icheck-->
<script src="js/icheck/skins/icheck.min.js"></script>
<!--icheck init-->
<script src="js/icheck-init.js"></script>

<!--tags input-->
<script src="js/tags-input.js"></script>

<!--tags input init-->
<script src="js/tags-input-init.js"></script>

<!--bootstrap-inputmask-->
<script src="js/bs-input-mask.min.js"></script>

<!--touchspin spinner-->
<script src="js/touchspin.js"></script>

<!--spinner init-->
<script src="js/spinner-init.js"></script>

<!--select2-->
<script src="js/select2.js"></script>
<!--select2 init-->
<script src="js/select2-init.js"></script>


<!--common scripts for all pages-->
<script src="js/scripts.js"></script>

</body>

<!-- Mirrored from thevectorlab.net/slicklab/table-static.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 

02 Apr 2015 23:03:48 GMT -->
</html>
<?php }
else
{
	header("Location: index.php");
}?>