<?php 
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
include("header.php");
 if($_SESSION['user_name'])
{


if(isset($_POST["search"]))
{
		$items = mysql_query("SELECT cat_id FROM rem_work_category WHERE cat_name='$_POST[work]'");
		while($items_row = mysql_fetch_array($items))
		{
			$item_id = $items_row[0];
		}
		header("Location: addwork.php?work=$item_id&from_type=$_POST[from_type]&from=$_POST[from]&from_outlet=$_POST[from_outlet]&vendor=$_POST[vendor]");
		
}

if(isset($_POST["submit"]))
{
		$from_type=$_GET['from_type'];
		$from_outlet=$_GET['from_outlet'];
		$from=$_GET['from'];
		$category=$_GET['work'];
		$user_name=$_SESSION["user_name"];
		
		$checkbox1 = $_POST['chk1'];
		$checkbox2 = $_POST['chk2'];
		$checkbox3 = $_POST['chk3'];
		$checkbox4 = $_POST['chk4'];
		$checkbox5 = $_POST['chk5'];
		$checkbox6 = $_POST['chk6'];
		$checkbox7 = $_POST['chk7'];		
		
		for ($i=0; $i<sizeof($checkbox1); $i++)
		{
		for ($i=0; $i<sizeof($checkbox2); $i++)
		{
		for ($i=0; $i<sizeof($checkbox3); $i++)
		{
		for ($i=0; $i<sizeof($checkbox4); $i++)
		{
		for ($i=0; $i<sizeof($checkbox5); $i++)
		{
		for ($i=0; $i<sizeof($checkbox6); $i++)
		{
		for ($i=0; $i<sizeof($checkbox7); $i++)
		{
		
		if($checkbox1[$i] == '' || $checkbox2[$i] == '' || $checkbox3[$i] == '' || $checkbox4[$i] == '' || $checkbox5[$i] == '' || $checkbox6[$i] == '' || $checkbox7[$i] == '')
		{

		}
		else
		{
			
			date_default_timezone_set('Asia/Calcutta');
			$current_date=date("Y-m-d H:i");
			$time=$checkbox7[$i].":00";
	
$sql="INSERT INTO rem_works_details(details_date,details_vendor,details_type,details_outlet,details_to,details_work_category,details_work,details_start,details_finish,details_alert,details_alert_time,details_user)
VALUES
('$current_date','".$checkbox3[$i]."','$from_type','$from_outlet','$from','$category','".$checkbox1[$i]."','".$checkbox4[$i]."','".$checkbox5[$i]."','".$checkbox6[$i]."','$time','$_SESSION[user_name]')";
 			
			if(!mysql_query($sql,$con))
          	{
            	die('Error: ' . mysql_error());
          	}
		}
		}
		}
		}
		}
		}
		}
		
			$message = 'Work Assigned Successfully';

   			echo "<SCRIPT type='text/javascript'> 
        	alert('$message');
        	window.location.replace(\"addwork.php\");
    		</SCRIPT>";
			
		}
}

?>
   
<div id="wrapper">
            <div id="layout-static">
              <div class="static-content-wrapper">
                  <div class="static-content">
                        <div class="page-content">
                          <ol class="breadcrumb">
                                
 <li class=""> <div class="btn-toolbar">
       <a class="btn btn-midnightblue" href="index.php"><i class="fa fa-fast-backward"></i> Back</a>
       
      
    </div></li>


                          </ol>
                            <div class="container-fluid">
                              
  <div class="row">
	<div class="col-sm-12">
	  <div class="panel panel-midnightblue">
	    <div class="panel-body">
	      <div class="tab-content">
	      <div class="tab-pane active" id="horizontal-form">
	      <form  method="post" class="form-horizontal">
                    
					  <div class="form-group">
						
						<div class="col-sm-12">
                        <div class="col-sm-2">
                               
								<?php 
								$items = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor");
								?>Choose Outlet/Warehouse:
                               	<select  class="form-control"   name="from_type" id="from_type" onchange="showfromtype(this.value)" required >
         						<option value="2">WAREHOUSE</option>
                                <option value="3">OUTLET</option>
                                        						
      							</select>
   							  </div>
                               
                               
                               <div id="displayFromType">
                               		<div class="col-sm-2">
                               <input type="hidden" name="from_outlet" id="from_outlet" value="0" />
								<?php 
								$warehouse = mysql_query("SELECT warehouse_id,warehouse_name FROM rem_warehouse");
								?>Choose Warehouse:
                               	<select  class="form-control"   name="from" id="from" required >
         						<option value="">CHOOSE WAREHOUSE</option>
         						<?php 
   								while($area_row = mysql_fetch_array($warehouse))
								{
								?>
								<option value="<?php echo $area_row[0]; ?>"><?php echo $area_row[1]; }?></option>
      							</select>
      								</div>
                               </div>
                               	<div class="col-sm-2">
                               	<?php 
								$vendor = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor ORDER BY vendor_name ASC");
								?>Choose Vendor:
                               	<select  class="form-control"   name="vendor" id="vendor" required >
         						<option value="">CHOOSE VENDOR</option>
         						<?php 
   								while($area_vendor = mysql_fetch_array($vendor))
								{
								?>
								<option value="<?php echo $area_vendor[0]; ?>"><?php echo $area_vendor[1]; }?></option>
      							</select>
      								</div>
                               <div class="col-sm-3">
                               
								 <?php
         				$items = mysql_query("SELECT cat_name FROM rem_work_category ");
		 				?>
Search Work Category :     
<input list="work" name="work" class="form-control" autocomplete="off" placeholder="Search Work Category" value="" required  >
<datalist id="work">
<?php 
   						while($row_items  = mysql_fetch_array($items ))
						{
						?>
            	<option value="<?php echo $row_items[0];  ?>"></option>
        	<?php
			} 
			?>
</datalist>  
      							</div>
                              <div class="col-sm-1"><br/>
                              <button type="submit" class="btn btn-success"  name="search" id="search">Select</button>
							  </div> 
						 
                        
                        
                        
                        
                    	</div>
       				</div>
                    </form>
                   
                    <form method="post">
                    <div class="form-group">
						  
								<div class="col-sm-12">
                                <?php if(isset($_GET['work']))
								{?>
                               <div id="demo">
                               <center><h4><u><b><?php echo $vendor_name; ?></b></u></h4></center>
<table cellpadding="0"  width="30%" cellspacing="0" border="1" class="table table-striped table-fixed-header m0"  >
<tr style="background-color:#999999; color:#FFF;">
<td ><b>WORK CATEGORY</b></td>
<td ><b>WORK NAME</b></td>
<td ><b>VENDOR NAME</b></td>
<td ><b>WORK START</b></td>
<td ><b>WORK END </b></td>
<td ><b>CHOOSE ALERT</b></td>
<td ><b>ALERT TIME</b></td>
</tr>
<?php 

	$result = mysql_query("SELECT a.work_id id,a.work_name name,b.cat_name category FROM rem_work_master a LEFT JOIN rem_work_category b ON a.work_category=b.cat_id WHERE a.work_category='$_GET[work]'");
$counter=0;
while($row = mysql_fetch_array($result))
{
	
?>

<tr class="venTab">
<td width="13%"><?php echo $row['category']; ?> </td>
<td width="32%"><?php echo $row['name']; ?>
<input type="hidden" name="chk1[]" id="chk1[]" value="<?php echo $row['id']; ?>" />
<input type="hidden" name="chk2[]" id="chk2[]" value="<?php echo $_GET['work']; ?>" /></td>
<td width="18%"><?php 
					$warehouse = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor where vendor_id='$_GET[vendor]'");
					
   					while($area_row = mysql_fetch_array($warehouse))
					{
						echo $area_row[1];
					}
					?><input type="hidden" name="chk3[]" id="chk3[]" value="<?php echo $_GET['vendor']; ?>"></td>
<td width="7%"><input type="date" class="form-control" name="chk4[]" id="chk4[]" value="<?php date_default_timezone_set('Asia/Calcutta');
echo date("Y-m-d"); ?>"></td>
<td width="7%"><input type="date"  class="form-control" name="chk5[]" id="chk5[]" value=""  autocomplete="off" placeholder="Enter Item Barcode"></td>
<td width="13%"><?php 
					$alert = mysql_query("SELECT alert_id,alert_name FROM rem_work_alert");
					?>
                    <select  class="form-control" name="chk6[]" id="chk6[]" >
         			<option value="">CHOOSE</option>
         			<?php 
   					while($area_alert = mysql_fetch_array($alert))
					{
					?>
					<option value="<?php echo $area_alert[0]; ?>"><?php echo $area_alert[1]; }?></option>
      				</select></td>
                    <td width="13%"><?php 
					$time = mysql_query("SELECT time_id,time_name FROM rem_work_alert_time");
					?>
                    <select  class="form-control" name="chk7[]" id="chk7[]" >
         			<option value="">CHOOSE</option>
         			<?php 
   					while($area_time = mysql_fetch_array($time))
					{
					?>
					<option value="<?php echo $area_time[1]; ?>"><?php echo $area_time[1]; }?></option>
      				</select></td>
</tr>
<?php }  ?>

</table>
</div><br/>
    <center><button type="submit" class="btn btn-info"  name="submit" id="submit">Assign Work</button></center>
<?php } ?>

</div>
       </div>
     </form>               
                    
					  </div>
					
					</div>
	 
				
         
			</div>
		</div>
          
	</div>
</div>
                          </div> 
                            <!-- .container-fluid -->
                        </div> <!-- #page-content -->
                </div>
                    <footer role="contentinfo">
   <?php include("footer.php"); ?>
</footer>
              </div>
  </div>
</div>
<script
  src="https://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
<script>


$(document).on("keyup","#qty",function()
{
	
	var oldVal = $("#stock").val();
	var newVal = $(this).val();
if(parseFloat(oldVal)<parseFloat(newVal))
{
alert('Sorry..! You dont have insufficient Stock Available to transfer ');
$(this).val(oldVal);
}	
});


function showfromtype(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayFromType").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransferfromtype.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showfrommerchant(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayFromMerchant").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransfermerchant.php?q="+str,true);
  xmlhttp.send();
}
</script>

<script>
function showfromemployeemerchant(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {

    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayFromEmployeeMerchant").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransferemployeemerchant.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showfromemployee(str,emp_outlet) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayFromEmployee").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransferemployee.php?q="+str+"&emp_outlet="+emp_outlet,true);
  xmlhttp.send();
}
</script>


<script>
function showcategory(str,from_type,from_outlet,from) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayItem").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransferitem.php?q="+str+"&from_type="+from_type+"&from_outlet="+from_outlet+"&from="+from,true);
  xmlhttp.send();
}
</script>

<script>
function showstock(str,stock_from_type,stock_from_outlet,stock_from) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayStock").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransferstock.php?q="+str+"&stock_from_type="+stock_from_type+"&stock_from_outlet="+stock_from_outlet+"&stock_from="+stock_from,true);
  xmlhttp.send();
}
</script>
<script>
function showtotype(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayToType").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransfertotype.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showtomerchant(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayToMerchant").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransfertomerchant.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showtoemployeemerchant(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {

    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayToEmployeeMerchant").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransfertoemployeemerchant.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showtoemployee(str,emp_outlet) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayToEmployee").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransfertoemployee.php?q="+str+"&emp_outlet="+emp_outlet,true);
  xmlhttp.send();
}
</script>
<!-- Switcher --><!-- /Switcher -->
    <!-- Load site level scripts -->

<!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script> -->
<script>
function confirmDelete(delUrl) {
  if (confirm("Are you sure you want to delete")) {
    document.location = delUrl;
  }
}
</script>
<script src="assets/js/jquery-1.10.2.min.js"></script> 							<!-- Load jQuery -->
<script src="assets/js/jqueryui-1.9.2.min.js"></script> 							<!-- Load jQueryUI -->

<script src="assets/js/bootstrap.min.js"></script> 								<!-- Load Bootstrap -->


<script src="assets/plugins/easypiechart/jquery.easypiechart.js"></script> 		<!-- EasyPieChart-->
<script src="assets/plugins/sparklines/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
<script src="assets/plugins/jstree/dist/jstree.min.js"></script>  				<!-- jsTree -->

<script src="assets/plugins/codeprettifier/prettify.js"></script> 				<!-- Code Prettifier  -->
<script src="assets/plugins/bootstrap-switch/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->

<script src="assets/plugins/bootstrap-tabdrop/js/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->

<script src="assets/plugins/iCheck/icheck.min.js"></script>     					<!-- iCheck -->

<script src="assets/js/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->

<script src="assets/plugins/bootbox/bootbox.js"></script>							<!-- Bootbox -->

<script src="assets/plugins/simpleWeather/jquery.simpleWeather.min.js"></script> <!-- Weather plugin-->

<script src="assets/plugins/nanoScroller/js/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->

<script src="assets/plugins/jquery-mousewheel/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script src="assets/plugins/datatables/jquery.dataTables.js"></script>
<script src="assets/plugins/datatables/dataTables.bootstrap.js"></script>
<script src="assets/demo/demo-datatables.js"></script>
<script src="assets/js/application.js"></script>
<script src="assets/demo/demo.js"></script>
<script src="assets/demo/demo-switcher.js"></script>

<!-- End loading site level scripts -->
    
    <!-- Load page level scripts-->
    

    <!-- End loading page level scripts-->

</body>

<!-- Mirrored from avenger.kaijuthemes.com/ui-forms.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 24 Oct 2015 18:46:10 GMT -->
</html>
<?php }
      else
        {
	       header('Location: ../index.php');
        }
		
	?>