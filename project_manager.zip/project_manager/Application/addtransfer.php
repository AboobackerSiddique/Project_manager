<?php 
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
include("header.php");
 if($_SESSION['user_name'])
{


if(isset($_POST["search"]))
{
		$from_type=$_POST['from_type'];
		$from_outlet=$_POST['from_outlet'];
		$from=$_POST['from'];
		$to_type=$_POST['to_type'];
		$to_outlet=$_POST['to_outlet'];
		$to=$_POST['to'];
		$item_id=$_POST['itemid'];
		$movable=$_POST['move'];
		$qty=$_POST['qty'];
		

 $sql="INSERT INTO rem_transfer(transfer_item,transfer_qty,transfer_from_type,transfer_from_outlet,transfer_from,transfer_to_type,transfer_to_outlet,transfer_to,transfer_movable,transfer_user)
VALUES
('$item_id','$qty','$from_type','$from_outlet','$from','$to_type','$to_outlet','$to','$movable','$_SESSION[user_name]')";
 

       		if(!mysql_query($sql,$con))
          	{
            	die('Error: ' . mysql_error());
          	}
		
		$message = 'Transfer Request Sent Successfully';

   			echo "<SCRIPT type='text/javascript'> 
        	alert('$message');
        	window.location.replace(\"addtransfer.php\");
    		</SCRIPT>";
}
?>
   
<div id="wrapper">
            <div id="layout-static">
              <div class="static-content-wrapper">
                  <div class="static-content">
                        <div class="page-content">
                          <ol class="breadcrumb">
                                
 <li class=""> <div class="btn-toolbar">
       <a class="btn btn-midnightblue" href="index.php"><i class="fa fa-fast-backward"></i> Back</a>
      
    </div></li>


                          </ol>
                            <div class="container-fluid">
                              
  <div class="row">
	<div class="col-sm-12">
	  <div class="panel panel-midnightblue">
	    <div class="panel-body">
	      <div class="tab-content">
	      <div class="tab-pane active" id="horizontal-form">
	      <form  method="post" class="form-horizontal">
                    
					  <div class="form-group">
						
						<div class="col-sm-12" ">
                        <div class="col-sm-2">
                               
								<?php 
								$items = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor");
								?>From_type:
                               	<select  class="form-control"   name="from_type" id="from_type" onchange="showfromtype(this.value)" required >
         						<option value="2">WAREHOUSE</option>
                                <option value="3">OUTLET</option>
                                <option value="4">EMPLOYEE</option>
         						
      							</select>
      							</div>
                               
                               
                               <div id="displayFromType">
                               		<div class="col-sm-2">
                               <input type="hidden" name="from_outlet" id="from_outlet" value="0" />
								<?php 
								$warehouse = mysql_query("SELECT warehouse_id,warehouse_name FROM rem_warehouse");
								?>Choose Warehouse:
                               	<select  class="form-control"   name="from" id="from" required >
         						<option value="">CHOOSE WAREHOUSE</option>
         						<?php 
   								while($area_row = mysql_fetch_array($warehouse))
								{
								?>
								<option value="<?php echo $area_row[0]; ?>"><?php echo $area_row[1]; }?></option>
      							</select>
      								</div>
                               </div>
                                
                                
                                
                                 <div class="col-sm-2">
                               
								 	<?php
         				$category = mysql_query("SELECT cat_id,cat_name FROM rem_vendor_category");
		 				?>Choose Category:
                               	<select  class="form-control" onchange="showcategory(this.value,from_type.value,from_outlet.value,from.value)"  name="category" id="category"  >
         						<option value="">CHOOSE CATEGORY</option>
         						<?php 
   								while($row_category = mysql_fetch_array($category))
								{
								?>
								<option value="<?php echo $row_category[0]; ?>"><?php echo $row_category[1]; }?></option>
      							</select>
      							</div>
                                
                  <div id="displayItem">    
                            <div class="col-sm-2"> 
                            Search Item:     
                          
                        <input list="item_id" name="item_id" onchange="showvendorprice(this.value)" class="form-control" autocomplete="off" placeholder="Search Item" value=""  >
        					<datalist id="item_id">
       		
    						</datalist>  
                   			 </div> 
                   </div>
                    
                    
                    <div id="displayStock">
                        	 <div class="col-sm-2">
                             Available Stock: 
								<input type="text" readonly="readonly" class="form-control"  id="stock" value="" name="stock" placeholder="Available Stock" >
      						</div> 
                   </div>
                        
                                 
                        <div class="col-sm-2" style="padding-top:50px;">
                             Enter Qty: 
								<input type="text" autocomplete="off" class="baseAmt form-control"  id="qty" value="<?php echo round($row_items_list[3], 1); ?>" name="qty" placeholder="Amount"  required="required">
      					</div>         
                       <br/><br/>         
                        <div class="col-sm-2" style="padding-top:50px;">
                               
								<?php 
								$items = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor");
								?>To_type:
                               	<select  class="form-control"   name="to_type" id="to_type" onchange="showtotype(this.value)" required >
         						<option value="2">WAREHOUSE</option>
                                <option value="3">OUTLET</option>
                                <option value="4">EMPLOYEE</option>
         						
      							</select>
      							</div>        
                                
                                <div id="displayToType">
                               		<div class="col-sm-2" style="padding-top:50px;">
                               <input type="hidden" name="to_outlet" id="to_outlet" value="0" />
								<?php 
								$warehouse = mysql_query("SELECT warehouse_id,warehouse_name FROM rem_warehouse");
								?>Choose Warehouse:
                               	<select  class="form-control"   name="to" id="to" required >
         						<option value="">CHOOSE WAREHOUSE</option>
         						<?php 
   								while($area_row = mysql_fetch_array($warehouse))
								{
								?>
								<option value="<?php echo $area_row[0]; ?>"><?php echo $area_row[1]; }?></option>
      							</select>
      								</div>
                               </div>  
                               <div class="col-sm-2" style="padding-top:50px;">
                               
								<?php 
								$items = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor");
								?>Movable/Immovable:
                               	<select  class="form-control"   name="move" id="move"  required>
         						
                                <option value="0">MOVABLE</option>
                                <option value="1">IMMOVABLE</option>
         						
      							</select>
      							</div>
                               <div class="col-sm-1" style="padding-top:50px;"><br/>
                              <button type="submit" class="btn btn-success"  name="search" id="search">Transfer Request Order</button>
      								</div> 
						 
                        
                        
                        
                        
                    	</div>
       				</div>
                    </form>
                    <br/>
                    
                    
					  </div>
					
					</div>
	 
				
         
			</div>
		</div>
          <div class="panel panel-midnightblue">
	    <div class="panel-body">
	      <div class="tab-content">
	      <div class="tab-pane active" id="horizontal-form">
	      <form  method="post" class="form-horizontal">
                    
					  <div class="form-group">
						
						<div class="col-sm-12">
                      
                   <table cellpadding="0"  width="30%" cellspacing="0" border="1" class="table table-striped table-fixed-header m0"  >
<tr style="background-color:#666; color:#FFF;">
<td colspan="8" align="center" ><b>TRANSFER REQUESTED ITEMS</b></td>

</tr>
<tr style="background-color:#999999; color:#FFF;">
<td ><b>SL NO</b></td>
<td ><b>REQ TIME</b></td>
<td ><b>TRANSFER ITEM</b></td>
<td ><b>TRANSFER FROM</b></td>
<td ><b>TRANSFER TO</b></td>
<td ><b>QTY</b></td>
<td ><b>REQ BY</b></td>
<td ><b>STATUS</b></td>

</tr>
<?php 

 $query_item=mysql_query("SELECT a.transfer_id id,b.item_name item_name,c.cat_name item_category,a.transfer_qty qty,a.transfer_from_type from_type,a.transfer_from_outlet from_outlet,a.transfer_from from_warehouse,a.transfer_to_type to_type,a.transfer_to_outlet to_outlet,a.transfer_to to_warehouse,a.transfer_process process,a.transfer_user user,a.transfer_datetime date FROM rem_transfer a LEFT JOIN rem_item b ON a.transfer_item=b.item_id LEFT JOIN rem_vendor_category c ON b.item_category=c.cat_id WHERE a.transfer_process!=2 ORDER BY a.transfer_id DESC");
 
while($row_item = mysql_fetch_assoc($query_item))
	{
		$details_item[] = $row_item;
	}

	$counter=0;
	foreach($details_item as $i):				
	
?>


<tr class="venTab">
<td width="5%"><?php echo ++$counter; ?></td>
<td width="9%"><?php print_r(date("d-m-y H:i", strtotime($i['date']))) ;?> </td>
<td width="30%"><?php print_r($i['item_name']) ;?> </td>
<td width="13%"><?php  
		if($i['from_type'] == '2')
		{
			 $result1 = mysql_query("SELECT warehouse_name FROM rem_warehouse WHERE warehouse_id='$i[from_warehouse]'");
			while($row1 = mysql_fetch_array($result1))
  			{
				$outlet_name=$row1[0];
  			}
			echo "WAREHOUSE :&nbsp;".$outlet_name; 
			
		} 
		else if($i['from_type'] == '3')
		{
			$result1 = mysql_query("SELECT outlet_name FROM rem_outlet WHERE outlet_id='$i[from_outlet]'");
			while($row1 = mysql_fetch_array($result1))
  			{
				$outlet_name=$row1[0];
  			}
			$result2 = mysql_query("SELECT a.assign_counter counter_id,b.counter_name counter_name,c.merchant_name merchant_name FROM rem_counter_assign a LEFT JOIN rem_counter_master b ON a.assign_counter=b.counter_id LEFT JOIN rem_merchant c ON a.assign_merchant=c.merchant_id  WHERE a.assign_outlet='$i[from_outlet]' AND a.assign_counter='$i[from_warehouse]'");
			while($row2 = mysql_fetch_array($result2))
  			{
				$merchant_name =$row2['merchant_name'];
				$counter_name =$row2['counter_name'];
  			}
  			echo "OUTELET :&nbsp;".$outlet_name."&nbsp;(".$counter_name."-".$merchant_name.")"; 
		}
		else 
		{
			$result1 = mysql_query("SELECT outlet_name FROM rem_outlet WHERE outlet_id='$i[from_outlet]'");
			while($row1 = mysql_fetch_array($result1))
  			{
				$outlet_name=$row1[0];
  			}
			$result2 = mysql_query("SELECT emp_name FROM rem_employee WHERE emp_id='$i[from_warehouse]'");
			while($row2 = mysql_fetch_array($result2))
  			{
				$merchant_name =$row2[0];
  			}
  			echo "EMPLOYEE :&nbsp;".$merchant_name."&nbsp;(".$outlet_name.")"; 
		}
		
		 ?> </td>
<td width="13%"><?php  
		if($i['to_type'] == '2')
		{
			 $result1 = mysql_query("SELECT warehouse_name FROM rem_warehouse WHERE warehouse_id='$i[to_warehouse]'");
			while($row1 = mysql_fetch_array($result1))
  			{
				$outlet_name=$row1[0];
  			}
			echo "WAREHOUSE :&nbsp;".$outlet_name; 
			
		} 
		else if($i['to_type'] == '3')
		{
			$result1 = mysql_query("SELECT outlet_name FROM rem_outlet WHERE outlet_id='$i[to_outlet]'");
			while($row1 = mysql_fetch_array($result1))
  			{
				$outlet_name=$row1[0];
  			}
			$result2 = mysql_query("SELECT a.assign_counter counter_id,b.counter_name counter_name,c.merchant_name merchant_name FROM rem_counter_assign a LEFT JOIN rem_counter_master b ON a.assign_counter=b.counter_id LEFT JOIN rem_merchant c ON a.assign_merchant=c.merchant_id  WHERE a.assign_outlet='$i[to_outlet]' AND a.assign_counter='$i[to_warehouse]'");
			while($row2 = mysql_fetch_array($result2))
  			{
				$merchant_name =$row2['merchant_name'];
				$counter_name =$row2['counter_name'];
  			}
  			echo "OUTELET :&nbsp;".$outlet_name."&nbsp;(".$counter_name."-".$merchant_name.")";  
		}
		else 
		{
			$result1 = mysql_query("SELECT outlet_name FROM rem_outlet WHERE outlet_id='$i[to_outlet]'");
			while($row1 = mysql_fetch_array($result1))
  			{
				$outlet_name=$row1[0];
  			}
			$result2 = mysql_query("SELECT emp_name FROM rem_employee WHERE emp_id='$i[to_warehouse]'");
			while($row2 = mysql_fetch_array($result2))
  			{
				$merchant_name =$row2[0];
  			}
  			echo "EMPLOYEE :&nbsp;".$merchant_name."&nbsp;(".$outlet_name.")"; 
		}
		
		 ?></td>
<td width="5%"><?php print_r($i['qty']) ;?></td>
<td width="7%"><?php print_r($i['user']) ;?></td>
<td width="7%"><?php if($i['process'] == '0'){ ;?><button class="btn btn-warning btn-sm"><font color="#000000">Waiting for Transfer</font></button><?php } else if($i['process'] == '1'){?><button class="btn btn-success btn-sm">Waiting for Delivered</button><?php } ?></td>

</tr>
<?php
	endforeach;
	?>

</table>     
                    	</div>
       				</div>
                    </form>
                    <br/>
                    
                    
					  </div>
					
					</div>
	 
				
         
			</div>
		</div>
        
	</div>
</div>
                          </div> 
                            <!-- .container-fluid -->
                        </div> <!-- #page-content -->
                </div>
                    <footer role="contentinfo">
   <?php include("footer.php"); ?>
</footer>
              </div>
  </div>
</div>
<script
  src="https://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
<script>


$(document).on("keyup","#qty",function()
{
	
	var oldVal = $("#stock").val();
	var newVal = $(this).val();
if(parseFloat(oldVal)<parseFloat(newVal))
{
alert('Sorry..! You dont have insufficient Stock Available to transfer ');
$(this).val(oldVal);
}	
});


function showfromtype(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayFromType").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransferfromtype.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showfrommerchant(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayFromMerchant").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransfermerchant.php?q="+str,true);
  xmlhttp.send();
}
</script>

<script>
function showfromemployeemerchant(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {

    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayFromEmployeeMerchant").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransferemployeemerchant.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showfromemployee(str,emp_outlet) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayFromEmployee").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransferemployee.php?q="+str+"&emp_outlet="+emp_outlet,true);
  xmlhttp.send();
}
</script>


<script>
function showcategory(str,from_type,from_outlet,from) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayItem").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransferitem.php?q="+str+"&from_type="+from_type+"&from_outlet="+from_outlet+"&from="+from,true);
  xmlhttp.send();
}
</script>

<script>
function showstock(str,stock_from_type,stock_from_outlet,stock_from) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayStock").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransferstock.php?q="+str+"&stock_from_type="+stock_from_type+"&stock_from_outlet="+stock_from_outlet+"&stock_from="+stock_from,true);
  xmlhttp.send();
}
</script>
<script>
function showtotype(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayToType").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransfertotype.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showtomerchant(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayToMerchant").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransfertomerchant.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showtoemployeemerchant(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {

    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayToEmployeeMerchant").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransfertoemployeemerchant.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showtoemployee(str,emp_outlet) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayToEmployee").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransfertoemployee.php?q="+str+"&emp_outlet="+emp_outlet,true);
  xmlhttp.send();
}
</script>
<!-- Switcher --><!-- /Switcher -->
    <!-- Load site level scripts -->

<!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script> -->
<script>
function confirmDelete(delUrl) {
  if (confirm("Are you sure you want to delete")) {
    document.location = delUrl;
  }
}
</script>
<script src="assets/js/jquery-1.10.2.min.js"></script> 							<!-- Load jQuery -->
<script src="assets/js/jqueryui-1.9.2.min.js"></script> 							<!-- Load jQueryUI -->

<script src="assets/js/bootstrap.min.js"></script> 								<!-- Load Bootstrap -->


<script src="assets/plugins/easypiechart/jquery.easypiechart.js"></script> 		<!-- EasyPieChart-->
<script src="assets/plugins/sparklines/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
<script src="assets/plugins/jstree/dist/jstree.min.js"></script>  				<!-- jsTree -->

<script src="assets/plugins/codeprettifier/prettify.js"></script> 				<!-- Code Prettifier  -->
<script src="assets/plugins/bootstrap-switch/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->

<script src="assets/plugins/bootstrap-tabdrop/js/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->

<script src="assets/plugins/iCheck/icheck.min.js"></script>     					<!-- iCheck -->

<script src="assets/js/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->

<script src="assets/plugins/bootbox/bootbox.js"></script>							<!-- Bootbox -->

<script src="assets/plugins/simpleWeather/jquery.simpleWeather.min.js"></script> <!-- Weather plugin-->

<script src="assets/plugins/nanoScroller/js/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->

<script src="assets/plugins/jquery-mousewheel/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script src="assets/plugins/datatables/jquery.dataTables.js"></script>
<script src="assets/plugins/datatables/dataTables.bootstrap.js"></script>
<script src="assets/demo/demo-datatables.js"></script>
<script src="assets/js/application.js"></script>
<script src="assets/demo/demo.js"></script>
<script src="assets/demo/demo-switcher.js"></script>

<!-- End loading site level scripts -->
    
    <!-- Load page level scripts-->
    

    <!-- End loading page level scripts-->

</body>

<!-- Mirrored from avenger.kaijuthemes.com/ui-forms.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 24 Oct 2015 18:46:10 GMT -->
</html>
<?php }
      else
        {
	       header('Location: ../index.php');
        }
		
	?>