<?php 
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
include("header.php");
if($_SESSION['user_name'])
{

if(isset($_POST["select"]))
{
	header("Location: addbarcode.php?warehouse=$_POST[warehouse]");
}?>
   
<div id="wrapper">
            <div id="layout-static">
              <div class="static-content-wrapper">
                  <div class="static-content">
                        <div class="page-content">
                          <ol class="breadcrumb">
                                
 <li class=""> <div class="btn-toolbar">
       <a class="btn btn-midnightblue" href="index.php"><i class="fa fa-fast-backward"></i> Back</a>
    </div></li>


                          </ol>
                            <div class="container-fluid">
                              
<div class="row">
	<div class="col-sm-12">
	  <div class="panel panel-midnightblue">
	    <div class="panel-body">
	      <div class="tab-content">
	      <div class="tab-pane active" id="horizontal-form">
	      <form  method="post" class="form-horizontal">
                     <?php if(isset($_GET['display']))
					 {
						 ?> <center><font color="#FF0000" size="3"><b><?php echo $_GET['display']; ?></b></font></center>
                         <?php } ?>
                         <div class="form-group">
					      
						   <div class="col-sm-3">
                               
								<?php 
								if(isset($_GET['warehouse']))
								{
									$items = mysql_query("SELECT warehouse_id,warehouse_name FROM rem_warehouse WHERE warehouse_id!='$_GET[warehouse]'");
								}
								else
								{
									
									$items = mysql_query("SELECT warehouse_id,warehouse_name FROM rem_warehouse");
								}
					
								?>Choose Warehouse:
                               	<select  class="form-control"   name="warehouse" id="warehouse" onkeydown='if(event.keyCode == 13){document.getElementById("vendor").focus();return false;}'  onchange="showcategory(this.value)" >
         						<?php 
								if(isset($_GET['warehouse']))
								{
								$warehouse = mysql_query("SELECT warehouse_id,warehouse_name FROM rem_warehouse WHERE warehouse_id='$_GET[warehouse]'");
								while($row_warehouse = mysql_fetch_array($warehouse))
								{
								?>
                                <option value="<?php echo $row_warehouse[0]; ?>"><?php echo $row_warehouse[1]; }?></option>
                              
                                <?php } ?>
         						<?php 
   								while($area_row = mysql_fetch_array($items))
								{
								?>
								<option value="<?php echo $area_row[0]; ?>"><?php echo $area_row[1]; }?></option>
      							</select>
      							</div>
                               
                                <div class="col-sm-1"><br/>
                               <button type="submit" class="btn btn-info"  style="background-color:#F93;"  name="select" id="select">Select</button>
								
      							</div>
                                <div class="col-sm-3">
                                <img src="images/Barcode-icon.png" width="150" height="70">
								
      							</div>
                      </div>	
                        
                       
                       	  <div class="form-group">
						  
								<div class="col-sm-12">
                                <?php if(isset($_GET['warehouse']))
								{?>
                               <div id="demo">
                               <center><h4><u><b><?php echo $vendor_name; ?></b></u></h4></center>
<table cellpadding="0"  width="30%" cellspacing="0" border="1" class="table table-striped table-fixed-header m0"  >
<tr style="background-color:#999999; color:#FFF;">
<td ><b>SL NO</b></td>
<td ><b>PO-NO</b></td>
<td ><b>DELIVERED DATE</b></td>
<td> <b>VENDOR NAME</b></td>
<td ><b>ITEM NAME</b></td>
<td ><b>QTY</b></td>
<td ><b>GENERATE </b></td>
</tr>
<?php 

	$result = mysql_query("SELECT a.details_id id,a.details_po pono,a.details_date entry_date,a.details_order_date order_date,a.details_delivery_date delivery_date,b.vendor_name vendor,c.item_name item,a.details_qty qty,a.details_delivered_date delivered,details_vendor vendor_id FROM rem_delivery_details a LEFT JOIN rem_vendor b ON a.details_vendor=b.vendor_id LEFT JOIN rem_item c ON a.details_item=c.item_id WHERE a.details_from_type='1' AND a.details_to='$_GET[warehouse]' AND details_barcode=0 ORDER BY pono");


$counter=0;
while($row = mysql_fetch_array($result))
{
?>

<tr class="venTab">
<td width="5%"><?php echo ++$counter; ?>
<td width="5%" align="center"><?php echo $row['pono']; ?> </td>
<td width="13%"  ><?php echo date("Y-m-d h:i:a", strtotime($row['entry_date'])); ?></td>
<td width="20%"><?php echo $row['vendor']; ?></td>
<td width="35%"><?php echo $row['item']; ?></td>
<td width="7%" align="center"><?php echo round($row['qty'],1); ?></td>
<td width="10%"><a class="btn btn-info" href="generatebarcode.php?id=<?php echo $row['id']; ?>&warehouse=<?php echo $_GET['warehouse']; ?>&vendor=<?php echo $_GET['vendor']; ?>&vendor_id=<?php echo $row['vendor_id']; ?>"><i class="fa  fa-barcode"></i>&nbsp;Generate Barcode</a></td>
</tr>
<?php } ?>

</table>
</div>

</div>
       </div>
                   	 
					</div>
                    
                     
  <?php } ?>
                    </form>
				
         
			</div>
		</div>
        
	</div>
</div>
                          </div> 
                            <!-- .container-fluid -->
                        </div> <!-- #page-content -->
                </div>
                    <footer role="contentinfo">
   <?php include("footer.php"); ?>
</footer>
              </div>
  </div>
</div>
<script>
function showqty(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayQty").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getorderform.php?q="+str,true);
  xmlhttp.send();
}
</script>

<!-- Switcher --><!-- /Switcher -->
    <!-- Load site level scripts -->

<!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script> -->
<script>
function confirmDelete(delUrl) {
  if (confirm("Are you sure you want to delete")) {
    document.location = delUrl;
  }
}
</script>
<script src="assets/js/jquery-1.10.2.min.js"></script> 							<!-- Load jQuery -->
<script src="assets/js/jqueryui-1.9.2.min.js"></script> 							<!-- Load jQueryUI -->

<script>
$(document).ready(function(){
	$(document).on('keyup','.qty',function(){
		var bAmt = $(this).parents('.venTab').find('.baseAmt').attr('amt');
		var reqQty = $(this).parents('.venTab').find('.reqQty').text();
		var cQty = $(this).val();
		var amt = parseFloat(bAmt)*parseFloat(cQty);
		var balQty = parseFloat(reqQty)-parseFloat(cQty)
		$(this).parents('.venTab').find('.totalAmt').val(amt);
		$(this).parents('.venTab').find('.balQty').val(balQty);
		});
	})
</script>
<script src="assets/js/bootstrap.min.js"></script> 								<!-- Load Bootstrap -->


<script src="assets/plugins/easypiechart/jquery.easypiechart.js"></script> 		<!-- EasyPieChart-->
<script src="assets/plugins/sparklines/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
<script src="assets/plugins/jstree/dist/jstree.min.js"></script>  				<!-- jsTree -->

<script src="assets/plugins/codeprettifier/prettify.js"></script> 				<!-- Code Prettifier  -->
<script src="assets/plugins/bootstrap-switch/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->

<script src="assets/plugins/bootstrap-tabdrop/js/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->

<script src="assets/plugins/iCheck/icheck.min.js"></script>     					<!-- iCheck -->

<script src="assets/js/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->

<script src="assets/plugins/bootbox/bootbox.js"></script>							<!-- Bootbox -->

<script src="assets/plugins/simpleWeather/jquery.simpleWeather.min.js"></script> <!-- Weather plugin-->

<script src="assets/plugins/nanoScroller/js/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->

<script src="assets/plugins/jquery-mousewheel/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script src="assets/plugins/datatables/jquery.dataTables.js"></script>
<script src="assets/plugins/datatables/dataTables.bootstrap.js"></script>
<script src="assets/demo/demo-datatables.js"></script>
<script src="assets/js/application.js"></script>
<script src="assets/demo/demo.js"></script>
<script src="assets/demo/demo-switcher.js"></script>

<!-- End loading site level scripts -->
    
    <!-- Load page level scripts-->
    

    <!-- End loading page level scripts-->

</body>

<!-- Mirrored from avenger.kaijuthemes.com/ui-forms.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 24 Oct 2015 18:46:10 GMT -->
</html>
<?php }
      else
        {
	       header('Location: ../index.php');
        }
		
	?>