<?php  
session_start();
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");

date_default_timezone_set('Asia/Calcutta');
$current_date = date("Y-m-d");

if(isset($_POST["search"]))
{
	header("Location: agreementreports.php?outlet=$_POST[outlet]&merchant=$_POST[merchant]");
	
}

if(isset($_POST["alot"]))
{
	header("Location: agreementreports1.php?outlet=$_POST[outlet]&merchant=$_POST[merchant]");
	
}


	$query_item=mysql_query("SELECT a.item_id item_id,a.item_name item_name,b.cat_name item_category,c.stock req,c.sales price  FROM rem_item a LEFT JOIN rem_vendor_category b ON a.item_category=b.cat_id LEFT JOIN (SELECT assign_item,SUM(assign_qty) stock,SUM(assign_amount) sales FROM rem_merchant_item_assign WHERE assign_merchant='$_GET[merchant]' AND assign_outlet='$_GET[outlet]' GROUP BY assign_item) AS c ON c.assign_item = a.item_id WHERE a.item_id IN (SELECT assign_item FROM rem_merchant_item_assign WHERE assign_outlet='$_GET[outlet]' AND assign_merchant='$_GET[merchant]' GROUP BY assign_item)");

	while($row_item = mysql_fetch_assoc($query_item))
	{
		$details_item[] = $row_item;
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Project Manager</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
/* Paste this css to your style sheet file or under head tag */
/* This only works with JavaScript, 
if it's not present, don't show loader */
.no-js #loader { display: none;  }
.js #loader { display: block; position: absolute; left: 100px; top: 0; }
.se-pre-con {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url(images/pageLoader.gif) center no-repeat #fff;
}
</style>
</head>
<body>
<div class="se-pre-con"></div>

<div class="container">
  <h2>Merchantwise Item Assigned Reports</h2>
  <form method="post">
  <table>
  <tr>
  <td width="6%"><br/><a class="btn btn-primary btn-sm" href="index.php" role="button"><i class="fa fa-fast-backward"></i>&nbsp;Home</a></td>
  <td width="6%"><br/>&nbsp;<a class="btn btn-success btn-sm" href="exportagreement.php?outlet=<?php echo $_GET['outlet']; ?>&merchant=<?php echo $_GET['merchant']; ?>" role="button"><i class="fa fa-file-excel-o"></i>&nbsp;Export</a>&nbsp;</td>
  
  <td width="15%" >
  			  Choose Outlet: 
								<?php 
								$vendor = mysql_query("SELECT outlet_id,outlet_name FROM rem_outlet WHERE outlet_id!='$_GET[outlet]' AND outlet_type='0'");
								?>
                      	<select  class="form-control" onChange="showoutlet(this.value)"  name="outlet" id="outlet" onkeydown='if(event.keyCode == 13){document.getElementById("merchant").focus();return false;}'  >
                         
                                <?php 
								
							
								$vendor6 = mysql_query("SELECT outlet_id,outlet_name FROM rem_outlet WHERE outlet_id='$_GET[outlet]'");
								while($area_vendor6 = mysql_fetch_array($vendor6))
								{?>
								<option value="<?php echo $area_vendor6[0]; ?>"><?php echo $area_vendor6[1]; } ?></option>
                               
                                <?php 
   								while($area_vendor = mysql_fetch_array($vendor))
								{
								?>
								<option value="<?php echo $area_vendor[0]; ?>"><?php echo $area_vendor[1]; }?></option>
      					</select>
</td>
                               
<td width="15%">

    <div id="displayCategory">                      
                         
                       
                          Choose Merchant: 
								<?php 
								
								$merchant = mysql_query("SELECT merchant_id,merchant_name FROM rem_merchant");
								
								?>
                      	<select  class="form-control"   name="merchant" id="merchant" onkeydown='if(event.keyCode == 13){document.getElementById("merchant").focus();return false;}'>
                         
                                <?php 
								
								$vendor6 = mysql_query("SELECT merchant_id,merchant_name FROM rem_merchant WHERE merchant_id='$_GET[merchant]'");
								while($area_vendor6 = mysql_fetch_array($vendor6))
								{?>
								<option value="<?php echo $area_vendor6[0]; ?>"><?php echo $area_vendor6[1]; } ?></option>
                               
         						
                                <?php 
   								while($area_vendor = mysql_fetch_array($merchant))
								{
								?>
								<option value="<?php echo $area_vendor[0]; ?>"><?php echo $area_vendor[1]; }?></option>
      					</select> 
                   
        </div>                        
</td>

<td width="8%"><br/>&nbsp;<input class="btn btn-success btn-sm" type="submit" value="Assign Reports" name="search" id="search"></td>
<td width="8%"><br/>&nbsp;<input class="btn btn-info btn-sm" type="submit" value="Alloted Reports" name="alot" id="alot"></td>
<td width="22%"></td>
  </tr>
  </table>
  </form>
  <br/>  
  <div >
  <p align="right"><font color="#000000">Search  : &nbsp;</font><input type="search" class="light-table-filter" data-table="table-bordered" placeholder="Filter"></p>    
  </div><br/>
    <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg" style="width:90%;">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Stock Details</h4>
        </div>
        <div class="modal-body ">
                <label id='ur_id'><label>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>   
  <button style="display:none" type="button" class="btn btn-info btn-lg btn_open_modal" data-toggle="modal" data-target="#myModal">Open Modal</button>     
  <table class="table table-bordered" id="table"
               data-toggle="table"
               data-height="460"
               data-sort-name="price"
               data-sort-order="desc">
    <thead>
      <tr>
       
         <th class="col-md-1">SL.NO</th>
        <th class="col-md-5">ITEM NAME & DESCRIPTION</th>
        <th class="col-md-1">QTY</th> 
          <th class="col-md-1">PRICE</th>           
      </tr>
    </thead>
    <tbody>
    <?php
	$counter=0;
	foreach($details_item as $i):				
	?>
      <tr>
        <td><?php echo ++$counter; ?></td>

        <td><b><u><?php print_r($i['item_name']) ;?>:</u></b><?php print_r($stock=round($i['price'],0)) ;?><br/>
        <?php 
							$result_mapping = mysql_query("SELECT b.name,a.map_values FROM rem_item_mapping a LEFT JOIN rem_item_specification b ON a.map_specification_id=b.id WHERE a.map_item_id='$i[item_id]'");
							while($row_mapping = mysql_fetch_array($result_mapping))
  							{
								echo $row_mapping[0]." :&nbsp;".$row_mapping[1].",&nbsp;";
								
							}
	   						?>
        </td>
       	<td align="center"><?php print_r($stock=round($i['req'],0)) ;?></td>
      	<td align="right">&nbsp;</td>  
      
      </tr>
	<?php
	endforeach;
	?> 

 <tr>
 <td colspan="3" align="right"><b>TOTAL:</b></td>
 <td align="right">
 <?php 
 $result_mapping1 = mysql_query("SELECT SUM(assign_amount) FROM rem_merchant_item_assign WHERE assign_outlet='$_GET[outlet]' AND assign_merchant='$_GET[merchant]'");
							while($row_mapping1 = mysql_fetch_array($result_mapping1))
  							{
								echo round($row_mapping1[0],0);
							}
							?></td>
 </tr>
    </tbody>
  </table>
</div>
</body>
</html>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
<script>

//paste this code under the head tag or in a separate js file.
	// Wait for window load
	$(window).load(function() {
		// Animate loader off screen
		$(".se-pre-con").fadeOut("slow");;
	});
	</script>
    <script>
    function priceSorter(a, b) {
        a = +a.substring(1); // remove $
        b = +b.substring(1);
        if (a > b) return 1;
        if (a < b) return -1;
        return 0;
    }
</script>

<script
  src="https://code.jquery.com/jquery-3.3.1.js"
  integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
  crossorigin="anonymous"></script>

  <script
  src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.min.js"
 ></script>
  <script>
  
$(document).on('click','.lbl_item',function(){
	var item_id = $(this).attr('itm_id');
	console.log(item_id);
	$.ajax({
			url:"getstock.php",
			data:{'item_id':item_id},
			type:'POST',
			success:function(data)
			{
				$("#ur_id").html(data);
			}
	});	
	
	$(".btn_open_modal").click();
});
</script>
 <script>
(function(document) {
    'use strict';

    var LightTableFilter = (function(Arr) {

          var _input;

          function _onInputEvent(e) {
              _input = e.target;
              var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
				});
			});
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
		};
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			LightTableFilter.init();
		}
	});

})(document);
</script>
<script>
function showoutlet(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayCategory").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getmerchantwisestockreports1.php?q="+str,true);
  xmlhttp.send();
}
</script>


<script>
$.tablesorter.addParser({ 
    id: 'price', 
    is: function(s) { 
        return false; 
    }, 
    format: function(s) { 
        return s.replace(/Free/,0).replace(/ CHF/,""); 
    }, 
    type: 'numeric' 
}); 

$(function() { 
    $("table").tablesorter({ 
        headers: { 
            1: { 
                sorter:'price' 
            } 
        } 
    }); 
});
</script>