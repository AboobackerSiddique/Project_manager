<?php  
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");

date_default_timezone_set('Asia/Calcutta');
$current_date = date("Y-m-d");
if(isset($_POST["search"]))
{
	header("Location: advancereports.php?vendor=$_POST[vendor]&from=$_POST[from]&to=$_POST[to]");
}

		if($_GET['vendor'] == 'ALL')
		{
			$query_merchant_assign=mysql_query("SELECT j.payment_advance_no advance_no,j.payment_order_id pono,j.payment_order_type type,j.payment_date date,k.vendor_name vendor,j.payment_amount amount,l.method_name method,j.payment_description description,j.display display,j.payment_vendor_id vendor_id,m.advance_nos advance_nos FROM rem_order_payment j LEFT JOIN rem_vendor k ON j.payment_vendor_id=k.vendor_id LEFT JOIN rem_payment_method l ON j.payment_type=l.method_id LEFT JOIN rem_advance m ON j.payment_advance_no=m.advance_no WHERE  DATE(j.payment_date) BETWEEN '$_GET[from]' AND '$_GET[to]'  ORDER BY 1 DESC");
		}
		else
		{
			$query_merchant_assign=mysql_query("SELECT j.payment_advance_no advance_no,j.payment_order_id pono,j.payment_order_type type,j.payment_date date,k.vendor_name vendor,j.payment_amount amount,l.method_name method,j.payment_description description,j.display display,j.payment_vendor_id vendor_id,m.advance_nos advance_nos FROM rem_order_payment j 
LEFT JOIN rem_vendor k ON j.payment_vendor_id=k.vendor_id 
LEFT JOIN rem_payment_method l ON j.payment_type=l.method_id LEFT JOIN rem_advance m ON j.payment_advance_no=m.advance_no  WHERE j.payment_vendor_id='$_GET[vendor]' and DATE(j.payment_date) BETWEEN '$_GET[from]' AND '$_GET[to]' 
ORDER BY 1 DESC");
		}
		
	while($row_item = mysql_fetch_assoc($query_merchant_assign))
		{
			$details_item[] = $row_item;
		}
		
		
		



?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Project Manager</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
/* Paste this css to your style sheet file or under head tag */
/* This only works with JavaScript, 
if it's not present, don't show loader */
.no-js #loader { display: none;  }
.js #loader { display: block; position: absolute; left: 100px; top: 0; }
.se-pre-con {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url(images/pageLoader.gif) center no-repeat #fff;
}
</style>
</head>
<body>
<div class="se-pre-con"></div>

<div class="container">
 <h2>Advance Reports</h2>
  <form method="post">
  <table>
  <tr>
  <td width="7%"><br/><a class="btn btn-primary btn-sm" href="index.php" role="button"><i class="fa fa-fast-backward"></i>&nbsp;Home</a></td>
  <td width="7%"><br/><br/>&nbsp;<a class="btn btn-success btn-sm" href="exportadvance.php?vendor=<?php echo $_GET['vendor']; ?>&from=<?php echo $_GET['from']; ?>&to=<?php echo $_GET['to']; ?>" role="button"><i class="fa fa-file-excel-o"></i>&nbsp;Export</a>&nbsp;</td>
  <td width="10%">From Date: <br/><input type="date" class="form-control" value="<?php echo $_GET['from']; ?>" name="from" to="from"></td>
  <td width="10%">To Date: <br/><input type="date" class="form-control" value="<?php echo $_GET['to']; ?>" name="to" to="to"></td>
<td width="20%">
                          Choose Vendor: 
								<?php 
								$vendor = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor WHERE vendor_id!='$_GET[vendor]'");
								?>
                             	<select  class="form-control"  name="vendor" id="vendor" onkeydown='if(event.keyCode == 13){document.getElementById("type").focus();return false;}'  >
         						
                                
                                
                                <?php 
								if($_GET['vendor'] == 'ALL')
								{?>
                                <option value="ALL">ALL Vendor..</option>
                                <?php 
								} 
								else
								{
								$vendor6 = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor WHERE vendor_id='$_GET[vendor]'");
								while($area_vendor6 = mysql_fetch_array($vendor6))
								{
								?>
								<option value="<?php echo $area_vendo6r[0]; ?>"><?php echo $area_vendor6[1]; }?></option>
                                 <option value="ALL">ALL Vendor..</option>
                                  <?php } ?>
                               
         						<?php 
   								while($area_vendor = mysql_fetch_array($vendor))
								{
								?>
								<option value="<?php echo $area_vendor[0]; ?>"><?php echo $area_vendor[1]; }?></option>
      							</select>
                                
</td>
  

<td width="10%"><br/>&nbsp;&nbsp;<input class="btn btn-success btn-sm" type="submit" value="Search" name="search" id="search"></td>
<td width="55%"></td>

  </tr>
  </table>
  </form>
  <div >          <p align="right"><font color="#000000">Search  : &nbsp;</font><input type="search" class="light-table-filter" data-table="table-bordered" placeholder="Filter"></p>    </div><br/>
           
  <table class="table table-bordered" id="table"
               data-toggle="table"
               data-height="460"
               data-sort-name="price"
               data-sort-order="desc">
    <thead>
      <tr>
        <th class="col-md-1">SL No</th>
        <th class="col-md-2" >Adv No</th>
        <th class="col-md-1" >PO/WO No</th>
        <th class="col-md-2" >Paid Date</th>
        <th class="col-md-4">Vendor Name</th>
        <th class="col-md-1">Amount</th>
        <th class="col-md-1">Pay Method</th>
        <th class="col-md-3">Narration</th>
         <th class="col-md-1">Edit/Print</th>      
      </tr>
    </thead>
    <tbody>
    <?php
	$total_Advance=0;				
	$counter=0;
	foreach($details_item as $i):
	$total_Advance+=$i['advance'];					  
	?>
      <tr>
        <td><?php echo ++$counter; ?></td>
        <td align="center"><?php  print_r($i['advance_nos']); ?></td>
         <td align="center"><b><font color="#009966"><?php if($i['type'] == '1') { print_r("<font color='#009966'>PO- ".$i['pono']); } else { print_r("<font color='#FF0000'>WO- ".$i['pono']); } ?></font></b></td>
        <td><?php echo date("d-m-Y h:i:a", strtotime($i['date'])) ;?></td>
        
         <td><?php print_r($i['vendor']) ;?></td>
        <td align="right"><?php echo $amount=$i['amount'];
		?></td>
        <td align="right">
		<?php print_r($i['method']) ;?></td>
        <td align="right"><?php print_r($i['description']) ;?></td>
        <td align="center"><a href="viewadvance.php?advno=<?php echo $i['advance_no']; ?>&type=<?php print_r($i['type']) ;?>&display=<?php echo $i['display']; ?>&vendor_name=<?php print_r($i['vendor']) ;?>&vendor_id=<?php print_r($i['vendor_id']) ;?>&pono=<?php print_r($i['pono']) ;?>&advance_nos=<?php print_r($i['advance_nos']) ;?>" class="btn btn-success btn-sm">Print</a></td>
       
      </tr>
		<?php
		endforeach;
		?> 
<tr>
<td colspan="5" align="right"><b>TOTAL</b>&nbsp;</td>  
<td align="right"><b>
<?php 

if($_GET['vendor'] == 'ALL')
{
	$query1 = mysql_query("SELECT SUM(payment_amount) FROM rem_order_payment");
}
else
{
	$query1 = mysql_query("SELECT SUM(payment_amount) FROM rem_order_payment WHERE payment_vendor_id='$_GET[vendor]'");
}
while($row1 = mysql_fetch_array($query1))
{
	echo $total_Amount = round($row1[0],0);
}
	

 
?></b></td>
<td align="right" colspan="3"></td>
</tr>
 
    </tbody>
  </table>
</div>
</body>
</html>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
<script>
//paste this code under the head tag or in a separate js file.
	// Wait for window load
	$(window).load(function() {
		// Animate loader off screen
		$(".se-pre-con").fadeOut("slow");;
	});
	</script>
    <script>
    function priceSorter(a, b) {
        a = +a.substring(1); // remove $
        b = +b.substring(1);
        if (a > b) return 1;
        if (a < b) return -1;
        return 0;
    }
</script>
 <script>
(function(document) {
    'use strict';

    var LightTableFilter = (function(Arr) {

          var _input;

          function _onInputEvent(e) {
              _input = e.target;
              var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
				});
			});
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
		};
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			LightTableFilter.init();
		}
	});

})(document);
</script>

<script>
$.tablesorter.addParser({ 
    id: 'price', 
    is: function(s) { 
        return false; 
    }, 
    format: function(s) { 
        return s.replace(/Free/,0).replace(/ CHF/,""); 
    }, 
    type: 'numeric' 
}); 

$(function() { 
    $("table").tablesorter({ 
        headers: { 
            1: { 
                sorter:'price' 
            } 
        } 
    }); 
});
</script>