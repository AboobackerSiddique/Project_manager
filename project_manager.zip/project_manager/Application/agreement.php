<?php 
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
include("header.php");
if(isset($_SESSION['user_name']))
{
$header_id=$_GET['header_id'];
$agreement = mysql_query("SELECT b.name,c.name,d.name,a.area,a.lessor_rep_name,a.lessee_rep_name,a.property_address,a.scheduled_premises,a.nature_of_trade,a.brand_name,a.rent_amount,a.security_deposit,e.name,a.lease_start_date,a.lease_end_date,f.name,a.escalation_percentage,g.name,a.escalation_start_date,a.car_parking_space,a.lessor_scope_of_work,a.lessee_scope_of_work,h.name,a.rent_commences,a.power,a.generator_backup,a.water_sump,a.overhead_tank,a.building_taxes_by,i.name,j.name,j.label_1,j.label_2,k.name,a.lessor_rep_age,a.lessor_rep_mobile,a.lessor_rep_address,l.name,a.lessee_rep_age,a.lessee_rep_mobile,a.lessee_rep_address FROM rem_agreement a LEFT JOIN countries b ON a.country=b.id LEFT JOIN states c ON a.state=c.id LEFT JOIN cities d ON a.cities=d.id LEFT JOIN month e ON a.lease_term=e.id LEFT JOIN month f ON a.lock_in_period=f.id  LEFT JOIN month g ON a.escalation_every_month=g.id LEFT JOIN month h ON a.grace_period=h.id LEFT JOIN locations i ON a.location=i.id LEFT JOIN rem_categories j ON a.category=j.id LEFT JOIN titles k ON a.lessor_rep_title=k.id LEFT JOIN titles l ON a.lessee_rep_title=l.id WHERE header_id='$header_id'");
	while($row = mysql_fetch_array($agreement))
	{
		$country=$row[0];
		$state=$row[1];
		$cities=$row[2];
		$area=$row[3];
		$lessors=$row[4];
		$lessee=$row[5];
		$address=$row[6];
		$scheduled_premises=$row[7];
		$nature_of_trade=$row[8];
		$brand_name=$row[9];
		$rent_amount=$row[10];
		$security_deposit=$row[11];
		$lease_term=$row[12];
		$lease_start_date=$row[13];
		$lease_end_date=$row[14];
		$lock_in_period=$row[15];
		$escalation_percentage=$row[16];
		$escalation_every_month=$row[17];
		$escalation_start_date=$row[18];
		$car_parking_space=$row[19];
		$lessor_scope_of_work=$row[20];
		$lessee_scope_of_work=$row[21];
		$grace_period=$row[22];
		$rent_commences=$row[23];
		$power=$row[24];
		$generator_backup=$row[25];
		$water_sump=$row[26];
		$overhead_tank=$row[27];
		$building_taxes_by=$row[28];
		$locations=$row[29];
		$agreement_category=$row[30];
		$agreement_label1=$row[31];
		$agreement_label2=$row[32];
		$lessor_title=$row[33];
		$lessor_age=$row[34];
		$lessor_mobile=$row[35];
		$lessor_address=$row[36];
		$lessee_title=$row[37];
		$lessee_age=$row[38];
		$lessee_mobile=$row[39];
		$lessee_address=$row[40];
	}
?>
   
<div id="wrapper">
            <div id="layout-static">
              <div class="static-content-wrapper">
                  <div class="static-content">
                    <div class="page-content">
                          <ol class="breadcrumb">
                  <li class=""> <div class="btn-toolbar">
       <a class="btn btn-midnightblue" href="viewagreement.php"><i class="fa fa-fast-backward"></i> Back</a>
    </div></li>
                  



                          </ol> <form  method="post" class="form-horizontal">
                      <div class="container-fluid">
                             
  <div class="row">
	<div class="col-sm-12">
	  <div class="panel panel-midnightblue">
	    <div class="panel-heading">
				<h2>Agreement Details</h2>
			</div>
			<div class="panel-body">
				<div class="tab-content">
					<div class="tab-pane active" id="horizontal-form">
					  <div class="form-group">
							<label for="inputPassword" class="col-sm-12 control-label">
                            <div id="demo">
<table cellpadding="0" cellspacing="0" border="1" class="table table-striped table-fixed-header m0" id="example" >
<tr >
<td width="100%" align="center" bgcolor="#666666" colspan="2"><font size="3" color="#FFFFFF"><b><?php echo $agreement_category; ?></b></font></td>
</tr>
<tr>
<td width="30%" align="right"><b>Country :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $country; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>State :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $state; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>City :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $cities; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>Location :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $locations; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>Area :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $area; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>Property Address :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $address; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b><?php echo $agreement_label1; ?> :</b>&nbsp;</td>
<td width="70%" align="left">



<table cellpadding="0" cellspacing="0" border="1" class="table table-striped table-fixed-header m0" id="example" >
<tr >
<td  bgcolor="#CCCCCC" width="20%"><b><?php echo $agreement_label2; ?></b></td>
<td  bgcolor="#CCCCCC" width="35%"><b>NAME </b></td>
<td bgcolor="#CCCCCC" width="5%"><b>AGE</b></td>
<td bgcolor="#CCCCCC" width="13%" ><b>MOBILE NO</b></td>
<td bgcolor="#CCCCCC" width="27%" ><b>ADDRESS</b></td>
</tr>
<tr >
<td  width="20%"><b>Represented Person</b></td>
<td  width="35%"><?php if($lessee_title == '0') { echo "<b>Company:</b> ".$lessors; } else { echo $lessor_title.".&nbsp;".$lessors; }?> </td>
<td width="5%"><?php echo $lessor_age; ?></td>
<td width="13%" ><?php echo $lessor_mobile; ?></td>
<td  width="27%" ><?php echo $lessor_address; ?></td>
</tr>
<?php
$escalation = mysql_query("SELECT b.name,a.lessor_name,a.age,a.mobile,a.address FROM rem_lessor_details a LEFT JOIN titles b ON a.lessor_title=b.id  WHERE a.header_id='$header_id'");
$counter=0;
while($row_lessor = mysql_fetch_array($escalation))
{?>
<tr>
<td><?php echo $agreement_label1.++$couter; ?></td>
<td><?php echo $row_lessor[0].".&nbsp;".$row_lessor[1]; ?></td>
<td><?php echo $row_lessor[2]; ?></td>
<td><?php echo $row_lessor[3]; ?></td>
<td><?php echo $row_lessor[4]; ?></td>
</tr>
<?php } ?>
</table>



</td>
</tr>
<tr>
<td width="30%" align="right"><b><?php echo $agreement_label2; ?>:</b>&nbsp;</td>
<td width="70%" align="left"><table cellpadding="0" cellspacing="0" border="1" class="table table-striped table-fixed-header m0" id="example" >
<tr >
<td  bgcolor="#CCCCCC" width="20%"><b><?php echo $agreement_label2; ?></b></td>
<td  bgcolor="#CCCCCC" width="35%"><b>NAME </b></td>
<td bgcolor="#CCCCCC" width="5%"><b>AGE</b></td>
<td bgcolor="#CCCCCC" width="13%" ><b>MOBILE NO</b></td>
<td bgcolor="#CCCCCC" width="27%" ><b>ADDRESS</b></td>
</tr>
<tr >
<td  width="20%"><b>Represented Person</b></td>
<td  width="35%"><?php if($lessee_title == '0') { echo "<b>Company:</b> ".$lessors; } else { echo $lessee_title.".&nbsp;".$lessors; }?> </td>
<td width="5%"><?php echo $lessee_age; ?></td>
<td width="13%" ><?php echo $lessee_mobile; ?></td>
<td  width="27%" ><?php echo $lessee_address; ?></td>
</tr>
<?php
$escalation = mysql_query("SELECT b.name,a.lessee_name,a.age,a.mobile,a.address FROM rem_lessee_details a LEFT JOIN titles b ON a.lessee_title=b.id  WHERE a.header_id='$header_id'");
$counter1=0;
while($row_lessee = mysql_fetch_array($escalation))
{?>
<tr>
<td><?php echo $agreement_label2.++$couter1; ?></td>
<td><?php echo $row_lessee[0].".&nbsp;".$row_lessee[1]; ?></td>
<td><?php echo $row_lessee[2]; ?></td>
<td><?php echo $row_lessee[3]; ?></td>
<td><?php echo $row_lessee[4]; ?></td>
</tr>
<?php } ?>
</table></td>
</tr>

<tr>
<td width="30%" align="right"><b>Scheduled Premises :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $scheduled_premises; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>Nature of Trade :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $nature_of_trade; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>Brand Name  :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $brand_name; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>Rent :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $rent_amount; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>Refundable Security Deposit (Interest Free) :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $security_deposit; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>Lease Term :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $lease_term; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>Lock In Period :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $lock_in_period; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>Lease Start date :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $lease_start_date; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>Lease End date :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $lease_end_date; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>Rent Escalation Percentage :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $escalation_percentage; ?>%</td>
</tr>
<tr>
<td width="30%" align="right"><b>Rent Escalation Every :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $escalation_every_month; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>Rent Escalation Start Date :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $escalation_start_date; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>Rent Escalation Next Payment :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp;<table cellpadding="0" cellspacing="0" border="1" class="table table-striped table-fixed-header m0" id="example" >
<tr >
<td  bgcolor="#CCCCCC" width="30%"><b>NEXT RENT ESCLATION DATE</b></td>
<td  bgcolor="#CCCCCC" width="30%"><b>PERCENTAGE</b></td>
<td bgcolor="#CCCCCC" width="40%" align="right"><b>RENT ESCLATION AMOUNT</b></td>
</tr>
<?php
$escalation = mysql_query("SELECT esc_date,esc_percentage,esc_amount FROM rem_escalation  WHERE esc_header_id='$header_id'");
while($row_escalation = mysql_fetch_array($escalation))
{?>
<tr>
<td width="30%"><?php echo date("d-m-Y", strtotime($row_escalation[0])); ?></td>
<td width="30%"><?php echo $row_escalation[1]; ?>%</td>
<td width="40%" align="right"><?php echo $row_escalation[2]; ?></td>
</tr>
<?php } ?>
</table></td>
</tr>
<tr>
<td width="30%" align="right"><b>Car Parking Space :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $car_parking_space; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>Lessor scope of Work :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $lessor_scope_of_work; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>Lessee Scope of Work :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $lessee_scope_of_work; ?></td>
</tr><tr>
<td width="30%" align="right"><b>Grace Period :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $grace_period; ?></td>
</tr><tr>
<td width="30%" align="right"><b>Rent commences :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $rent_commences; ?></td>
</tr><tr>
<td width="30%" align="right"><b>Power :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $power; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>Genrator back up:</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $generator_backup; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>Water Sump :</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $water_sump; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>Overhead tank:</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $overhead_tank; ?></td>
</tr>
<tr>
<td width="30%" align="right"><b>Building taxes by:</b>&nbsp;</td>
<td width="70%" align="left">&nbsp; <?php echo $building_taxes_by; ?></td>
</tr>

<tr>
<td width="30%" align="right"><b>Ownership Proof:</b>&nbsp;</td>
<td width="70%" align="left">&nbsp;
<?php  
$proofs = mysql_query("SELECT b.name FROM rem_owners_proof a LEFT JOIN rem_proofs b ON a.proof=b.id  WHERE a.proof_header_id='$header_id'");
	while($row_proof = mysql_fetch_array($proofs))
	{
		echo $row_proof[0].", ";
	} ?></td>
</tr>

</table>
</div>


<br/>
<div id="demo">
<table cellpadding="0" cellspacing="0" border="1" class="table table-striped table-fixed-header m0" id="example" >
<tr >
<td  bgcolor="#CCCCCC" width="30%"><b>Document Name</b></td>
<td  bgcolor="#CCCCCC" width="70%"><b>Download</b></td>

</tr>
<?php
$escalation = mysql_query("SELECT upload_file FROM rem_proof_uploaded  WHERE upload_header_id='$header_id'");
while($row_escalation = mysql_fetch_array($escalation))
{?>
<tr>
<td width="30%"><?php echo $row_escalation[0]; ?></td>
<td width="30%"><a href="download.php?filename=<?php echo $row_escalation[0];?>"><img src="images/quick-download-media-file-image.png" / width="120"></a></td>

</tr>
<?php } ?>
</table>
</div>
                            
                            </label>
								
						  </div>	
                          
					
                         
					</div>
					<div class="tab-pane" id="vertical-form"></div>
					<div class="tab-pane" id="bordered-row"></div>
					<div class="tab-pane" id="tabular-form"></div>
				</div>

				
              </div>
               
            
            
		</div>
                    </div>
</div>
                          </div> </form>
                            <!-- .container-fluid -->
                        </div> <!-- #page-content -->
                </div>
                    <footer role="contentinfo">
   <?php include("footer.php"); ?>
</footer>
              </div>
  </div>
</div>

<script>
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
</script>
<script>
function showstates(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayStates").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getstates.php?q="+str,true);
  xmlhttp.send();
}
</script>

<script>
function showcities(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayCities").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getcity.php?q="+str,true);
  xmlhttp.send();
}
</script>


<script>
function showrent(payment_display,rent_start,lease_term,rent,escalation_percentage,escalation_month) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayRent").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getrentdetails.php?payment_display="+payment_display+"&rent_start="+rent_start+"&lease_term="+lease_term+"&rent="+rent+"&escalation_percentage="+escalation_percentage+"&escalation_month="+escalation_month,true);
  xmlhttp.send();
}
</script>

<!-- Switcher --><!-- /Switcher -->
    <!-- Load site level scripts -->

<!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script> -->

<script src="assets/js/jquery-1.10.2.min.js"></script> 							<!-- Load jQuery -->
<script src="assets/js/jqueryui-1.9.2.min.js"></script> 							<!-- Load jQueryUI -->

<script src="assets/js/bootstrap.min.js"></script> 								<!-- Load Bootstrap -->


<script src="assets/plugins/easypiechart/jquery.easypiechart.js"></script> 		<!-- EasyPieChart-->
<script src="assets/plugins/sparklines/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
<script src="assets/plugins/jstree/dist/jstree.min.js"></script>  				<!-- jsTree -->

<script src="assets/plugins/codeprettifier/prettify.js"></script> 				<!-- Code Prettifier  -->
<script src="assets/plugins/bootstrap-switch/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->

<script src="assets/plugins/bootstrap-tabdrop/js/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->

<script src="assets/plugins/iCheck/icheck.min.js"></script>     					<!-- iCheck -->

<script src="assets/js/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->

<script src="assets/plugins/bootbox/bootbox.js"></script>							<!-- Bootbox -->

<script src="assets/plugins/simpleWeather/jquery.simpleWeather.min.js"></script> <!-- Weather plugin-->

<script src="assets/plugins/nanoScroller/js/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->

<script src="assets/plugins/jquery-mousewheel/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->

<script src="assets/js/application.js"></script>
<script src="assets/demo/demo.js"></script>
<script src="assets/demo/demo-switcher.js"></script>
<script src="assets/plugins/clockface/js/clockface.js"></script>     								<!-- Clockface -->

<script src="assets/plugins/form-colorpicker/js/bootstrap-colorpicker.min.js"></script> 			<!-- Color Picker -->

<script src="assets/plugins/bootstrap-datepicker/bootstrap-datepicker.js"></script>      			<!-- Datepicker -->
<script src="assets/plugins/bootstrap-timepicker/bootstrap-timepicker.js"></script>      			<!-- Timepicker -->
<script src="assets/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script> 	<!-- DateTime Picker -->
<script src="assets/plugins/form-daterangepicker/moment.min.js"></script>              			<!-- Moment.js for Date Range Picker -->
<script src="assets/plugins/form-daterangepicker/daterangepicker.js"></script>     				<!-- Date Range Picker -->

<script src="assets/demo/demo-pickers.js"></script>
<!-- End loading site level scripts -->
    
    <!-- Load page level scripts-->
    

    <!-- End loading page level scripts-->

</body>

<!-- Mirrored from avenger.kaijuthemes.com/ui-forms.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 24 Oct 2015 18:46:10 GMT -->
</html>
<?php }
      else
        {
	       header('Location: ../index.php');
        }
		
	?>