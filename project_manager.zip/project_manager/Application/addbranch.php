<?php 
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
include("header.php");
 if($_SESSION['user_name'])
{
	
		if(isset($_GET["branchid"]))
   		{
	  		 mysql_query("DELETE FROM lodge_branch WHERE branch_id='$_GET[branchid]'");
   		}
   
	if(isset($_POST["submit"]))
{
	

 $sql="INSERT INTO lodge_branch(branch_name,branch_mobile,branch_email,branch_address1,branch_address2,branch_gstno)
VALUES
('$_POST[name]','$_POST[contact]','$_POST[email]','$_POST[address1]','$_POST[address2]','$_POST[gstno]')";
 

       if (!mysql_query($sql,$con))
          {
            die('Error: ' . mysql_error());
          }
  
    	 	$message = 'Branch Added Successfully';
			echo "<SCRIPT type='text/javascript'> 
       	 	alert('$message');
       	 	window.location.replace(\"addbranch.php\");
    		</SCRIPT>";
   }
   
?>
   
<div id="wrapper">
            <div id="layout-static">
              <div class="static-content-wrapper">
                  <div class="static-content">
                        <div class="page-content">
                          <ol class="breadcrumb">
                                
 <li class=""> <div class="btn-toolbar">
      

<a class="btn btn-midnightblue" onClick="goBack()"><i class="fa fa-fast-backward"></i> Back</a>
<script>
function goBack() {
    window.history.back();
}
</script>
    </div></li>


                          </ol>
                            <div class="container-fluid">
                              
  <div class="row">
	<div class="col-sm-8">
	  <div class="panel panel-midnightblue">
	    <div class="panel-heading">
				<h2>Add Branch</h2>
			</div>
			<div class="panel-body">
				<div class="tab-content">
					<div class="tab-pane active" id="horizontal-form">
						<form  method="post" class="form-horizontal">
                     <?php if(isset($_GET['display']))
					 {
						 ?> <center><font color="#FF0000" size="3"><b><?php echo $_GET['display']; ?></b></font></center>
                         <?php } ?>
						  <div class="form-group">
								<label for="focusedinput" class="col-sm-2 control-label">Branch Name</label>
								<div class="col-sm-8">
									<input type="text" class="form-control" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("contact").focus();return false;}' id="name" value="<?php echo $_GET['username']; ?>" autofocus name="name" placeholder="Enter Branch Name" required>
								</div>
						  </div>
							
						  
                          <div class="form-group">
								<label for="inputPassword" class="col-sm-2 control-label">Contact No</label>
								<div class="col-sm-8">
									<input type="text" class="form-control" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("email").focus();return false;}' id="contact" value="" name="contact" placeholder="Enter Contact No" required>
								</div>
						  </div>
                            <div class="form-group">
								<label for="inputPassword" class="col-sm-2 control-label">Email</label>
								<div class="col-sm-8">
									<input type="text" class="form-control" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("address1").focus();return false;}' id="email" value="<?php echo $_GET['email']; ?>" name="email" placeholder="Enter Email Address" required>
								</div>
						  </div>
                          
                          <div class="form-group">
								<label for="inputPassword" class="col-sm-2 control-label"> Address1</label>
								<div class="col-sm-8">
									<input type="text" class="form-control" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("address2").focus();return false;}' id="address1" value="" name="address1" placeholder="Enter Address1" required>
								</div>
						  </div>
                          <div class="form-group">
								<label for="inputPassword" class="col-sm-2 control-label"> Address2</label>
								<div class="col-sm-8">
									<input type="text" class="form-control" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("gstno").focus();return false;}' id="address2" value="" name="address2" placeholder="Enter Address2" required>
								</div>
						  </div>
                          
                          <div class="form-group">
								<label for="inputPassword" class="col-sm-2 control-label">GST No</label>
								<div class="col-sm-8">
									<input type="text" class="form-control" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("hsnno").focus();return false;}' id="gstno" value="" name="gstno" placeholder="Enter GST No" required>
								</div>
						  </div>
                          <div class="tab-pane" id="vertical-form"></div>
					<div class="tab-pane" id="bordered-row"></div>
					<div class="tab-pane" id="tabular-form"></div>
					
					<div class="row">
						<div class="col-sm-8 col-sm-offset-2">
						  <button type="submit" class="btn btn-info"  name="submit" id="submit">ADD Branch</button>
                            </form>
					
					</div>
                   
				</div>
         
			</div>
		</div>
        
	</div>
</div>
                          </div> 
                            <!-- .container-fluid -->
                        </div> <!-- #page-content -->
                </div>
                <div class="container-fluid">
                              <div class="row">
                                <div class="col-md-12">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h2>View Added Branches </h2>
				<div class="panel-ctrls">
				</div>
			</div>
			<div class="panel-body panel-no-padding">
				<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
					<thead>
						<tr>
                            <th >SL No</th>
                            <th >Name</th>
                            <th>Mobile</th>
                            <th >Email</th>
                            <th >Address1</th>
                            <th >Address2</th>
                             <th >GST NO</th>
                               <th >Edit</th>
                                  <th >Del</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $result = mysql_query("SELECT branch_id,branch_name,branch_mobile,branch_email,branch_address1,branch_address2,branch_gstno FROM lodge_branch");
$counter=0;					
while($row = mysql_fetch_array($result))
  {?>
                        <tr class="odd gradeX">
                           
                            <td><?php echo ++$counter; ?></td>
                            <td><?php echo $row[1]; ?></td>
                           <td><?php echo $row[2]; ?></td>
                            <td><?php echo $row[3]; ?></td>
                             <td><?php echo $row[4]; ?></td>
                              <td><?php echo $row[5]; ?></td>
                               <td><?php echo $row[6]; ?></td>
                               
                               
                                <td><a href="updatebranch.php?branchid=<?php echo $row[0]; ?>"><img src="images/edit.png" width="22" height="24"></a></U></td> 
                          <td><a href="javascript:confirmDelete('addbranch.php?branchid=<?php echo $row[0]; ?>')"><img src="images/074073-rounded-glossy-black-icon-alphanumeric-circled-x3.png" width="22" height="25"></a></U></td>
                      <?php } ?>
						
				  </tbody>
				</table>
				<div class="panel-footer"></div>
			</div>
		</div>
	</div>
</div>

                          </div>
                    <footer role="contentinfo">
   <?php include("footer.php"); ?>
</footer>
<script>
function confirmDelete(delUrl) {
  if (confirm("Are you sure you want to delete")) {
    document.location = delUrl;
  }
}
</script>
<!-- Switcher --><!-- /Switcher -->
    <!-- Load site level scripts -->

<!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script> -->

<script src="assets/js/jquery-1.10.2.min.js"></script> 							<!-- Load jQuery -->
<script src="assets/js/jqueryui-1.9.2.min.js"></script> 							<!-- Load jQueryUI -->

<script src="assets/js/bootstrap.min.js"></script> 								<!-- Load Bootstrap -->


<script src="assets/plugins/easypiechart/jquery.easypiechart.js"></script> 		<!-- EasyPieChart-->
<script src="assets/plugins/sparklines/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
<script src="assets/plugins/jstree/dist/jstree.min.js"></script>  				<!-- jsTree -->

<script src="assets/plugins/codeprettifier/prettify.js"></script> 				<!-- Code Prettifier  -->
<script src="assets/plugins/bootstrap-switch/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->

<script src="assets/plugins/bootstrap-tabdrop/js/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->

<script src="assets/plugins/iCheck/icheck.min.js"></script>     					<!-- iCheck -->

<script src="assets/js/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->

<script src="assets/plugins/bootbox/bootbox.js"></script>							<!-- Bootbox -->

<script src="assets/plugins/simpleWeather/jquery.simpleWeather.min.js"></script> <!-- Weather plugin-->

<script src="assets/plugins/nanoScroller/js/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->

<script src="assets/plugins/jquery-mousewheel/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->

<script src="assets/js/application.js"></script>
<script src="assets/demo/demo.js"></script>
<script src="assets/demo/demo-switcher.js"></script>

<!-- End loading site level scripts -->
    
    <!-- Load page level scripts-->
    
    
<script src="assets/plugins/datatables/jquery.dataTables.js"></script>
<script src="assets/plugins/datatables/dataTables.bootstrap.js"></script>
<script src="assets/demo/demo-datatables.js"></script>
    <!-- End loading page level scripts-->

</body>

<!-- Mirrored from avenger.kaijuthemes.com/ui-forms.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 24 Oct 2015 18:46:10 GMT -->
</html>
<?php }
      else
        {
	       header('Location: ../index.php');
        }
		
	?>