<?php 
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
include("header.php");
 if($_SESSION['user_name'])
{
	if(isset($_GET["contractor_id"]))
   	{
	    mysql_query("DELETE FROM rem_contractor WHERE contractor_id= '$_GET[contractor_id]'");
   	}
   
if(isset($_POST["submit"]))
{
	$result9 = mysql_query("SELECT contractor_name FROM rem_contractor where contractor_name='$_POST[name]'");
	while($row9 = mysql_fetch_array($result9))
  	{
 		$username= $row9[0];
	}
	
	
if ($_POST['name'] == $username ) 
{

 $message = 'Contractor Already Exist';

    echo "<SCRIPT type='text/javascript'> 
        alert('$message');
        window.location.replace(\"addcontractor.php\");
    </SCRIPT>"; 
}
else
{
	
 $sql="INSERT INTO rem_contractor(contractor_name,contractor_description)
VALUES
('$_POST[name]','$_POST[address]')";
 

       if (!mysql_query($sql,$con))
          {
            die('Error: ' . mysql_error());
          }
  }
     $message = 'Contractor Created Successfully';

    echo "<SCRIPT type='text/javascript'> 
        alert('$message');
        window.location.replace(\"addcontractor.php\");
    </SCRIPT>";
   }
?>
   
<div id="wrapper">
            <div id="layout-static">
              <div class="static-content-wrapper">
                  <div class="static-content">
                        <div class="page-content">
                          <ol class="breadcrumb">
                                
 <li class=""> <div class="btn-toolbar">
       <a class="btn btn-midnightblue" href="index.php"><i class="fa fa-fast-backward"></i> Back</a>
    </div></li>


                          </ol>
                            <div class="container-fluid">
                              
  <div class="row">
	<div class="col-sm-7">
	  <div class="panel panel-midnightblue">
	    <div class="panel-heading">
				<h2>Contractor  Master</h2>
			</div>
			<div class="panel-body">
				<div class="tab-content">
					<div class="tab-pane active" id="horizontal-form">
						<form  method="post" class="form-horizontal">
                     <?php if(isset($_GET['display']))
					 {
						 ?> <center><font color="#FF0000" size="3"><b><?php echo $_GET['display']; ?></b></font></center>
                         <?php } ?>
						  <div class="form-group">
								<label for="inputPassword" class="col-sm-2 control-label">Contractor Name</label>
							  <div class="col-sm-8">
								  <input type="text" class="form-control" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("address").focus();return false;}' id="name" value="" name="name" placeholder="Enter Contractor Name" required>
						   </div>
						  </div>
						  <div class="form-group">
						    <label for="focusedinput" class="col-sm-2 control-label">Description</label>
							<div class="col-sm-8">
								  <textarea class="form-control" name="address" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("submit").focus();return false;}' id="address" required placeholder="Enter Description"></textarea>
								</div>
						  </div>
						  </div>
					<div class="tab-pane" id="vertical-form"></div>
					</div>
                    
                      <div class="form-group">
								<label for="focusedinput" class="col-sm-2 control-label"></label>
								<div class="col-sm-8">
									<button type="submit" class="btn btn-info"  style="background-color:#F93;"  name="submit" id="submit">Create Contractor</button>
								</div>
						  </div>
  
                            </form>
				
         
			</div>
		</div>
        
	</div>
</div>


                              <div class="row">
                                <div class="col-md-7">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h2>Displaying Added Contractor Details</h2>
				<div class="panel-ctrls">
				</div>
			</div>
			<div class="panel-body panel-no-padding">
				<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
					<thead>
						<tr>
                            <th >S No</th>
                            <th >Contractor Name</th>
                            <th >Description</th>
                            
                             <?php if($_SESSION["user_type"] == 'Super Admin'){?>     
                             <th >Action</th>
							 <?php } ?>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
					
						$result = mysql_query("SELECT contractor_id,contractor_name,contractor_description FROM rem_contractor");
					$counter = 0;
while($row = mysql_fetch_array($result))
  {?>
                        <tr class="odd gradeX">
                            <td><?php echo ++$counter; ?></td>
                            <td><b><?php echo $row[1]; ?></b></td>
                            <td><?php echo $row[2]; ?></td>
                     		                         
                           <?php if($_SESSION["user_type"] == 'Super Admin'){?>
                          
                            <td>&nbsp;&nbsp;&nbsp;<a href="updatecontractor.php?contractor_id=<?php echo $row[0]; ?>"><img src="images/edit.png" width="24" height="25"></a>&nbsp;&nbsp;&nbsp;<a href="javascript:confirmDelete('addcontractor.php?contractor_id=<?php echo $row[0]; ?>')"><img src="images/error.png" width="30" height="25"></a></td><?php } ?>
                        </tr>
                      <?php } ?>
						  
				  </tbody>
				</table>
                
				<div class="panel-footer"></div>
			</div>
		</div>
	</div>
</div>

                         
                          </div> 
                            <!-- .container-fluid -->
                        </div> <!-- #page-content -->
                </div>
                    <footer role="contentinfo">
   <?php include("footer.php"); ?>
</footer>
              </div>
  </div>
</div>
<script>
function showstates(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayStates").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getstates.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showtesting(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayTesting").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettesting.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showcategory(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayCategory").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getcategory.php?q="+str,true);
  xmlhttp.send();
}
</script>


<script>
function showcities(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayCities").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getcity.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showlocations(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayLocation").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getlocations.php?q="+str,true);
  xmlhttp.send();
}
</script>

<!-- Switcher --><!-- /Switcher -->
    <!-- Load site level scripts -->

<!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script> -->
<script>
function confirmDelete(delUrl) {
  if (confirm("Are you sure you want to delete")) {
    document.location = delUrl;
  }
}
</script>
<script src="assets/js/jquery-1.10.2.min.js"></script> 							<!-- Load jQuery -->
<script src="assets/js/jqueryui-1.9.2.min.js"></script> 							<!-- Load jQueryUI -->

<script src="assets/js/bootstrap.min.js"></script> 								<!-- Load Bootstrap -->


<script src="assets/plugins/easypiechart/jquery.easypiechart.js"></script> 		<!-- EasyPieChart-->
<script src="assets/plugins/sparklines/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
<script src="assets/plugins/jstree/dist/jstree.min.js"></script>  				<!-- jsTree -->

<script src="assets/plugins/codeprettifier/prettify.js"></script> 				<!-- Code Prettifier  -->
<script src="assets/plugins/bootstrap-switch/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->

<script src="assets/plugins/bootstrap-tabdrop/js/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->

<script src="assets/plugins/iCheck/icheck.min.js"></script>     					<!-- iCheck -->

<script src="assets/js/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->

<script src="assets/plugins/bootbox/bootbox.js"></script>							<!-- Bootbox -->

<script src="assets/plugins/simpleWeather/jquery.simpleWeather.min.js"></script> <!-- Weather plugin-->

<script src="assets/plugins/nanoScroller/js/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->

<script src="assets/plugins/jquery-mousewheel/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script src="assets/plugins/datatables/jquery.dataTables.js"></script>
<script src="assets/plugins/datatables/dataTables.bootstrap.js"></script>
<script src="assets/demo/demo-datatables.js"></script>
<script src="assets/js/application.js"></script>
<script src="assets/demo/demo.js"></script>
<script src="assets/demo/demo-switcher.js"></script>

<!-- End loading site level scripts -->
    
    <!-- Load page level scripts-->
    

    <!-- End loading page level scripts-->

</body>

<!-- Mirrored from avenger.kaijuthemes.com/ui-forms.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 24 Oct 2015 18:46:10 GMT -->
</html>
<?php }
      else
        {
	       header('Location: ../index.php');
        }
		
	?>