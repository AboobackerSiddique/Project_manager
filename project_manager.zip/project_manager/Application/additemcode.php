<?php  
session_start();
ob_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");

date_default_timezone_set('Asia/Calcutta');
$current_date = date("Y-m-d");
if(isset($_POST["submit"]))
{
	
		$checkbox1 = $_POST['chk1'];
		$checkbox2 = $_POST['chk2'];
		$checkbox3 = $_POST['chk3'];
		$checkbox4 = $_POST['chk4'];
		
		for ($i=0; $i<sizeof($checkbox1); $i++)
		{
		for ($i=0; $i<sizeof($checkbox2); $i++)
		{
		for ($i=0; $i<sizeof($checkbox3); $i++)
		{
		for ($i=0; $i<sizeof($checkbox4); $i++)
		{
			mysql_query("UPDATE rem_item SET item_code='".$checkbox2[$i]."',item_tax='".$checkbox3[$i]."',item_movable='".$checkbox4[$i]."' WHERE item_id='".$checkbox1[$i]."'");
		}
		}
		}
		}
}
	
	
	
		$query=mysql_query("SELECT a.item_id itemid,a.item_name itemname,b.cat_name itemcategory,a.item_code itemcode,a.item_tax tax,a.item_movable movable FROM rem_item a LEFT JOIN rem_vendor_category b ON a.item_category=b.cat_id ORDER BY a.item_category");

	while($row_item = mysql_fetch_assoc($query))
		{
			$details_item[] = $row_item;
		}
		
		
		



?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Project Manager</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <style>
/* Paste this css to your style sheet file or under head tag */
/* This only works with JavaScript, 
if it's not present, don't show loader */
.no-js #loader { display: none;  }
.js #loader { display: block; position: absolute; left: 100px; top: 0; }
.se-pre-con {
	position: fixed;
	left: 0px;
	top: 0px;
	width: 100%;
	height: 100%;
	z-index: 9999;
	background: url(images/pageLoader.gif) center no-repeat #fff;
}
</style>
</head>
<body>
<div class="se-pre-con"></div>
<br/>
<div class="container">
 <a class="btn btn-primary btn-sm" href="additem.php" role="button"><i class="fa fa-fast-backward"></i>&nbsp;Back</a> <h2>Update Item Code</h2>
  
  <div >          <p align="right"><font color="#000000">Search  : &nbsp;</font><input type="search" class="light-table-filter" data-table="table-bordered" placeholder="Filter"></p>    </div><br/>
    <form method="post">       
  <table class="table table-bordered" id="table"
               data-toggle="table"
               data-height="460"
               data-sort-name="price"
               data-sort-order="desc">
    <thead>
      <tr>
        <th style="col-md-2">SL No</th>
        <th style="col-md-4" >Item Category</th>
        <th style="col-md-5" >Item Name</th>
        <th style="col-md-2" >Update Code</th>
        <th style="col-md-2" >Update Tax</th> 
        <th style="col-md-2" >Movable/Immovable</th>      
      </tr>
    </thead>
    <tbody>
    <?php				
	$counter=0;
	foreach($details_item as $i):
	?>
      <tr>
        <td><?php echo ++$counter; ?></td>
        <td align="center"><?php print_r($i['itemcategory']); ?></td>
         <td align="left"><?php print_r($i['itemname']); ?></td>
         <td align="center"><input type="hidden" class="form-control"  id="chk1[]" value="<?php print_r($i['itemid']); ?>" name="chk1[]" placeholder="Item Code" >
         <input type="text" class="form-control"  id="chk2[]" value="<?php print_r($i['itemcode']); ?>" autocomplete="off" name="chk2[]" placeholder="Item Code" ></td>
       
     <td width="15%">      <?php
         $units = mysql_query("SELECT tax_id,tax_primary FROM rem_tax_master WHERE tax_id!='$i[tax]'");
		 ?>
		<select   class="form-control"  name="chk3[]" id="chk3[]" onkeydown='if(event.keyCode == 13){document.getElementById("specification").focus();return false;}'>
         <?php
		 if($i['tax'] == 0)
		 {?>
         <option value="">Choose Tax%</option>
		<?php  }
		 else
		 {
         $units1 = mysql_query("SELECT tax_id,tax_primary FROM rem_tax_master WHERE tax_id='$i[tax]'");
         while($row_units1 = mysql_fetch_array($units1))
		{?>
        <option value="<?php echo $row_units1[0]; ?>"><?php echo round($row_units1[1],0)."%"; }?></option>
        <?php } ?>
			<?php 
   		while($row_units = mysql_fetch_array($units))
		{
		?>
		<option value="<?php echo $row_units[0]; ?>"><?php echo round($row_units[1],0)."%"; }?></option>
      
       </select></td>  
       <td>  
		<select   class="form-control"  name="chk4[]" id="chk4[]" onkeydown='if(event.keyCode == 13){document.getElementById("specification").focus();return false;}'>
         <?php
		 if($i['movable'] == 0)
		 {?>
        <option value="0">MOVABLE</option>
        <option value="1">IMMOVABLE</option>
		<?php  }
		 else
		 {?>
        <option value="1">IMMOVABLE</option>
        <option value="0">MOVABLE</option>
              
		<?php } ?>
      
       </select></td>
      </tr>
		<?php
		endforeach;
		?> 

 
    </tbody>
  </table>
  
  <center>	<button type="submit" class="btn btn-info"  style="background-color:#F93;"  name="submit" id="submit">Update Item Code</button><br/><br/></center>
  
  </form>
</div>
</body>
</html>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
<script>
//paste this code under the head tag or in a separate js file.
	// Wait for window load
	$(window).load(function() {
		// Animate loader off screen
		$(".se-pre-con").fadeOut("slow");;
	});
	</script>
    <script>
    function priceSorter(a, b) {
        a = +a.substring(1); // remove $
        b = +b.substring(1);
        if (a > b) return 1;
        if (a < b) return -1;
        return 0;
    }
</script>
 <script>
(function(document) {
    'use strict';

    var LightTableFilter = (function(Arr) {

          var _input;

          function _onInputEvent(e) {
              _input = e.target;
              var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
			Arr.forEach.call(tables, function(table) {
				Arr.forEach.call(table.tBodies, function(tbody) {
					Arr.forEach.call(tbody.rows, _filter);
				});
			});
		}

		function _filter(row) {
			var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
			row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';
		}

		return {
			init: function() {
				var inputs = document.getElementsByClassName('light-table-filter');
				Arr.forEach.call(inputs, function(input) {
					input.oninput = _onInputEvent;
				});
			}
		};
	})(Array.prototype);

	document.addEventListener('readystatechange', function() {
		if (document.readyState === 'complete') {
			LightTableFilter.init();
		}
	});

})(document);
</script>

<script>
$.tablesorter.addParser({ 
    id: 'price', 
    is: function(s) { 
        return false; 
    }, 
    format: function(s) { 
        return s.replace(/Free/,0).replace(/ CHF/,""); 
    }, 
    type: 'numeric' 
}); 

$(function() { 
    $("table").tablesorter({ 
        headers: { 
            1: { 
                sorter:'price' 
            } 
        } 
    }); 
});
</script>