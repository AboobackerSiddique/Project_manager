<?php 
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
include("header.php");
 if($_SESSION['user_name'])
{
	
   
if(isset($_POST["submit"]))
{
	$result9 = mysql_query("SELECT cuisine_name FROM rem_cuisine_master where cuisine_name='$_POST[name]'");
	while($row9 = mysql_fetch_array($result9))
  	{
 		$name= $row9[0];
	}
	
	
if ($_POST['name'] == $name ) 
{

 $message = 'Cuisine Already Exist';

    echo "<SCRIPT type='text/javascript'> 
        alert('$message');
        window.location.replace(\"addcuisine.php\");
    </SCRIPT>"; 
}
else
{
	
 $sql="INSERT INTO rem_cuisine_master(cuisine_name)
VALUES
('$_POST[name]')";
 

       if (!mysql_query($sql,$con))
          {
            die('Error: ' . mysql_error());
          }
  }
     
   }
   
?>
   
<div id="wrapper">
            <div id="layout-static">
              <div class="static-content-wrapper">
                  <div class="static-content">
                        <div class="page-content">
                          <ol class="breadcrumb">
                                
 <li class=""> <div class="btn-toolbar">
       <a class="btn btn-midnightblue" href="assigncounter.php?outlet=1"><i class="fa fa-fast-backward"></i> Back</a>
    </div></li>


                          </ol>
                            <div class="container-fluid">
                              
  <div class="row">
	<div class="col-sm-8">
	  <div class="panel panel-midnightblue">
	    <div class="panel-heading">
				<h2>Add Cuisine Master</h2>
			</div>
			<div class="panel-body">
				<div class="tab-content">
					<div class="tab-pane active" id="horizontal-form">
						<form  method="post" class="form-horizontal">
                    
						  <div class="form-group">
								<label for="focusedinput" class="col-sm-2 control-label">Cuisine Name</label>
								<div class="col-sm-8">
									<input type="text" class="form-control" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("submit").focus();return false;}' id="name" value="" autofocus name="name" autocomplete="off" placeholder="Enter Cuisine Name" required>
								</div>
						  </div>
							
						  
						  </div>
					<div class="tab-pane" id="vertical-form"></div>
					<div class="tab-pane" id="bordered-row"></div>
					<div class="tab-pane" id="tabular-form"></div>
				</div>

				<div class="panel-footer">
					<div class="row">
						<div class="col-sm-8 col-sm-offset-2">
						  <button type="submit" class="btn btn-info"  name="submit" id="submit">ADD Cuisine</button>
                            </form>
						</div>
                          
					</div>
                   
				</div>
         
			</div>
		</div>
        
	</div>
</div>
                          </div> 
                            <!-- .container-fluid -->
                        </div> <!-- #page-content -->
                </div>
                
                
                
                     <div class="container-fluid">
                              <div class="row">
                                <div class="col-md-9">
		<div class="panel panel-default">
			<div class="panel-heading">
				<h2>Displaying Added Cuisine Master</h2>
				<div class="panel-ctrls">
				</div>
			</div>
			<div class="panel-body panel-no-padding">
				<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
					<thead>
						<tr>
                            <th >S No</th>
                            <th >Cuisine Name</th>
                         
                           
                             <th >Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
					
						$result = mysql_query("SELECT cuisine_id,cuisine_name FROM rem_cuisine_master WHERE cuisine_type='0'");
					$counter = 0;
while($row = mysql_fetch_array($result))
  {?>
                        <tr class="odd gradeX">
                            <td><?php echo ++$counter; ?></td>
                            <td><b><?php echo $row[1]; ?></b></td>
                        
                           
                         
                            <td>&nbsp;&nbsp;&nbsp;<a href="updatecuisine.php?id=<?php echo $row[0]; ?>&name=<?php echo $row[1]; ?>"><img src="images/edit.png" width="24" height="25"></a></td>
                        </tr>
                      <?php } ?>
						  
				  </tbody>
				</table>
				<div class="panel-footer"></div>
			</div>
		</div>
	</div>
</div>

                          </div> 
                    <footer role="contentinfo">
   <?php include("footer.php"); ?>
</footer>
              </div>
  </div>
</div>
<script>
function confirmDelete(delUrl) {
  if (confirm("Are you sure you want to delete")) {
    document.location = delUrl;
  }
}
</script>
<!-- Switcher --><!-- /Switcher -->
    <!-- Load site level scripts -->

<!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script> -->

<script src="assets/js/jquery-1.10.2.min.js"></script> 							<!-- Load jQuery -->
<script src="assets/js/jqueryui-1.9.2.min.js"></script> 							<!-- Load jQueryUI -->

<script src="assets/js/bootstrap.min.js"></script> 								<!-- Load Bootstrap -->


<script src="assets/plugins/easypiechart/jquery.easypiechart.js"></script> 		<!-- EasyPieChart-->
<script src="assets/plugins/sparklines/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
<script src="assets/plugins/jstree/dist/jstree.min.js"></script>  				<!-- jsTree -->

<script src="assets/plugins/codeprettifier/prettify.js"></script> 				<!-- Code Prettifier  -->
<script src="assets/plugins/bootstrap-switch/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->

<script src="assets/plugins/bootstrap-tabdrop/js/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->

<script src="assets/plugins/iCheck/icheck.min.js"></script>     					<!-- iCheck -->

<script src="assets/js/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->

<script src="assets/plugins/bootbox/bootbox.js"></script>							<!-- Bootbox -->

<script src="assets/plugins/simpleWeather/jquery.simpleWeather.min.js"></script> <!-- Weather plugin-->

<script src="assets/plugins/nanoScroller/js/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->

<script src="assets/plugins/jquery-mousewheel/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->

<script src="assets/js/application.js"></script>
<script src="assets/demo/demo.js"></script>
<script src="assets/demo/demo-switcher.js"></script>

<!-- End loading site level scripts -->
    
    <!-- Load page level scripts-->
    

    <!-- End loading page level scripts-->

</body>

<!-- Mirrored from avenger.kaijuthemes.com/ui-forms.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 24 Oct 2015 18:46:10 GMT -->
</html>
<?php }
      else
        {
	       header('Location: ../index.php');
        }
		
	?>