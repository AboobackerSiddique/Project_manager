<?php 
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
include("header.php");
$counter_id=$_GET['header_id'];
 if($_SESSION['user_name'])
{

$counter_details = mysql_query("SELECT merchant_name,merchant_description,merchant_type FROM rem_merchant_temp WHERE merchant_header_id='$counter_id'");
	while($row_counter = mysql_fetch_array($counter_details))
	{
		$merchant_name = $row_counter[0];
		$merchant_description = $row_counter[1];
		$merchant_type = $row_counter[2];
	}

if(isset($_GET['delete_id']))
{
	mysql_query("DELETE FROM rem_merchant_item_master WHERE assign_id='$_GET[delete_id]'");
}
	
	if(isset($_POST["add"]))
{
	
	$find_outlets = mysql_query("SELECT merchant_name FROM rem_merchant WHERE merchant_name='$_POST[name]'");
	while($row_find_outlets = mysql_fetch_array($find_outlets))
	{
		$counter_find = $row_find_outlets[0];
	}
	
	if($counter_find)
	{
			$message = 'Merchant Name Already Exist..';
 			echo "<SCRIPT type='text/javascript'> 
        	alert('$message');
       		window.location.replace(\"addmerchant.php\");
    		</SCRIPT>"; 
	}
	else
	{
	
	$max_header_result = mysql_query("SELECT MAX(merchant_header_id) FROM rem_merchant_temp");
	while($row_id = mysql_fetch_array($max_header_result))
	{
		$max_header = $row_id[0];
	}
	
		if ($max_header == 0 )
		{
			$max_header_id = "T1";	
		}
		else
		{
			$max_header_id = $max_header;
			$max_header_id++;
		} 
		$header_id=$max_header_id;
		
		mysql_query("DELETE FROM rem_merchant_temp");
		mysql_query("DELETE FROM rem_merchant_item_master WHERE assign_process=0");
				
		$sql="INSERT INTO rem_merchant_temp(merchant_header_id,merchant_name,merchant_description,merchant_type)
		VALUES
		('$header_id','$_POST[name]','$_POST[address]','$_POST[gender]')";
 		
		if (!mysql_query($sql,$con))
        {
        	die('Error: ' . mysql_error());
        }
		header("Location: addmerchant.php?header_id=$header_id");
	}
}



if(isset($_POST["create"]))
{
	$counter_details1 = mysql_query("SELECT item_id FROM rem_item WHERE item_name='$_POST[item_id]'");
	while($row_counter1 = mysql_fetch_array($counter_details1))
	{
		$items_idd=$row_counter1[0];
	}
	
	$sql="INSERT INTO rem_merchant_item_master(assign_merchant,assign_item,assign_price,assign_qty,assign_amount)
	VALUES
	('$counter_id','$items_idd','$_POST[prices]','$_POST[qty]','$_POST[amount]')";
 		
	if (!mysql_query($sql,$con))
    {
       die('Error: ' . mysql_error());
    }	
	header("Location: addmerchant.php?header_id=$counter_id");
}

if(isset($_POST["submit"]))
{
	$max_header_result = mysql_query("SELECT MAX(merchant_id) FROM rem_merchant");
	while($row_id = mysql_fetch_array($max_header_result))
	{
		$max_header = $row_id[0];
	}
	
			
			if ($max_header == 0 )
			{
				$max_header_id = "1";	
			}
			else
			{
				$max_header_id = $max_header;
				$max_header_id++;
			} 
			$header_id=$max_header_id;
			
			$sql="INSERT INTO rem_merchant(merchant_id,merchant_name,merchant_description,merchant_type)
			VALUES
			('$header_id','$merchant_name','$merchant_description','$merchant_type')";
 		
			if (!mysql_query($sql,$con))
        	{
        		die('Error: ' . mysql_error());
        	}

          $sql2="INSERT INTO cfms_party_master(party_name,party_type_id,party_type)
      VALUES
      ('$merchant_name','$header_id','merchant')";
    
      if (!mysql_query($sql2,$con))
          {
            die('Error: ' . mysql_error());
          }
			
			mysql_query("UPDATE  rem_merchant_item_master SET assign_merchant='$header_id',assign_process='1' WHERE assign_merchant='$counter_id'");	
			
			$message = 'Merchant Added Successfully..';
 			echo "<SCRIPT type='text/javascript'> 
        	alert('$message');
       		window.location.replace(\"index.php\");
    		</SCRIPT>"; 
}

?>
   
<div id="wrapper">
            <div id="layout-static">
              <div class="static-content-wrapper">
                  <div class="static-content">
                        <div class="page-content">
                          <ol class="breadcrumb">
                                
 <li class=""> <div class="btn-toolbar">
       <a class="btn btn-midnightblue" href="index.php"><i class="fa fa-fast-backward"></i> Back</a>
       &nbsp;&nbsp;<a class="btn btn-success" href="viewmerchant.php"><i class="fa fa-pencil"></i> Edit/ View Merchant</a>
    </div></li>


                          </ol>
                            <form  method="post" class="form-horizontal">
                      <div class="container-fluid">
                             
  <div class="row">
	<div class="col-sm-12">
	  <div class="panel panel-midnightblue">
	    <div class="panel-heading">
				<h2>Merchant Master</h2>
			</div>
			<div class="panel-body">
				<div class="tab-content">
					<div class="tab-pane active" id="horizontal-form">
					  <div class="form-group">
						    <label for="selector1" class="col-sm-2 control-label">Merchant Name</label>
						<div class="col-sm-2">
                                <input type="text" <?php if(isset($_GET['header_id'])){ echo 'readonly="readonly"'; } ?> autocomplete="off" class="form-control" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("address").focus();return false;}' id="name" value="<?php echo $merchant_name; ?>" name="name" placeholder="Enter Merchant Name" required></div>
       
						  </div>
					  <div class="form-group">
						    <label for="selector1" class="col-sm-2 control-label"> Description</label>
							<div class="col-sm-2">
                              <textarea  class="form-control" <?php if(isset($_GET['header_id'])){ echo 'readonly="readonly"'; } ?> name="address" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("add").focus();return false;}' id="address" required placeholder="Enter Description"><?php echo $merchant_description; ?></textarea><br/>
       <?php if(isset($_GET['header_id']))
					{
					}
					else
					{?> 
        <input type="radio" name="gender" id="gender" value="0" required="required" style="height:18px; width:18px;" checked="checked" >
                          <b>Consider as a Merchant</b><br/>
                           <input type="radio" required="required" name="gender" id="gender" value="1" style="height:18px; width:18px;" >
                          <b>Consider as a Outlet </b> <?php } ?></div>
       <?php if(!isset($_GET['header_id']))
	   {?>
       <div class="col-sm-2">
         <button type="submit" class="btn btn-success"  name="add" id="add">Click to Assign Item</button>
       </div>
       <?php } ?>
						  </div>
                    </div>
                   <?php if(isset($_GET['header_id']))
					{?>  
                    <div class="form-group">
						<label for="selector1" class="col-sm-2 control-label">Choose Item</label>
						<div class="col-sm-10">
                        <table cellpadding="0"  width="30%" cellspacing="0" border="1" class="table table-striped table-fixed-header m0"  >
                        <tr style="color:#FFF;" >
                        <td bgcolor="#999999" width="20%">Choose Category</td>
                        <td bgcolor="#999999" width="20%">Choose Item</td>
                        <td bgcolor="#999999" width="15%">Prices</td>
                        <td bgcolor="#999999" width="15%">Qty</td>
                        <td bgcolor="#999999" width="15%">Amount</td>
                        <td bgcolor="#999999" width="10%">ADD</td>
                        </tr>
                        <tr>
                        <td >
                       	<?php
         				$category = mysql_query("SELECT cat_id,cat_name FROM rem_vendor_category");
		 				?>
						<select class="form-control" onchange="showcategory(this.value)"  name="category" id="category"  onkeydown='if(event.keyCode == 13){document.getElementById("item_id").focus();return false;}'>
         				<option value="">Choose Category</option>
         				<?php 
   						while($row_category  = mysql_fetch_array($category ))
						{
						?>
						<option value="<?php echo $row_category[0]; ?>"><?php echo $row_category[1]; }?></option>
      					</select>
                       </td>
                       <td >
                       	<div id="displayCategory">
						
						<select class="form-control" onchange="showvendorprice(this.value)" name="item_id" id="item_id"  onkeydown='if(event.keyCode == 13){document.getElementById("vendor").focus();return false;}'>
         				<option value="">Choose Item</option>
         				<?php 
   						while($row_item  = mysql_fetch_array($item ))
						{
						?>
						<option value="<?php echo $row_item[0]; ?>"><?php echo $row_item[1]; }?></option>
      					</select>
                        </div>
                       </td>
                       
                        <td >
                        	<div id="displayPrices">
						
						<select class="form-control" name="prices" id="prices"  onkeydown='if(event.keyCode == 13){document.getElementById("qty").focus();return false;}'>
         				<option value="">Price</option>
         				</select>
                        </div>
      					</td>
                         <td >
                         <input type="text"  onkeyup="showamount(this.value,prices.value)" class="form-control" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("amount").focus();return false;}' id="qty" value="0" name="qty" placeholder="Qty" >
      					</td>
                         <td >
                         <div id="displayAmount">
                         <input type="text"  class="form-control" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("create").focus();return false;}' id="amount" value="" name="amount" placeholder="Amount" >
       					</div>
      					</td>
                        <td >
                         <button type="submit" class="btn btn-info"  name="create" id="create">ADD</button>
                         </td>
                        </tr>
                        </table>
                         <?php
         				$counter_items_list= mysql_query("SELECT a.assign_id,b.merchant_name,c.item_name,a.assign_price,a.assign_qty,a.assign_amount FROM rem_merchant_item_master a LEFT JOIN rem_merchant b ON a.assign_merchant=b.merchant_id LEFT JOIN rem_item c ON a.assign_item=c.item_id WHERE a.assign_merchant='$counter_id'");
						if($counter_items_list){
		 				?>
                         <table cellpadding="0"  width="30%" cellspacing="0" border="1" class="table table-striped table-fixed-header m0"  >
                        <?php
						while($row_items_list  = mysql_fetch_array($counter_items_list))
						{?> 
                        <tr>
                        <td  width="40%"><?php echo $row_items_list[2]; ?></td>
                        <td  width="15%"><?php echo round($row_items_list[3], 1); ?></td><td  width="15%"><?php echo round($row_items_list[4], 1); ?></td>
                        <td  width="15%"><?php echo round($row_items_list[5], 1); ?></td>
                       
                        <td  width="10%"><a href="addmerchant.php?delete_id=<?php echo $row_items_list[0]; ?>&header_id=<?php echo $counter_id; ?>" class="btn btn-danger btn-sm">Delete</a></td>
                        </tr>
                        <?php } ?>
                        
                        <tr>
                        </table>
                        <?php } ?>

                        
                        
                        
                        
                    	</div>
       				</div>
                   
					<div class="tab-pane" id="vertical-form"></div>
					<div class="tab-pane" id="bordered-row"></div>
					<div class="tab-pane" id="tabular-form"></div>
				</div>

				<div class="panel-footer">
					<div class="row">
						<div class="col-sm-10 col-sm-offset-2">
						  <button type="submit" class="btn btn-success" name="submit" id="submit">Add Merchant</button>
                 		</div>
                    </div>
             	 </div>
                 
                 <?php } ?>
              </div>
               
            
            
		</div>
                    </div>
</div>
                          </div> </form> 
                            <!-- .container-fluid -->
                        </div> <!-- #page-content -->
                </div>
                    <footer role="contentinfo">
   <?php include("footer.php"); ?>
</footer>
              </div>
  </div>
</div>
<script>
function showcategory(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayCategory").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getitemcategory2.php?q="+str,true);
  xmlhttp.send();
}
</script>

<script>
function showvendorprice(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayPrices").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getvendorprice.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showamount(str,prices) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayAmount").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getfinalamount.php?q="+str+"&prices="+prices,true);
  xmlhttp.send();
}
</script>
<script>
function showpriceamount(str,qty) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayAmount").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getpricefinalamount.php?q="+str+"&qty="+qty,true);
  xmlhttp.send();
}
</script>

<!-- Switcher --><!-- /Switcher -->
    <!-- Load site level scripts -->

<!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script> -->
<script>
function confirmDelete(delUrl) {
  if (confirm("Are you sure you want to delete")) {
    document.location = delUrl;
  }
}
</script>
<script src="assets/js/jquery-1.10.2.min.js"></script> 							<!-- Load jQuery -->
<script src="assets/js/jqueryui-1.9.2.min.js"></script> 							<!-- Load jQueryUI -->

<script src="assets/js/bootstrap.min.js"></script> 								<!-- Load Bootstrap -->


<script src="assets/plugins/easypiechart/jquery.easypiechart.js"></script> 		<!-- EasyPieChart-->
<script src="assets/plugins/sparklines/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
<script src="assets/plugins/jstree/dist/jstree.min.js"></script>  				<!-- jsTree -->

<script src="assets/plugins/codeprettifier/prettify.js"></script> 				<!-- Code Prettifier  -->
<script src="assets/plugins/bootstrap-switch/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->

<script src="assets/plugins/bootstrap-tabdrop/js/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->

<script src="assets/plugins/iCheck/icheck.min.js"></script>     					<!-- iCheck -->

<script src="assets/js/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->

<script src="assets/plugins/bootbox/bootbox.js"></script>							<!-- Bootbox -->

<script src="assets/plugins/simpleWeather/jquery.simpleWeather.min.js"></script> <!-- Weather plugin-->

<script src="assets/plugins/nanoScroller/js/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->

<script src="assets/plugins/jquery-mousewheel/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script src="assets/plugins/datatables/jquery.dataTables.js"></script>
<script src="assets/plugins/datatables/dataTables.bootstrap.js"></script>
<script src="assets/demo/demo-datatables.js"></script>
<script src="assets/js/application.js"></script>
<script src="assets/demo/demo.js"></script>
<script src="assets/demo/demo-switcher.js"></script>

<!-- End loading site level scripts -->
    
    <!-- Load page level scripts-->
    

    <!-- End loading page level scripts-->

</body>

<!-- Mirrored from avenger.kaijuthemes.com/ui-forms.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 24 Oct 2015 18:46:10 GMT -->
</html>
<?php }
      else
        {
	       header('Location: ../index.php');
        }
		
	?>