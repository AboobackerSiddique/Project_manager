<?php 
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
include("header.php");
if($_SESSION['user_name'])
{
	
	$max_header_result = mysql_query("SELECT MAX(vendor_id) FROM rem_vendor");
	while($row_id = mysql_fetch_array($max_header_result))
	{
		$max_header = $row_id[0];
	}
	
			
			if ($max_header == 0 )
			{
				$max_header_id = "1";	
			}
			else
			{
				$max_header_id = $max_header;
				$max_header_id++;
			} 
			$header_id=$max_header_id;
			
 
	if(isset($_GET["search"]))
   	{
	    mysql_query("DELETE FROM rem_vendor_item_assign WHERE assign_vendor= '$_GET[search]'");
		header("Location: addvendor.php");
   	}
	
	if(isset($_GET["assign_id"]))
   	{
	      mysql_query("DELETE FROM rem_vendor_item_assign WHERE assign_id='$_GET[assign_id]'");
		   echo "<script>window.history.go(-1);</script>";
   	}
	
	if(isset($_GET["vendor_id"]))
   	{
	    mysql_query("DELETE FROM rem_vendor WHERE vendor_id= '$_GET[vendor_id]'");
		mysql_query("DELETE FROM rem_vendor_item_assign WHERE assign_vendor= '$_GET[vendor_id]'");
   	}
   
if(isset($_POST["submit"]))
{
	$result9 = mysql_query("SELECT vendor_name,vendor_code FROM rem_vendor where vendor_name='$_POST[name]'");
	while($row9 = mysql_fetch_array($result9))
  	{
 		$username= $row9[0];
		$code= $row9[1];
	}
	
	
if ($_POST['name'] == $username ) 
{

 $message = 'Vendor Already Exist';

    echo "<SCRIPT type='text/javascript'> 
        alert('$message');
        window.location.replace(\"addvendor.php\");
    </SCRIPT>"; 
}
else if ($_POST['sname'] == $code ) 
{

 $message = 'Vendor Short Name Already Exist';

    echo "<SCRIPT type='text/javascript'> 
        alert('$message');
        window.location.replace(\"addvendor.php\");
    </SCRIPT>"; 
}
else
{
	
 $sql="INSERT INTO rem_vendor(vendor_id,vendor_name,vendor_description,vendor_code,vendor_user,vendor_country,vendor_state,vendor_city,vendor_ledger_type)
VALUES
('$header_id','$_POST[name]','$_POST[description]','$_POST[sname]','$_SESSION[user_name]','$_POST[country]','$_POST[states]','$_POST[cities]','capital')";
 

       if (!mysql_query($sql,$con))
          {
            die('Error: ' . mysql_error());
          }
		  $sql2="INSERT INTO cfms_party_master(party_name,party_type_id,party_type)
VALUES
('$_POST[name]','$header_id','vendor')";
 

       if (!mysql_query($sql2,$con))
          {
            die('Error: ' . mysql_error());
          }

		$checkbox1 = $_POST['chk1'];
		$checkbox2 = $_POST['chk2'];
		
		for ($i=0; $i<sizeof($checkbox1); $i++)
		{
		for ($i=0; $i<sizeof($checkbox2); $i++)
		{
			mysql_query("UPDATE rem_vendor_item_assign SET assign_item_price='".$checkbox2[$i]."' WHERE assign_vendor='$header_id' AND assign_item='".$checkbox1[$i]."'"); 
		}}
  }
     $message = 'Vendor Created Successfully';

    echo "<SCRIPT type='text/javascript'> 
        alert('$message');
        window.location.replace(\"addvendor.php\");
    </SCRIPT>";
   }
?>
   
<div id="wrapper">
            <div id="layout-static">
              <div class="static-content-wrapper">
                  <div class="static-content">
                        <div class="page-content">
                          <ol class="breadcrumb">
                                
 <li class=""> <div class="btn-toolbar">
       <a class="btn btn-midnightblue" href="index.php"><i class="fa fa-fast-backward"></i> Back</a>&nbsp;&nbsp; <a class="btn btn-success" href="viewvendor.php"><i class="fa fa-user"></i> View Added Vendor</a>
    </div></li>


                          </ol>
                            <div class="container-fluid">
                              
  <div class="row">
	<div class="col-sm-7">
	  <div class="panel panel-midnightblue">
	    <div class="panel-heading">
				<h2>Vendor Master</h2>
			</div>
			<div class="panel-body">
				<div class="tab-content">
					<div class="tab-pane active" id="horizontal-form">
						<form  method="post" class="form-horizontal">
                     <?php if(isset($_GET['display']))
					 {
						 ?> <center><font color="#FF0000" size="3"><b><?php echo $_GET['display']; ?></b></font></center>
                         <?php } ?>
                           <div class="form-group">
						    <label for="selector1" class="col-sm-2 control-label"> Country</label>
							<div class="col-sm-8">
                                  <?php
         $countries = mysql_query("SELECT id,name FROM countries");
		 ?>
		<select required  class="form-control"  name="country" id="country" onchange="showstates(this.value)" onkeydown='if(event.keyCode == 13){document.getElementById("states").focus();return false;}'>
         <option value="">Country...</option>
         <?php 
   		while($row_countries = mysql_fetch_array($countries))
		{
		?>
		<option value="<?php echo $row_countries[0]; ?>"><?php echo $row_countries[1]; }?></option>
      
       </select></div>
						  </div>
                          <div id="displayStates">
                         <div class="form-group">
<label for="selector1" class="col-sm-2 control-label"> States</label>
<div class="col-sm-8">
<?php
$states = mysql_query("SELECT id,name FROM states WHERE country_id=''");
?>
<select   class="form-control" required  name="states" id="states" onkeydown='if(event.keyCode == 13){document.getElementById("city").focus();return false;}'>
<option value="">States...</option>
 <?php 
while($row_states = mysql_fetch_array($states))
{?>
<option value="<?php echo $row_states[0]; ?>"><?php echo $row_states[1]; }?></option>
</select></div></div>
                          </div>
                          
                          <div id="displayCities">
                      <div class="form-group">
<label for="selector1" class="col-sm-2 control-label"> Cities</label>
<div class="col-sm-8">
<?php
$cities = mysql_query("SELECT id,name FROM cities WHERE state_id='$_GET[q]'");
?>
<select   class="form-control"  required  name="cities" id="cities" onkeydown='if(event.keyCode == 13){document.getElementById("location").focus();return false;}'>
<option value="">Cities...</option>
 <?php 
while($row_cities = mysql_fetch_array($cities))
{?>
<option value="<?php echo $row_cities[0]; ?>"><?php echo $row_cities[1]; }?></option>
</select></div></div>
                          </div>
                          
						  <div class="form-group">
								<label for="inputPassword" class="col-sm-2 control-label">Vendor Name</label>
							  <div class="col-sm-8">
								  <input type="text" class="form-control" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("sname").focus();return false;}' id="name" value="" name="name" placeholder="Enter Vendor Name" required>
						   </div>
						  </div>
                          <div class="form-group">
								<label for="inputPassword" class="col-sm-2 control-label">Vendor Code</label>
							  <div class="col-sm-8">
								  <input type="text" class="form-control" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("category").focus();return false;}' id="sname" value="" name="sname" placeholder="Enter Vendor Short Name" required>
						   </div>
						  </div>
                          	 <div class="form-group">
						    <label for="selector1" class="col-sm-2 control-label"> Choose Category</label>
								<div class="col-sm-8">
                               
								<?php 
								$items = mysql_query("SELECT cat_id,cat_name FROM rem_vendor_category");
								?>
                               	<select  class="form-control"  name="category" id="category" onkeydown='if(event.keyCode == 13){document.getElementById("description").focus();return false;}'  onchange="showcategory(this.value)" >
         						<option value="">Choose Category</option>
         						<?php 
   								while($area_row = mysql_fetch_array($items))
								{
								?>
								<option value="<?php echo $area_row[0]; ?>"><?php echo $area_row[1]; }?></option>
      							</select>
      							</div>
                                </div>	
                        
                          
                       	  <div class="form-group">
						    <label for="selector1" class="col-sm-2 control-label"> Choose Item </label>
								<div class="col-sm-8">
                                <input type="hidden" name="header_id" id="header_id" value="<?php echo $header_id; ?>" />
                                <div id="displayItem">
                                <div id="displayCategory">
								
                               	<select  class="form-control"  name="item_id" id="item_id" onkeydown='if(event.keyCode == 13){document.getElementById("description").focus();return false;}'  onchange="showitem(item_id.value,header_id.value)" >
         						<option value="">Choose item to add...</option>
         						<?php 
   								while($area_row = mysql_fetch_array($items))
								{
								?>
								<option value="<?php echo $area_row[0]; ?>"><?php echo $area_row[1]; }?></option>
      							</select>
      							</div>	
                              
                               
       <br/>
       
       <?php 
$proofs = mysql_query("SELECT a.assign_id,a.assign_vendor,a.assign_item,b.item_name,a.assign_item_price FROM rem_vendor_item_assign a LEFT JOIN rem_item b ON a.assign_item=b.item_id where a.assign_vendor='$header_id'");

if($proofs){?><div id="demo">
<table cellpadding="0"  width="30%" cellspacing="0" border="1" class="table table-striped table-fixed-header m0"  >
<?php 
while($row_proof = mysql_fetch_array($proofs))
{
?>
<tr>
<td width="50%">
<?php echo $row_proof[3]; ?> </td>
<td width="40%">
<input type="hidden" class="form-control" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("category").focus();return false;}' id="chk1[]" value="<?php echo $row_proof[2]; ?>" name="chk1[]" placeholder="Enter Vendor Name" required>
        <input type="text" class="form-control" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("category").focus();return false;}' id="chk2[]" value="<?php echo round($row_proof[4],0); ?>" name="chk2[]" placeholder="Enter Item Amount" ></td>
        <td width="10%"><a class="btn btn-danger"  href="addvendor.php?assign_id=<?php echo $row_proof[0]; ?>"><i class="fa fa-times-circle"></i></a></td>
</tr>
<?php } ?>
</table>
</div>
<?php } ?></div>
       </div>
       
						  </div>
                          <div class="form-group">
							  <label for="focusedinput" class="col-sm-2 control-label">Descripion</label>
							<div class="col-sm-8">
								  <textarea class="form-control" name="description" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("submit").focus();return false;}' id="description" required placeholder="Enter  Description"></textarea>
							</div>
						  </div>
                          
                          
                          
                         
						  </div>
					<div class="tab-pane" id="vertical-form"></div>
					</div>
                    
                      <div class="form-group">
								<label for="focusedinput" class="col-sm-2 control-label"></label>
								<div class="col-sm-8">
									<button type="submit" class="btn btn-info"  style="background-color:#F93;"  name="submit" id="submit">Create Vendor</button>
								</div>
						  </div>
  
                            </form>
				
         
			</div>
		</div>
        
	</div>
</div>
                          </div> 
                            <!-- .container-fluid -->
                        </div> <!-- #page-content -->
                </div>
                    <footer role="contentinfo">
   <?php include("footer.php"); ?>
</footer>
              </div>
  </div>
</div>
<script>
function showitem(item_id,header_id) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayItem").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getitem.php?item_id="+item_id+"&header_id="+header_id,true);
  xmlhttp.send();
}
</script>
<script>
function showstates(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayStates").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getstates.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showtesting(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayTesting").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettesting.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showcities(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayCities").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getcity.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showcategory(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayCategory").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getitemcategory.php?q="+str,true);
  xmlhttp.send();
}
</script>

<!-- Switcher --><!-- /Switcher -->
    <!-- Load site level scripts -->

<!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script> -->
<script>
function confirmDelete(delUrl) {
  if (confirm("Are you sure you want to delete")) {
    document.location = delUrl;
  }
}
</script>
<script src="assets/js/jquery-1.10.2.min.js"></script> 							<!-- Load jQuery -->
<script src="assets/js/jqueryui-1.9.2.min.js"></script> 							<!-- Load jQueryUI -->

<script src="assets/js/bootstrap.min.js"></script> 								<!-- Load Bootstrap -->


<script src="assets/plugins/easypiechart/jquery.easypiechart.js"></script> 		<!-- EasyPieChart-->
<script src="assets/plugins/sparklines/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
<script src="assets/plugins/jstree/dist/jstree.min.js"></script>  				<!-- jsTree -->

<script src="assets/plugins/codeprettifier/prettify.js"></script> 				<!-- Code Prettifier  -->
<script src="assets/plugins/bootstrap-switch/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->

<script src="assets/plugins/bootstrap-tabdrop/js/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->

<script src="assets/plugins/iCheck/icheck.min.js"></script>     					<!-- iCheck -->

<script src="assets/js/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->

<script src="assets/plugins/bootbox/bootbox.js"></script>							<!-- Bootbox -->

<script src="assets/plugins/simpleWeather/jquery.simpleWeather.min.js"></script> <!-- Weather plugin-->

<script src="assets/plugins/nanoScroller/js/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->

<script src="assets/plugins/jquery-mousewheel/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script src="assets/plugins/datatables/jquery.dataTables.js"></script>
<script src="assets/plugins/datatables/dataTables.bootstrap.js"></script>
<script src="assets/demo/demo-datatables.js"></script>
<script src="assets/js/application.js"></script>
<script src="assets/demo/demo.js"></script>
<script src="assets/demo/demo-switcher.js"></script>

<!-- End loading site level scripts -->
    
    <!-- Load page level scripts-->
    

    <!-- End loading page level scripts-->

</body>

<!-- Mirrored from avenger.kaijuthemes.com/ui-forms.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 24 Oct 2015 18:46:10 GMT -->
</html>
<?php }
      else
        {
	       header('Location: ../index.php');
        }
		
	?>