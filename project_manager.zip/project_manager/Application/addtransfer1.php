<?php 
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
include("header.php");
 if($_SESSION['user_name'])
{
if(isset($_POST["search"]))
{
		header("Location: addtransfer.php?qty=$_POST[qty]&move=$_POST[move]&itemid=$_POST[itemid]&from_type=$_POST[from_type]&from=$_POST[from]&from_outlet=$_POST[from_outlet]&to_type=$_POST[to_type]&to=$_POST[to]&to_outlet=$_POST[to_outlet]");
		
}

if(isset($_POST["submit"]))
{
		$from_type=$_GET['from_type'];
		$from_outlet=$_GET['from_outlet'];
		$from=$_GET['from'];
		$to_type=$_GET['to_type'];
		$to_outlet=$_GET['to_outlet'];
		$to=$_GET['to'];
		$item_id=$_GET['itemid'];
		if($_GET['move'] == '1')
		{
			$movable=0;
		}
		else
		{
			$movable=1;
		}
		$user_name=$_SESSION["user_name"];
		
		$checkbox1 = $_POST['chk1'];
		$checkbox2 = $_POST['chk2'];
		
		
		for ($i=0; $i<sizeof($checkbox1); $i++)
		{
		for ($i=0; $i<sizeof($checkbox2); $i++)
		{
date_default_timezone_set('Asia/Calcutta');
$current_date=date("Y-m-d H:i");	
 $sql="INSERT INTO rem_stock(stock_item,stock_barcode,stock_qty,stock_from_type,stock_from_outlet,stock_from,stock_to_type,stock_to_outlet,stock_to,stock_user,stock_movable)
VALUES
('$item_id','".$checkbox2[$i]."','".$checkbox1
[$i]."','$from_type','$from_outlet','$from','$to_type','$to_outlet','$to','$user_name','$movable')";
 

       		if(!mysql_query($sql,$con))
          	{
            	die('Error: ' . mysql_error());
          	}
		}
		}
			$message = 'Stock Transferred Successfully';

   			echo "<SCRIPT type='text/javascript'> 
        	alert('$message');
        	window.location.replace(\"addtransfer.php\");
    		</SCRIPT>";
}
?>
   
<div id="wrapper">
            <div id="layout-static">
              <div class="static-content-wrapper">
                  <div class="static-content">
                        <div class="page-content">
                          <ol class="breadcrumb">
                                
 <li class=""> <div class="btn-toolbar">
       <a class="btn btn-midnightblue" href="index.php"><i class="fa fa-fast-backward"></i> Back</a>
      
    </div></li>


                          </ol>
                            <div class="container-fluid">
                              
  <div class="row">
	<div class="col-sm-12">
	  <div class="panel panel-midnightblue">
	    <div class="panel-body">
	      <div class="tab-content">
	      <div class="tab-pane active" id="horizontal-form">
	      <form  method="post" class="form-horizontal">
                    
					  <div class="form-group">
						
						<div class="col-sm-12">
                        <div class="col-sm-2">
                               
								<?php 
								$items = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor");
								?>From_type:
                               	<select  class="form-control"   name="from_type" id="from_type" onchange="showfromtype(this.value)" required >
         						<option value="2">WAREHOUSE</option>
                                <option value="3">OUTLET</option>
                                <option value="4">EMPLOYEE</option>
         						
      							</select>
      							</div>
                               
                               
                               <div id="displayFromType">
                               		<div class="col-sm-2">
                               <input type="hidden" name="from_outlet" id="from_outlet" value="0" />
								<?php 
								$warehouse = mysql_query("SELECT warehouse_id,warehouse_name FROM rem_warehouse");
								?>Choose Warehouse:
                               	<select  class="form-control"   name="from" id="from" required >
         						<option value="">CHOOSE WAREHOUSE</option>
         						<?php 
   								while($area_row = mysql_fetch_array($warehouse))
								{
								?>
								<option value="<?php echo $area_row[0]; ?>"><?php echo $area_row[1]; }?></option>
      							</select>
      								</div>
                               </div>
                                
                                
                                
                                 <div class="col-sm-2">
                               
								 	<?php
         				$category = mysql_query("SELECT cat_id,cat_name FROM rem_vendor_category");
		 				?>Choose Category:
                               	<select  class="form-control" onchange="showcategory(this.value,from_type.value,from_outlet.value,from.value)"  name="category" id="category"  >
         						<option value="">CHOOSE CATEGORY</option>
         						<?php 
   								while($row_category = mysql_fetch_array($category))
								{
								?>
								<option value="<?php echo $row_category[0]; ?>"><?php echo $row_category[1]; }?></option>
      							</select>
      							</div>
                                
                  <div id="displayItem">    
                            <div class="col-sm-2"> 
                            Search Item:     
                          
                        <input list="item_id" name="item_id" onchange="showvendorprice(this.value)" class="form-control" autocomplete="off" placeholder="Search Item" value=""  >
        					<datalist id="item_id">
       		
    						</datalist>  
                   			 </div> 
                   </div>
                    
                    
                    <div id="displayStock">
                        	 <div class="col-sm-2">
                             Available Stock: 
								<input type="text" readonly="readonly" class="form-control"  id="stock" value="" name="stock" placeholder="Available Stock" >
      						</div> 
                   </div>
                        
                                 
                        <div class="col-sm-2">
                             Enter Qty: 
								<input type="text" autocomplete="off" class="baseAmt form-control"  id="qty" value="<?php echo round($row_items_list[3], 1); ?>" name="qty" placeholder="Amount"  required="required">
      					</div>         
                                
                        <div class="col-sm-2">
                               
								<?php 
								$items = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor");
								?>To_type:
                               	<select  class="form-control"   name="to_type" id="to_type" onchange="showtotype(this.value)" required >
         						<option value="2">WAREHOUSE</option>
                                <option value="3">OUTLET</option>
                                <option value="4">EMPLOYEE</option>
         						
      							</select>
      							</div>        
                                
                                <div id="displayToType">
                               		<div class="col-sm-2">
                               <input type="hidden" name="to_outlet" id="to_outlet" value="0" />
								<?php 
								$warehouse = mysql_query("SELECT warehouse_id,warehouse_name FROM rem_warehouse");
								?>Choose Warehouse:
                               	<select  class="form-control"   name="to" id="to" required >
         						<option value="">CHOOSE WAREHOUSE</option>
         						<?php 
   								while($area_row = mysql_fetch_array($warehouse))
								{
								?>
								<option value="<?php echo $area_row[0]; ?>"><?php echo $area_row[1]; }?></option>
      							</select>
      								</div>
                               </div>  
                               <div class="col-sm-2">
                               
								<?php 
								$items = mysql_query("SELECT vendor_id,vendor_name FROM rem_vendor");
								?>Movable/Immovable:
                               	<select  class="form-control"   name="move" id="move"  required>
         						
                                <option value="1">MOVABLE</option>
                                <option value="2">IMMOVABLE</option>
         						
      							</select>
      							</div>
                               <div class="col-sm-1"><br/>
                              <button type="submit" class="btn btn-success"  name="search" id="search">Transfer Stock</button>
      								</div> 
						 
                        
                        
                        
                        
                    	</div>
       				</div>
                    </form>
                    <form method="post">
                    <div class="form-group">
						  
								<div class="col-sm-12">
                                <?php if(isset($_GET['itemid']))
								{?>
                               <div id="demo">
                               <center><h4><u><b><?php echo $vendor_name; ?></b></u></h4></center>
<table cellpadding="0"  width="30%" cellspacing="0" border="1" class="table table-striped table-fixed-header m0"  >
<tr style="background-color:#999999; color:#FFF;">
<td ><b>SL NO</b></td>
<td ><b>ITEM CATEGORY</b></td>
<td ><b>ITEM NAME</b></td>
<td ><b>QTY</b></td>
<td ><b>ITEM BARCODE </b></td>
</tr>
<?php 

	$result = mysql_query("SELECT a.item_id id,a.item_name item_name,b.cat_name item_category FROM rem_item a LEFT JOIN rem_vendor_category b ON a.item_category=b.cat_id WHERE a.item_id='$_GET[itemid]'");
$counter=0;
while($row = mysql_fetch_array($result))
{
	$i=0;
	for($i=0; $i<$_GET['qty']; $i++)
	{
?>

<tr class="venTab">
<td width="5%"><?php echo ++$counter; ?>
<td width="25%"><?php echo $row['item_category']; ?> </td>
<td width="30%"><?php echo $row['item_name']; ?></td>
<td width="10%"><input type="text" readonly="readonly" class="form-control" name="chk1[]" id="chk1[]" value="1"></td>
<td width="25%"><input type="text"  class="form-control" name="chk2[]" id="chk2[]" value=""  autocomplete="off" placeholder="Enter Item Barcode"></td>
</tr>
<?php } } ?>

</table>
</div><br/>
    <center><button type="submit" class="btn btn-info"  name="submit" id="submit">Transfer Stock</button></center>
<?php } ?>

</div>
       </div>
     </form>               
                    
                    
                    
					  </div>
					
					</div>
	 
				
         
			</div>
		</div>
        
	</div>
</div>
                          </div> 
                            <!-- .container-fluid -->
                        </div> <!-- #page-content -->
                </div>
                    <footer role="contentinfo">
   <?php include("footer.php"); ?>
</footer>
              </div>
  </div>
</div>
<script
  src="https://code.jquery.com/jquery-3.3.1.min.js"
  integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
  crossorigin="anonymous"></script>
<script>


$(document).on("keyup","#qty",function()
{
	
	var oldVal = $("#stock").val();
	var newVal = $(this).val();
if(parseFloat(oldVal)<parseFloat(newVal))
{
alert('Sorry..! You dont have insufficient Stock Available to transfer ');
$(this).val(oldVal);
}	
});


function showfromtype(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayFromType").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransferfromtype.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showfrommerchant(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayFromMerchant").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransfermerchant.php?q="+str,true);
  xmlhttp.send();
}
</script>

<script>
function showfromemployeemerchant(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {

    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayFromEmployeeMerchant").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransferemployeemerchant.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showfromemployee(str,emp_outlet) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayFromEmployee").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransferemployee.php?q="+str+"&emp_outlet="+emp_outlet,true);
  xmlhttp.send();
}
</script>


<script>
function showcategory(str,from_type,from_outlet,from) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayItem").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransferitem.php?q="+str+"&from_type="+from_type+"&from_outlet="+from_outlet+"&from="+from,true);
  xmlhttp.send();
}
</script>

<script>
function showstock(str,stock_from_type,stock_from_outlet,stock_from) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayStock").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransferstock.php?q="+str+"&stock_from_type="+stock_from_type+"&stock_from_outlet="+stock_from_outlet+"&stock_from="+stock_from,true);
  xmlhttp.send();
}
</script>
<script>
function showtotype(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayToType").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransfertotype.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showtomerchant(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayToMerchant").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransfertomerchant.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showtoemployeemerchant(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {

    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayToEmployeeMerchant").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransfertoemployeemerchant.php?q="+str,true);
  xmlhttp.send();
}
</script>
<script>
function showtoemployee(str,emp_outlet) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayToEmployee").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","gettransfertoemployee.php?q="+str+"&emp_outlet="+emp_outlet,true);
  xmlhttp.send();
}
</script>
<!-- Switcher --><!-- /Switcher -->
    <!-- Load site level scripts -->

<!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script> -->
<script>
function confirmDelete(delUrl) {
  if (confirm("Are you sure you want to delete")) {
    document.location = delUrl;
  }
}
</script>
<script src="assets/js/jquery-1.10.2.min.js"></script> 							<!-- Load jQuery -->
<script src="assets/js/jqueryui-1.9.2.min.js"></script> 							<!-- Load jQueryUI -->

<script src="assets/js/bootstrap.min.js"></script> 								<!-- Load Bootstrap -->


<script src="assets/plugins/easypiechart/jquery.easypiechart.js"></script> 		<!-- EasyPieChart-->
<script src="assets/plugins/sparklines/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
<script src="assets/plugins/jstree/dist/jstree.min.js"></script>  				<!-- jsTree -->

<script src="assets/plugins/codeprettifier/prettify.js"></script> 				<!-- Code Prettifier  -->
<script src="assets/plugins/bootstrap-switch/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->

<script src="assets/plugins/bootstrap-tabdrop/js/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->

<script src="assets/plugins/iCheck/icheck.min.js"></script>     					<!-- iCheck -->

<script src="assets/js/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->

<script src="assets/plugins/bootbox/bootbox.js"></script>							<!-- Bootbox -->

<script src="assets/plugins/simpleWeather/jquery.simpleWeather.min.js"></script> <!-- Weather plugin-->

<script src="assets/plugins/nanoScroller/js/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->

<script src="assets/plugins/jquery-mousewheel/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->
<script src="assets/plugins/datatables/jquery.dataTables.js"></script>
<script src="assets/plugins/datatables/dataTables.bootstrap.js"></script>
<script src="assets/demo/demo-datatables.js"></script>
<script src="assets/js/application.js"></script>
<script src="assets/demo/demo.js"></script>
<script src="assets/demo/demo-switcher.js"></script>

<!-- End loading site level scripts -->
    
    <!-- Load page level scripts-->
    

    <!-- End loading page level scripts-->

</body>

<!-- Mirrored from avenger.kaijuthemes.com/ui-forms.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 24 Oct 2015 18:46:10 GMT -->
</html>
<?php }
      else
        {
	       header('Location: ../index.php');
        }
		
	?>