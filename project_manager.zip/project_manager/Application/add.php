<?php 
ob_start();
session_start();
error_reporting(E_ERROR | E_PARSE);
include("dbconnection.php");
include("header.php");
$counter_id = $_GET['header_id'];
if(isset($_SESSION["user_name"]))
{
$counter_details = mysql_query("SELECT counter_outlet,counter_merchant FROM rem_counter_temp WHERE counter_header_id='$counter_id'");
	while($row_counter = mysql_fetch_array($counter_details))
	{
		$counter_outlet = $row_counter[0];
		$counter_merchant = $row_counter[1];
	}

if(isset($_GET['delete_id']))
{
	mysql_query("DELETE FROM rem_counter_details WHERE details_id='$_GET[delete_id]'");
}

if(isset($_POST["add"]))
{
	
	$find_outlets = mysql_query("SELECT counter_outlet FROM rem_counter WHERE counter_outlet='$_POST[outlet]' AND counter_merchant='$_POST[merchant]'");
	while($row_find_outlets = mysql_fetch_array($find_outlets))
	{
		$counter_find = $row_find_outlets[0];
	}
	
	if($counter_find)
	{
			$message = 'Kitchen Already Exist..';
 			echo "<SCRIPT type='text/javascript'> 
        	alert('$message');
       		window.location.replace(\"add.php\");
    		</SCRIPT>"; 
	}
	else
	{
	
	$max_header_result = mysql_query("SELECT MAX(counter_header_id) FROM rem_counter_temp");
	while($row_id = mysql_fetch_array($max_header_result))
	{
		$max_header = $row_id[0];
	}
	
		if ($max_header == 0 )
		{
			$max_header_id = "T1";	
		}
		else
		{
			$max_header_id = $max_header;
			$max_header_id++;
		} 
		$header_id=$max_header_id;
		
		mysql_query("DELETE FROM rem_counter_temp");
		mysql_query("DELETE FROM rem_counter_details WHERE details_process=0");
				
		$sql="INSERT INTO rem_counter_temp(counter_header_id,counter_outlet,counter_merchant)
		VALUES
		('$header_id','$_POST[outlet]','$_POST[merchant]')";
 		
		if (!mysql_query($sql,$con))
        {
        	die('Error: ' . mysql_error());
        }
		header("Location: add.php?header_id=$header_id");
	}
		
		
}

if(isset($_POST["create"]))
{
	$sql="INSERT INTO rem_counter_details(details_header_id,details_outlet,details_merchant,details_vendor,details_item,details_price,details_qty,details_amount)
	VALUES
	('$counter_id','$counter_outlet','$counter_merchant]','$_POST[vendor]','$_POST[item_id]','$_POST[price]','$_POST[qty]','$_POST[amount]')";
 		
	if (!mysql_query($sql,$con))
    {
       die('Error: ' . mysql_error());
    }	
	header("Location: add.php?header_id=$counter_id");
}

if(isset($_POST["submit"]))
{
	$max_header_result = mysql_query("SELECT MAX(counter_header_id) FROM rem_counter");
	while($row_id = mysql_fetch_array($max_header_result))
	{
		$max_header = $row_id[0];
	}
	
			
			if ($max_header == 0 )
			{
				$max_header_id = "1";	
			}
			else
			{
				$max_header_id = $max_header;
				$max_header_id++;
			} 
			$header_id=$max_header_id;
			
			$sql="INSERT INTO rem_counter(counter_header_id,counter_outlet,counter_merchant)
			VALUES
			('$header_id','$counter_outlet','$counter_merchant')";
 		
			if (!mysql_query($sql,$con))
        	{
        		die('Error: ' . mysql_error());
        	}
			mysql_query("UPDATE rem_counter_details SET details_header_id='$header_id',details_process='1' WHERE details_header_id='$counter_id'");	
			
			$message = 'Kichen Added Successfully..';
 			echo "<SCRIPT type='text/javascript'> 
        	alert('$message');
       		window.location.replace(\"index.php\");
    		</SCRIPT>"; 
}



?>
   
<div id="wrapper">
            <div id="layout-static">
              <div class="static-content-wrapper">
                  <div class="static-content">
                    <div class="page-content">
                          <ol class="breadcrumb">
                  <li class=""> <div class="btn-toolbar">
       <a class="btn btn-midnightblue" href="index.php"><i class="fa fa-fast-backward"></i> Back</a>
    </div></li>
                  



                          </ol> <form  method="post" class="form-horizontal">
                      <div class="container-fluid">
                             
  <div class="row">
	<div class="col-sm-12">
	  <div class="panel panel-midnightblue">
	    <div class="panel-heading">
				<h2>Assign Item to Outlet Kitchen</h2>
			</div>
			<div class="panel-body">
				<div class="tab-content">
					<div class="tab-pane active" id="horizontal-form">
					  <div class="form-group">
						    <label for="selector1" class="col-sm-2 control-label">Choose Oulet</label>
						<div class="col-sm-2">
                                  <?php
         $outlet = mysql_query("SELECT outlet_id,outlet_name FROM rem_outlet WHERE outlet_id!='$counter_outlet'");
		 ?>
		<select required  class="form-control"  name="outlet" id="outlet"  <?php if(isset($_GET['header_id']))
	   { echo 'disabled="disabled"'; } ?>  onkeydown='if(event.keyCode == 13){document.getElementById("merchant").focus();return false;}'>
         <?php if(isset($_GET['header_id']))
		 {
			$outlet_get = mysql_query("SELECT outlet_id,outlet_name FROM rem_outlet WHERE outlet_id='$counter_outlet'");
			while($row_outlet_get = mysql_fetch_array($outlet_get))
			{?>
            <option value="<?php echo $row_outlet_get[0]; ?>"><?php echo $row_outlet_get[1]; }?></option>
         <?php } else { ?>
         <option value="">Choose Outlet</option>
         <?php } ?>
         <?php 
   		while($row_outlet = mysql_fetch_array($outlet))
		{
		?>
		<option value="<?php echo $row_outlet[0]; ?>"><?php echo $row_outlet[1]; }?></option>
      
       </select></div>
       
						  </div>
					  <div class="form-group">
						    <label for="selector1" class="col-sm-2 control-label"> Choose Merchant</label>
							<div class="col-sm-2">
                                  <?php
         $merchant = mysql_query("SELECT merchant_id,merchant_name FROM rem_merchant WHERE merchant_id!='$counter_merchant'");
		 ?>
		<select required  class="form-control"  name="merchant" <?php if(isset($_GET['header_id']))
	   { echo 'disabled="disabled"'; } ?> id="merchant" onkeydown='if(event.keyCode == 13){document.getElementById("item").focus();return false;}'>
         <?php if(isset($_GET['header_id']))
		 {
			$merchant_get = mysql_query("SELECT merchant_id,merchant_name FROM rem_merchant WHERE merchant_id='$counter_merchant'");
			while($row_merchant_get = mysql_fetch_array($merchant_get))
			{?>
            <option value="<?php echo $row_merchant_get[0]; ?>"><?php echo $row_merchant_get[1]; }?></option>
         <?php } else { ?>
         <option value="">Choose Merchant..</option>
         <?php } ?>
         <?php 
   		while($row_merchant = mysql_fetch_array($merchant))
		{
		?>
		<option value="<?php echo $row_merchant[0]; ?>"><?php echo $row_merchant[1]; }?></option>
      
       </select></div>
       <?php if(!isset($_GET['header_id']))
	   {?>
       <div class="col-sm-2">
         <button type="submit" class="btn btn-success"  name="add" id="add">Click to Assign Item</button>
       </div>
       <?php } ?>
						  </div>
                    </div>
                   <?php if(isset($_GET['header_id']))
					{?>  
                    <div class="form-group">
						<label for="selector1" class="col-sm-2 control-label">Choose Item</label>
						<div class="col-sm-10">
                        <table cellpadding="0"  width="30%" cellspacing="0" border="1" class="table table-striped table-fixed-header m0"  >
                        <tr style="color:#FFF;" >
                        <td bgcolor="#999999" width="20%">Choose Category</td>
                        <td bgcolor="#999999" width="20%">Choose Item</td>
                        <td bgcolor="#999999" width="15%">Choose Vendor</td>
                        <td bgcolor="#999999" width="11%">Cost</td>
                        <td bgcolor="#999999" width="11%">Qty</td>
                        <td bgcolor="#999999" width="13">Amount</td>
                        <td bgcolor="#999999" width="10%">Add</td>
                        </tr>
                        <tr>
                        <td >
                       	<?php
         				$category = mysql_query("SELECT cat_id,cat_name FROM rem_vendor_category");
		 				?>
						<select class="form-control" onchange="showcategory(this.value)"  name="category" id="category"  onkeydown='if(event.keyCode == 13){document.getElementById("item_id").focus();return false;}'>
         				<option value="">Choose Category</option>
         				<?php 
   						while($row_category  = mysql_fetch_array($category ))
						{
						?>
						<option value="<?php echo $row_category[0]; ?>"><?php echo $row_category[1]; }?></option>
      					</select>
                       </td>
                       <td >
                       	<div id="displayCategory">
						<?php
         				$item = mysql_query("SELECT item_id,item_name FROM rem_item");
		 				?>
						<select class="form-control" onchange="showvendor(this.value)"  name="item_id" id="item_id"  onkeydown='if(event.keyCode == 13){document.getElementById("vendor").focus();return false;}'>
         				<option value="">Choose Item</option>
         				<?php 
   						while($row_item  = mysql_fetch_array($item ))
						{
						?>
						<option value="<?php echo $row_item[0]; ?>"><?php echo $row_item[1]; }?></option>
      					</select>
                        </div>
                       </td>
                        <td >
                        <div id="displayVendor">
                       
						<select class="form-control" onchange="showprice(this.value,item_id.value)"  name="vendor" id="vendor"  onkeydown='if(event.keyCode == 13){document.getElementById("qty").focus();return false;}'>
         				<option value="">Choose Vendor</option>
         				</select>
                        </div>
                        </td>
                        <td >
                        <div id="displayPrice">
                        <input type="text" readonly="readonly" class="form-control" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("qty").focus();return false;}' id="price" value="" name="price" placeholder="Cost" >
        				</div>
                        </td>
                        <td >
                         <input type="text" onkeyup="showamount(this.value,price.value)"  class="form-control" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("amount").focus();return false;}' id="qty" value="" name="qty" placeholder="Qty" >
        </td>
                        <td >
                        <div id="displayAmount">
                         <input type="text"  class="form-control" onkeydown='if (event.keyCode == 13) 
        {document.getElementById("add").focus();return false;}' id="amount" value="" name="amount" placeholder="Amount" >
       					</div>
                        </td>
                        <td >
                         <button type="submit" class="btn btn-info"  name="create" id="create">ADD</button>
                         </td>
                        </tr>
                        </table>
                        <?php
         				$counter_items_list= mysql_query("SELECT a.details_id,a.details_header_id,b.outlet_name,c.merchant_name,d.vendor_name,e.item_name,a.details_price,a.details_qty,a.details_amount FROM rem_counter_details a LEFT JOIN rem_outlet b ON a.details_outlet=b.outlet_id LEFT JOIN rem_merchant c ON a.details_merchant=c.merchant_id LEFT JOIN rem_vendor d ON a.details_vendor=d.vendor_id LEFT JOIN rem_item e ON a.details_item=e.item_id WHERE a.details_header_id='$counter_id'");
						if($counter_items_list){
		 				?>
                         <table cellpadding="0"  width="30%" cellspacing="0" border="1" class="table table-striped table-fixed-header m0"  >
                        <?php
						while($row_items_list  = mysql_fetch_array($counter_items_list))
						{?> 
                        <tr>
                        <td  width="40%"><?php echo $row_items_list[5]; ?></td>
                        <td  width="15%"><?php echo $row_items_list[4]; ?></td>
                        <td  width="11%">&#8377 <?php echo round($row_items_list[6], 0); ?></td>
                        <td  width="11%"><?php echo round($row_items_list[7],0); ?></td>
                        <td  width="13">&#8377 <?php echo round($row_items_list[8],0); ?></td>
                        <td  width="10%"><a href="add.php?delete_id=<?php echo $row_items_list[0]; ?>&header_id=<?php echo $counter_id; ?>" class="btn btn-danger btn-sm">Delete</a></td>
                        </tr>
                        <?php } ?>
                        <tr style="color:#000;" >
                        <td bgcolor="#CCCCCC" width="75%" colspan="4" align="right">Total Cost for this Kitchen is:</td>
                        <td bgcolor="#CCCCCC" width="25" colspan="2">&#8377 
                        <?php 
						$counter_total= mysql_query("SELECT SUM(details_amount) FROM rem_counter_details WHERE details_header_id='$counter_id'");
						while($row_total  = mysql_fetch_array($counter_total))
						{
							echo round($row_total[0],0);
						}?>
                        </td>
                        
                        </tr>
                        <tr>
                        </table>
                        <?php } ?>

                        
                        
                        
                        
                    	</div>
       				</div>
                   
					<div class="tab-pane" id="vertical-form"></div>
					<div class="tab-pane" id="bordered-row"></div>
					<div class="tab-pane" id="tabular-form"></div>
				</div>

				<div class="panel-footer">
					<div class="row">
						<div class="col-sm-10 col-sm-offset-2">
						  <button type="submit" class="btn btn-success" name="submit" id="submit">Add Kitchen</button>
                 		</div>
                    </div>
             	 </div>
                 
                 <?php } ?>
              </div>
               
            
            
		</div>
                    </div>
</div>
                          </div> </form>
                            <!-- .container-fluid -->
                        </div> <!-- #page-content -->
                </div>
                    <footer role="contentinfo">
   <?php include("footer.php"); ?>
</footer>
              </div>
  </div>
</div>

<script>
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}
</script>
<script>
function showvendor(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayVendor").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getvendor.php?q="+str,true);
  xmlhttp.send();
}
</script>

<script>
function showprice(str,item_id) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayPrice").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getprice.php?q="+str+"&item_id="+item_id,true);
  xmlhttp.send();
}
</script>

<script>
function showamount(str,price) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayAmount").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getamount.php?q="+str+"&price="+price,true);
  xmlhttp.send();
}
</script>

<script>
function showcategory(str) {
  if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      document.getElementById("displayCategory").innerHTML=xmlhttp.responseText;
    }
  }
  xmlhttp.open("GET","getitemcategory2.php?q="+str,true);
  xmlhttp.send();
}
</script>

<!-- Switcher --><!-- /Switcher -->
    <!-- Load site level scripts -->

<!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.9.2/jquery-ui.min.js"></script> -->

<script src="assets/js/jquery-1.10.2.min.js"></script> 							<!-- Load jQuery -->
<script src="assets/js/jqueryui-1.9.2.min.js"></script> 							<!-- Load jQueryUI -->

<script src="assets/js/bootstrap.min.js"></script> 								<!-- Load Bootstrap -->


<script src="assets/plugins/easypiechart/jquery.easypiechart.js"></script> 		<!-- EasyPieChart-->
<script src="assets/plugins/sparklines/jquery.sparklines.min.js"></script>  		<!-- Sparkline -->
<script src="assets/plugins/jstree/dist/jstree.min.js"></script>  				<!-- jsTree -->

<script src="assets/plugins/codeprettifier/prettify.js"></script> 				<!-- Code Prettifier  -->
<script src="assets/plugins/bootstrap-switch/bootstrap-switch.js"></script> 		<!-- Swith/Toggle Button -->

<script src="assets/plugins/bootstrap-tabdrop/js/bootstrap-tabdrop.js"></script>  <!-- Bootstrap Tabdrop -->

<script src="assets/plugins/iCheck/icheck.min.js"></script>     					<!-- iCheck -->

<script src="assets/js/enquire.min.js"></script> 									<!-- Enquire for Responsiveness -->

<script src="assets/plugins/bootbox/bootbox.js"></script>							<!-- Bootbox -->

<script src="assets/plugins/simpleWeather/jquery.simpleWeather.min.js"></script> <!-- Weather plugin-->

<script src="assets/plugins/nanoScroller/js/jquery.nanoscroller.min.js"></script> <!-- nano scroller -->

<script src="assets/plugins/jquery-mousewheel/jquery.mousewheel.min.js"></script> 	<!-- Mousewheel support needed for jScrollPane -->

<script src="assets/js/application.js"></script>
<script src="assets/demo/demo.js"></script>
<script src="assets/demo/demo-switcher.js"></script>
<script src="assets/plugins/clockface/js/clockface.js"></script>     								<!-- Clockface -->

<script src="assets/plugins/form-colorpicker/js/bootstrap-colorpicker.min.js"></script> 			<!-- Color Picker -->

<script src="assets/plugins/bootstrap-datepicker/bootstrap-datepicker.js"></script>      			<!-- Datepicker -->
<script src="assets/plugins/bootstrap-timepicker/bootstrap-timepicker.js"></script>      			<!-- Timepicker -->
<script src="assets/plugins/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js"></script> 	<!-- DateTime Picker -->
<script src="assets/plugins/form-daterangepicker/moment.min.js"></script>              			<!-- Moment.js for Date Range Picker -->
<script src="assets/plugins/form-daterangepicker/daterangepicker.js"></script>     				<!-- Date Range Picker -->

<script src="assets/demo/demo-pickers.js"></script>
<!-- End loading site level scripts -->
    
    <!-- Load page level scripts-->
    

    <!-- End loading page level scripts-->

</body>

<!-- Mirrored from avenger.kaijuthemes.com/ui-forms.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 24 Oct 2015 18:46:10 GMT -->
</html>
<?php }
      else
        {
	       header('Location: ../index.php');
        }
		
	?>